# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_commentmeta`
#

DROP TABLE IF EXISTS `mjwp_commentmeta`;


#
# Table structure of table `mjwp_commentmeta`
#

CREATE TABLE `mjwp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_commentmeta (2 records)
#
 
INSERT INTO `mjwp_commentmeta` VALUES (1, 1, '_wp_trash_meta_status', '1') ; 
INSERT INTO `mjwp_commentmeta` VALUES (2, 1, '_wp_trash_meta_time', '1399745360') ;
#
# End of data contents of table mjwp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_comments`
#

DROP TABLE IF EXISTS `mjwp_comments`;


#
# Table structure of table `mjwp_comments`
#

CREATE TABLE `mjwp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_comments (1 records)
#
 
INSERT INTO `mjwp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-05-10 15:13:55', '2014-05-10 15:13:55', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;
#
# End of data contents of table mjwp_comments
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_links`
#

DROP TABLE IF EXISTS `mjwp_links`;


#
# Table structure of table `mjwp_links`
#

CREATE TABLE `mjwp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_links (0 records)
#

#
# End of data contents of table mjwp_links
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_options`
#

DROP TABLE IF EXISTS `mjwp_options`;


#
# Table structure of table `mjwp_options`
#

CREATE TABLE `mjwp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=459 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_options (157 records)
#
 
INSERT INTO `mjwp_options` VALUES (1, 'siteurl', 'http://localhost/themusicjournal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (2, 'blogname', 'The Music Journal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (5, 'admin_email', 'carriemphotography@gmail.com', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (6, 'start_of_week', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (11, 'posts_per_rss', '4', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (12, 'rss_use_excerpt', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (21, 'posts_per_page', '3', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (27, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (28, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `mjwp_options` VALUES (35, 'active_plugins', 'a:3:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (36, 'home', 'http://localhost/themusicjournal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (41, 'gmt_offset', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (43, 'recently_edited', 'a:2:{i:0;s:82:"/Applications/MAMP/htdocs/themusicjournal/wp-content/themes/musicjournal/style.css";i:1;s:0:"";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (44, 'template', 'musicjournal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (45, 'stylesheet', 'musicjournal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `mjwp_options` VALUES (48, 'comment_registration', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (52, 'db_version', '26692', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (55, 'blog_public', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (59, 'show_avatars', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (77, 'page_comments', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (83, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (85, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (86, 'timezone_string', 'America/New_York', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (87, 'page_for_posts', '9', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (88, 'page_on_front', '5', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (91, 'initial_db_version', '26691', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (92, 'mjwp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (99, 'cron', 'a:6:{i:1400555637;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1400570820;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1400604650;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1400604657;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1400986800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (106, '_site_transient_timeout_browser_4d5ef5d98dfcfc16bce93596e56654ed', '1400339647', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (107, '_site_transient_browser_4d5ef5d98dfcfc16bce93596e56654ed', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (133, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (140, 'acf_version', '4.3.8', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (142, 'cpt_custom_post_types', 'a:3:{i:0;a:21:{s:4:"name";s:7:"project";s:5:"label";s:8:"Projects";s:14:"singular_label";s:7:"Project";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}i:1;a:21:{s:4:"name";s:11:"inspiration";s:5:"label";s:11:"Inspiration";s:14:"singular_label";s:11:"Inspiration";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}i:2;a:21:{s:4:"name";s:5:"album";s:5:"label";s:5:"Album";s:14:"singular_label";s:5:"Album";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (149, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1399745178;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (150, 'current_theme', 'Music Journal', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (151, 'theme_mods_twentythirteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1399745889;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}}}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (152, 'theme_switched', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (153, '_transient_random_seed', '21eb3593a012acf8827e6d4b21373e3a', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (157, 'theme_mods_twentytwelve', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1399759328;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (166, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:28:"carriemphotography@gmail.com";s:7:"version";s:5:"3.8.3";s:9:"timestamp";i:1399751270;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (167, 'db_upgraded', '', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (168, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:3:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:2;O:8:"stdClass":10:{s:8:"response";s:10:"autoupdate";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-3.9.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-3.9.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.9";s:7:"version";s:3:"3.9";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1400545458;s:15:"version_checked";s:5:"3.8.3";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (169, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (172, 'theme_mods_musicjournal', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (197, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (211, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (256, '_site_transient_timeout_browser_4ca40adb72856494e5dc5b1f6bed7e37', '1400700739', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (257, '_site_transient_browser_4ca40adb72856494e5dc5b1f6bed7e37', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.137";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (374, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1400306618', 'no') ; 
INSERT INTO `mjwp_options` VALUES (375, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 18:44:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.9.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"WDS Welcomes Marcus Battle!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://webdevstudios.com/2014/05/15/wds-welcomes-marcus-battle/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://webdevstudios.com/2014/05/15/wds-welcomes-marcus-battle/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 18:34:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8195";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:421:"&#160; WebDevStudios is proud to announce the newest addition to our team, Marcus Battle! He has taken on the position of Back-End Developer. Marcus loves WordPress. Having created his own content management systems and working with others, WordPress simply gets &#8230; <a class="more-link" href="http://webdevstudios.com/2014/05/15/wds-welcomes-marcus-battle/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2111:"<p>&nbsp;</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2014/05/marcus.jpg"><img class="alignleft size-medium wp-image-8196" src="http://webdevstudios.com/wp-content/uploads/2014/05/marcus-300x300.jpg" alt="marcus" width="300" height="300" /></a>WebDevStudios is proud to announce the newest addition to our team, Marcus Battle! He has taken on the position of Back-End Developer.</p>
<p>Marcus loves WordPress. Having created his own content management systems and working with others, WordPress simply gets the job done better. He was introduced to WordPress in 2009 and kind of snubbed it as inferior to anything he could create. All it took to make him a believer was his inbox flooding with content management requests from his freelance work to realize that he needed some help. Ever since Marcus realized how much time he could save with upfront development and for clients, WordPress has been his tool of choice.</p>
<blockquote><p>I am excited to work with WDS because of all of the great talents I get to learn from. I believe that you’re never done learning and even in my first few days, I can see that I’m “around” people who really know their stuff and are open to sharing information. Overall, I just believe that working at WDS is going to make me a better developer because of the people.</p></blockquote>
<p>Outside of working for WDS he is a college student minister in Greensboro, NC where for the past 7 years; he’s helped hundreds of students prepare for their post-graduate careers and develop their faith.</p>
<p>In Marcus’ spare time, him and his wife are planning and preparing for their first child – “Baby Boy” Battle, so that’s already keeping them on their toes. (They’re not telling the name yet just in case they change their mind). You can follow <a href="https://twitter.com/MarcusDBattle">Marcus on twitter</a> to keep up on his baby news and other WordPress related awesomeness!</p>
<p>We are very excited to see what Marcus has to bring to WDS to make the company and the team better, as well as his personal growth. Welcome, Marcus!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://webdevstudios.com/2014/05/15/wds-welcomes-marcus-battle/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:60:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"WDS at WordCamp Miami 2014!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://webdevstudios.com/2014/05/05/wds-at-wordcamp-miami-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://webdevstudios.com/2014/05/05/wds-at-wordcamp-miami-2014/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 May 2014 18:51:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:10:"BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8187";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:408:"This year is the WordCamp Miami 5th anniversary event! For need to know information, you can visit the WordCamp Miami Blog. You can also sign up for SMS alerts on schedule changes, after party details, and emergencies. This year Brian Messenlehner, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/05/05/wds-at-wordcamp-miami-2014/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4356:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/05/wcmia_2014_badge_speaking.png"><img class="alignleft size-full wp-image-8189" alt="wcmia_2014_badge_speaking" src="http://webdevstudios.com/wp-content/uploads/2014/05/wcmia_2014_badge_speaking.png" width="150" height="175" /></a>This year is the <a href="http://2014.miami.wordcamp.org/">WordCamp Miami</a> 5th anniversary event! For need to know information, you can visit the <a href="http://2014.miami.wordcamp.org/important-information-for-wordcamp-miami-2014-attendees/">WordCamp Miami Blog</a>. You can also sign up for <a href="https://gather.mailchimpapp.com/subscribe/signup-for-text-alerts-from-wordcamp-miami">SMS alerts</a> on schedule changes, after party details, and emergencies. This year <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a>, <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a>, and <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> of WDS will be attendance. All three of them will also be presenting on what they know best &#8212; WordPress!</p>
<p>Like last year, WordCamp Miami is going to be holding a <a href="http://2014.miami.wordcamp.org/schedule/#may9buddycamp">BuddyCamp Miami</a> on Friday, May 9th.  This is where you will be able to find <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a> for the first time during this event. Brian is going to be speaking about <em>Building Mobile Apps With BuddyPress.<strong> </strong></em>In this session, he will be discussing how BuddyPress might be used in building a mobile app. You can sit in on this session at <strong>1:15 PM on Friday, May 9th</strong>. BuddyCamp Miami is being held at the Whitten Learning Center.</p>
<p>You can find <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> on <strong>Saturday, May 10th at 11:15 AM</strong> in the developers track. <em>I don&#8217;t hate you, I just hate your code</em> is the topic of Brian&#8217;s presentation. In this session, you&#8217;ll learn why writing clean and simple code is so incredibly important and you&#8217;ll learn some tips and tricks to achieve this goal.</p>
<p>If you miss <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a>&#8216;s BuddyCamp presentation, you&#8217;ll have the opportunity to see him speak again. You can  find him in the developers track on <strong>Saturday, May 10th at 3:00 PM</strong> to talk to you about <em>Building Web And Mobile Apps with WordPress</em>. With this talk, he will be more focused on the use of WordPress.</p>
<p>And last but not least, you can also find <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> on <strong>Saturday, May 10th at 4:30 PM</strong> in the Designer Track for <em>WordPress Podcasting: The Panel</em>. Here, Brad will be joined by fellow WordPress Podcast enthusiasts <a href="https://twitter.com/dremeda">Dre Armeda</a>, <a href="https://twitter.com/mt_Suzette">Suzette Franck</a>, <a href="https://twitter.com/mattmedeiros">Matt Medeiros</a>, <a href="https://twitter.com/pippinsplugins">Pippin Williamson</a>, and <a href="https://twitter.com/bradt">Brad Touesnard</a>.</p>
<h2>A description of the panel:</h2>
<blockquote><p>This year we are proud to be hosting a unique and a WordCamp-first panel this year at WordCamp Miami on May 10th (Saturday). We will be hosting a “Podcasting And WordPress” panel, with some of the biggest and most popular WordPress podcasters all in one room. One *physical* room. They will be telling us how they do what they do, what mistakes they’ve learned, and how they run a successful podcast. Plus a special surprise which we won’t tell them about yet</p></blockquote>
<p>Brian, Brad, and Brian are always excited to make new connections with fellow WordPress lovers. They also look forward to reconnecting with those they already know. You will have the opportunity to pick these master brains at the various events such as the networking party and the Ice Cream Social. If you see any of these guys hanging around, make sure you stop and say hey!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://webdevstudios.com/2014/05/05/wds-at-wordcamp-miami-2014/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WordPress For Dummies 6th Edition is now available!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2014/04/21/wordpress-for-dummies-6th-edition-is-now-available/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2014/04/21/wordpress-for-dummies-6th-edition-is-now-available/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 18:44:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:10:"WP Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8178";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:456:"Lisa Sabin-Wilson has been writing books on WordPress for 8 years now. From WordPress for Dummies to WordPress All-in-One and also WordPress Web Design For Dummies. With that, it should come as no surprise that the 6th edition of WordPress for Dummies is now available &#8230; <a class="more-link" href="http://webdevstudios.com/2014/04/21/wordpress-for-dummies-6th-edition-is-now-available/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3479:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/04/thumbnail1.jpg"><img class="alignleft size-medium wp-image-8179" alt="thumbnail" src="http://webdevstudios.com/wp-content/uploads/2014/04/thumbnail1-239x300.jpg" width="239" height="300" /></a><a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> has been writing books on WordPress for <strong>8 years</strong> now. From <a href="http://www.amazon.com/WordPress-For-Dummies-Lisa-Sabin-Wilson/dp/1118791614/ref=sr_1_1?ie=UTF8&amp;qid=1398105420&amp;sr=8-1&amp;keywords=wordpress+for+dummies">WordPress for Dummies</a> to <a href="http://www.amazon.com/WordPress-All-One-For-Dummies/dp/1118383346/ref=pd_sim_b_1?ie=UTF8&amp;refRID=1S4K45DRBRC1NM0F7GX8">WordPress All-in-One </a>and also <a href="http://www.amazon.com/WordPress-Web-Design-For-Dummies/dp/111854661X/ref=pd_sim_b_7?ie=UTF8&amp;refRID=0PDKKTDZ3HVM2C3SP5RG">WordPress Web Design For Dummies</a>. With that, it should come as no surprise that the <a href="http://www.amazon.com/gp/product/1118791614/ref=as_li_qf_sp_asin_tl?ie=UTF8&amp;camp=1789&amp;creative=9325&amp;creativeASIN=1118791614&amp;linkCode=as2&amp;tag=wein-20">6th edition of WordPress for Dummies</a> is now available on <a href="http://www.amazon.com/ref=gno_logo">Amazon</a>! If you are just starting off in <a href="wordpress.org">WordPress</a>, or if you&#8217;re looking to expand your knowledge base, WordPress for Dummies 6th Edition will quickly help you become familiar with all the latest features and teach you how to incorporate everything into your WordPress powered website.</p>
<p>Written for the non-technical reader, <a href="http://www.amazon.com/gp/product/1118791614/ref=as_li_qf_sp_asin_tl?ie=UTF8&amp;camp=1789&amp;creative=9325&amp;creativeASIN=1118791614&amp;linkCode=as2&amp;tag=wein-20">WordPress for Dummies 6th edition</a> provides a friendly, hands-on guide for anything and everything related to setting up your first WordPress powered website including:</p>
<ul>
<li>The differences between hosting your own WordPress site or launching a blog on WordPress.com</li>
<li>Helpful information on the tools you’ll need along the way</li>
<li>How to add and structure content for your site</li>
<li>Crucial information on themes and plugins</li>
<li>Tips on design and functionality</li>
<li>Best-practices for managing your new WordPress site</li>
</ul>
<p>Having sold over 105,000 copies of the <a href="http://www.amazon.com/Lisa-Sabin-Wilson/e/B002BLY54I/ref=ntt_athr_dp_pel_1">previous editions</a>, WordPress for Dummies is considered an industry-standard manual for anyone involved in WordPress. In fact, many seasoned developers have noted that they keep a copy of the current WordPress for Dummies book as a reference tool when they need to be able to communicate with their clients on a non-technical level.</p>
<p>Anyone new to WordPress will find this manual provides a solid starting place, rich with valuable information, to help you quickly gain the master art of WordPress. Those familiar with WordPress will appreciate the broad range of information presented in the book.</p>
<p>Make sure you grab your copy of <a href="http://www.amazon.com/WordPress-Dummies-Lisa-Sabin-Wilson/dp/1118791614/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1398098178&amp;sr=1-1&amp;keywords=wordpress+for+dummies">WordPress For Dummies 6th Edition</a> on Amazon and be sure to let us know how you like it!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://webdevstudios.com/2014/04/21/wordpress-for-dummies-6th-edition-is-now-available/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WDS Welcomes Ryan Fugate!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://webdevstudios.com/2014/04/17/wds-welcomes-ryan-fugate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2014/04/17/wds-welcomes-ryan-fugate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 14:55:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8158";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:412:"WDS is excited to announce our newest developer &#8212; Ryan Fugate! Ryan Fugate is a BuddyPress enthusiast and mobile WordPress fanatic. Previously working in social media marketing using WordPress as a secret weapon where Ryan built sites for many major &#8230; <a class="more-link" href="http://webdevstudios.com/2014/04/17/wds-welcomes-ryan-fugate/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1085:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/04/thumbnail.jpg"><img class="alignleft size-medium wp-image-8159" alt="thumbnail" src="http://webdevstudios.com/wp-content/uploads/2014/04/thumbnail-300x300.jpg" width="300" height="300" /></a>WDS is excited to announce our newest developer &#8212; <a title="Ryan Fugate" href="http://webdevstudios.com/team/ryan-fugate/">Ryan Fugate</a>!</p>
<p>Ryan Fugate is a BuddyPress enthusiast and mobile WordPress fanatic. Previously working in social media marketing using WordPress as a secret weapon where Ryan built sites for many major brands. His current status: BuddyPress trac and forums, creating fun plugins, WordPress as a mobile framework and coffee. When he’s not breaking WordPress, he rides his fixie around Los Angeles and frequently indulges in churro consumption at Disneyland. You can follow Ryan on Twitter for all things WordPress and BuddyPress! <a href="https://twitter.com/modemlooper">@modemlooper</a></p>
<p>We can&#8217;t wait to see what Ryan can bring to the WebDevStudios table. Welcome, Ryan!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:66:"http://webdevstudios.com/2014/04/17/wds-welcomes-ryan-fugate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WDS Welcomes Trisha Salas!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://webdevstudios.com/2014/04/16/wds-welcomes-trisha-salas/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://webdevstudios.com/2014/04/16/wds-welcomes-trisha-salas/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 17:44:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8156";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:394:"WebDevStudios is excited to announce a new member to the team &#8212; Trisha Salas! She will be coming onto the team as a designer. Trisha has been called a ‘rogue designer’ more than once. She’s just as comfortable in a graphics &#8230; <a class="more-link" href="http://webdevstudios.com/2014/04/16/wds-welcomes-trisha-salas/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1506:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/04/large.jpg"><img class="alignleft size-medium wp-image-8157" alt="large" src="http://webdevstudios.com/wp-content/uploads/2014/04/large-300x262.jpg" width="300" height="262" /></a></p>
<p>WebDevStudios is excited to announce a new member to the team &#8212; <a title="Trisha Salas" href="http://webdevstudios.com/team/trisha-salas/">Trisha Salas</a>! She will be coming onto the team as a designer.</p>
<p>Trisha has been called a ‘rogue designer’ more than once. She’s just as comfortable in a graphics editor as she is a text editor (but prefers the latter). Originally a web designer with a love for CSS, she transitioned to WordPress in 2011 and hasn&#8217;t looked back.<br />
Since then she has spoken at her first WordCamp, organized the Tulsa WordPress MeetUp, helped to organize the Tulsa 200 OK Conference, and started regularly contributing to BuddyPress. She’s also now co-leading a<a href="http://make.wordpress.org/docs/handbook/projects/admin-help/"> feature plugin for WordPress core</a>. Trisha is a self-declared introvert who spends her free time working on projects or playing with code.</p>
<p>When not head down in code, Trisha loves to spend time with her five children who are 23, 21, 19, and twins who are 15! You can follow Trisha on Twitter! <a href="https://twitter.com/trishacodes">@trishacodes</a></p>
<p>We can&#8217;t wait to see what Trisha can add to the team and the company! Welcome, Trisha!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://webdevstudios.com/2014/04/16/wds-welcomes-trisha-salas/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"Lisa Sabin-Wilson at the Greater Milwaukee Area WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://webdevstudios.com/2014/04/14/lisa-sabin-wilson-at-the-greater-milwaukee-area-wordpress-meetup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:110:"http://webdevstudios.com/2014/04/14/lisa-sabin-wilson-at-the-greater-milwaukee-area-wordpress-meetup/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 16:45:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:10:"AppPresser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8150";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:396:"Lisa loves to be involved in the WordPress community as much as she can. One way she likes to show her support is by going to the local meetups in her area! If you are in the Milwaukee area tomorrow; &#8230; <a class="more-link" href="http://webdevstudios.com/2014/04/14/lisa-sabin-wilson-at-the-greater-milwaukee-area-wordpress-meetup/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1761:"<p><a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/"><img class="alignleft size-thumbnail wp-image-8151" alt="meetup" src="http://webdevstudios.com/wp-content/uploads/2014/04/meetup-150x150.png" width="150" height="150" />Lisa</a> loves to be involved in the WordPress community as much as she can. One way she likes to show her support is by going to the local meetups in her area! If you are in the Milwaukee area tomorrow; Tuesday, April 15th at 7: 00 PM CST, you can stop at <a href="https://maps.google.com/maps?f=q&amp;hl=en&amp;q=222+E.+Erie+Street,+Suite+330,+Milwaukee,+WI,+53202,+us">C2 Graphics Productivity Solutions, LLC</a> and sit in on Lisa&#8217;s talk.</p>
<p><a href="http://apppresser.com"><img class="size-full wp-image-8154 alignnone" alt="AppPresser" src="http://webdevstudios.com/wp-content/uploads/2014/04/login-logo.png" width="312" height="59" /></a></p>
<p>Lisa will be talking about Creating a Mobile App with WordPress + <a href="http://apppresser.com/">AppPresser</a>.</p>
<blockquote><p>Design your app and customize it the same way you build a normal WordPress site. No objective C, Java or SDK knowledge necessary. Use the AppPresser plugins and themes to make WordPress look and behave like a native app. Use sliding panels, menus, and tap into native device hardware. Submit your app to the iOS App Store, Google Play, and more. People all over the world can download (or purchase) your app!</p>
<p>The power of building native mobile apps is now in your hands &#8211; with WordPress + AppPresser.</p></blockquote>
<p>If you&#8217;re attending the meetup, say hey to Lisa! She&#8217;s excited to reconnect with those she&#8217;s already met, and to also connect with those she has not!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:106:"http://webdevstudios.com/2014/04/14/lisa-sabin-wilson-at-the-greater-milwaukee-area-wordpress-meetup/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WDS Welcomes Simon Urbina!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://webdevstudios.com/2014/04/10/wds-welcomes-simon-urbina/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://webdevstudios.com/2014/04/10/wds-welcomes-simon-urbina/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Apr 2014 19:49:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8143";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:390:"WebDevStudios is excited to announce a new member of the team &#8212; Simon Urbina! He will be coming on as one of our front-end developers! Simon Urbina is a Web Designer, App Developer, and Information Architect with over 20 years &#8230; <a class="more-link" href="http://webdevstudios.com/2014/04/10/wds-welcomes-simon-urbina/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1175:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/04/Simon.jpg"><img class="alignleft size-full wp-image-8145" alt="Simon" src="http://webdevstudios.com/wp-content/uploads/2014/04/Simon.jpg" width="164" height="218" /></a></p>
<p>WebDevStudios is excited to announce a new member of the team &#8212; <a href="http://webdevstudios.com/team/simon-urbina/" title="Simon Urbina">Simon Urbina</a>! He will be coming on as one of our front-end developers!</p>
<p>Simon Urbina is a Web Designer, App Developer, and Information Architect with over 20 years of experience. He started as a graphic designer and illustrator in the late 80&#8242;s and made his transition to web in 1996. He&#8217;s a talented artist while understanding business strategy, user experience, and technology. He&#8217;s a proponent for the user and completely in love with technologies like WordPress. He&#8217;s a dedicated family man and lives in Naples, Florida with his wife and son. You can follow Simon on Twitter &#8211; <a href="http://twitter.com/simonwebdesign">@SimonWebDesign</a></p>
<p>We can&#8217;t wait to see what Simon has to offer the team and the company. Welcome, Simon!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://webdevstudios.com/2014/04/10/wds-welcomes-simon-urbina/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"AppPresser at MacWorld/iWorld 2014!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2014/03/19/apppresser-at-macworldiworld-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2014/03/19/apppresser-at-macworldiworld-2014/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 15:59:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:10:"AppPresser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8090";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:423:"MacWorld/iWorld is the dream of Apple fans everywhere. A 3 day conference full of all things Apple, including the &#8220;6 About To Break&#8221; competition. The &#8220;6 About To Break&#8221; is a competition of the top 6 most innovative apps, accessories, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/03/19/apppresser-at-macworldiworld-2014/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1812:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/03/Macworld-iWorld-2014.png"><img class="aligncenter size-full wp-image-8091" alt="Macworld   iWorld 2014" src="http://webdevstudios.com/wp-content/uploads/2014/03/Macworld-iWorld-2014.png" width="419" height="86" /></a></p>
<p><a href="http://www.macworldiworld.com/">MacWorld/iWorld</a> is the dream of Apple fans everywhere. A 3 day conference full of all things Apple, including the <a href="http://www.macworldiworld.com/6-about-to-break">&#8220;6 About To Break&#8221; competition</a>. The &#8220;6 About To Break&#8221; is a competition of the top 6 most innovative apps, accessories, software, and utilities that are going to be making waves in the Apple Marketplace.</p>
<p>WDS is excited about this competition &#8212; why? <a href="http://apppresser.com/">AppPresser</a> has taken 1 of those 6 spots! All of the creators of these amazing products, in true Apple fashion, will have the chance at MacWorld to have a 5 minute demonstration and a 5 minute Q&amp;A about their product. AppPresser co-founders, <a href="https://twitter.com/bmess">Brian Messenlehner</a> and <a href="https://twitter.com/scottbolinger">Scott Bolinger</a> will be attending MacWorld to make the presentation. This showdown is happening on Thursday, March 27th from 4:30-5:30pm on the Macworld/iWorld’s Second Stage. After all the presentations have been made, a panel of experts will make the decision on who will be the winner.</p>
<p>Along with being in the &#8220;6 About To Break&#8221;, AppPresser will also have a kiosk throughout the event where you can ask questions and check it out! You can get more details about AppPresser at MacWorld/iWorld 2014 on their <a href="http://apppresser.com/6-about-to-break/">blog</a>.</p>
<p>Good Luck, AppPresser!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2014/03/19/apppresser-at-macworldiworld-2014/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"Brad Williams and Lisa Sabin-Wilson — Podcast with InMotion Hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://webdevstudios.com/2014/03/12/brad-williams-and-lisa-sabin-wilson-podcast-with-inmotion-hosting/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:111:"http://webdevstudios.com/2014/03/12/brad-williams-and-lisa-sabin-wilson-podcast-with-inmotion-hosting/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 17:07:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8085";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:443:"Brad Williams and Lisa Sabin-Wilson did an interview with InMotion Hosting on March 11th, 2014. The interview was conducted by Jeff Matson, who is the Technical Content Writer over at InMotion Hosting. Brad and Lisa were asked all about WDS and &#8230; <a class="more-link" href="http://webdevstudios.com/2014/03/12/brad-williams-and-lisa-sabin-wilson-podcast-with-inmotion-hosting/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:869:"<p><a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> and <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> did an interview with <a href="http://www.inmotionhosting.com/">InMotion Hosting</a> on March 11th, 2014. The interview was conducted by <a href="https://twitter.com/TheJeffMatson">Jeff Matson</a>, who is the Technical Content Writer over at InMotion Hosting. Brad and Lisa were asked all about WDS and WordPress!</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/iMiTmbDJaMo?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:107:"http://webdevstudios.com/2014/03/12/brad-williams-and-lisa-sabin-wilson-podcast-with-inmotion-hosting/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Brian Messenlehner and Lisa Sabin-Wilson at SXSW 2014!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2014/03/06/brian-messenlehner-and-lisa-sabin-wilson-at-sxsw-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2014/03/06/brian-messenlehner-and-lisa-sabin-wilson-at-sxsw-2014/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Mar 2014 16:37:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8070";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:426:"SXSW, if you didn&#8217;t know, is a huge gathering of the brightest minds, greatest artists, and impressive film creators. This event is being held from March 7th &#8211; March 16th in Austin, Texas. If you have trouble trying to find it, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/03/06/brian-messenlehner-and-lisa-sabin-wilson-at-sxsw-2014/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2094:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/03/sxsw.png"><img class="alignleft size-full wp-image-8079" alt="sxsw" src="http://webdevstudios.com/wp-content/uploads/2014/03/sxsw.png" width="293" height="192" /></a><a href="http://sxsw.com/">SXSW</a>, if you didn&#8217;t know, is a huge gathering of the brightest minds, greatest artists, and impressive film creators. This event is being held from March 7th &#8211; March 16th in Austin, Texas. If you have trouble trying to find it, just look up, you won&#8217;t be able to miss it. This year, <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a> and <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> will be attending SXSW for the interactive portion &#8212; &#8220;<em>An incubator of cutting-edge technologies and digital creativity, the 2014 event features five days of compelling <a href="http://sxsw.com/interactive/sessions/about">presentations and panels</a> from the brightest minds in emerging technology, scores of exciting networking events hosted by industry leaders and an unbeatable lineup of special programs showcasing the best new websites, video games and start-up ideas the community has to offer</em>.&#8221;</p>
<p>You won&#8217;t find Brian or Lisa on stage presenting this time around, but you can find them walking around to all the booths on &#8220;The Floor&#8221;, at various WordPress related gatherings, and at after parties. On Saturday, Brian and Lisa will be attending the <a href="http://wordpress.com/">Wo</a><a href="http://wordpress.com/">rdPress.com</a> VIP Party at <a href="http://www.maggiemaesaustin.com/" target="_blank">Maggie Mae&#8217;s Rooftop</a>. If you&#8217;re looking for a chance to network with Brian or Lisa, or with WebDevStudios as a whole, SXSW is the place to do it!</p>
<p>Brian and Lisa are excited, as always, to reconnect with people they&#8217;ve already met and are hoping to make even more connections with people they&#8217;ve yet to meet!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2014/03/06/brian-messenlehner-and-lisa-sabin-wilson-at-sxsw-2014/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"/f0IVmjRIceqi7Wuc3NcFJ/s+T8";s:13:"last-modified";s:29:"Fri, 16 May 2014 16:50:12 GMT";s:4:"date";s:29:"Fri, 16 May 2014 18:03:38 GMT";s:7:"expires";s:29:"Fri, 16 May 2014 18:03:38 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (376, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1400306618', 'no') ; 
INSERT INTO `mjwp_options` VALUES (377, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1400263418', 'no') ; 
INSERT INTO `mjwp_options` VALUES (378, 'rewrite_rules', 'a:110:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"inspiration/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"inspiration/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"inspiration/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"inspiration/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"inspiration/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"inspiration/([^/]+)/trackback/?$";s:38:"index.php?inspiration=$matches[1]&tb=1";s:40:"inspiration/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?inspiration=$matches[1]&paged=$matches[2]";s:47:"inspiration/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?inspiration=$matches[1]&cpage=$matches[2]";s:32:"inspiration/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?inspiration=$matches[1]&page=$matches[2]";s:28:"inspiration/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"inspiration/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"inspiration/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"inspiration/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"inspiration/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"album/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"album/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"album/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"album/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"album/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"album/([^/]+)/trackback/?$";s:32:"index.php?album=$matches[1]&tb=1";s:34:"album/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?album=$matches[1]&paged=$matches[2]";s:41:"album/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?album=$matches[1]&cpage=$matches[2]";s:26:"album/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?album=$matches[1]&page=$matches[2]";s:22:"album/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"album/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"album/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"album/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"album/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (422, '_site_transient_timeout_theme_roots', '1400547144', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (423, '_site_transient_theme_roots', 'a:4:{s:12:"musicjournal";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (425, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1400545459;s:7:"checked";a:4:{s:12:"musicjournal";s:3:"1.0";s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:3:{s:14:"twentyfourteen";a:4:{s:5:"theme";s:14:"twentyfourteen";s:11:"new_version";s:3:"1.1";s:3:"url";s:43:"https://wordpress.org/themes/twentyfourteen";s:7:"package";s:60:"https://wordpress.org/themes/download/twentyfourteen.1.1.zip";}s:14:"twentythirteen";a:4:{s:5:"theme";s:14:"twentythirteen";s:11:"new_version";s:3:"1.2";s:3:"url";s:43:"https://wordpress.org/themes/twentythirteen";s:7:"package";s:60:"https://wordpress.org/themes/download/twentythirteen.1.2.zip";}s:12:"twentytwelve";a:4:{s:5:"theme";s:12:"twentytwelve";s:11:"new_version";s:3:"1.4";s:3:"url";s:41:"https://wordpress.org/themes/twentytwelve";s:7:"package";s:58:"https://wordpress.org/themes/download/twentytwelve.1.4.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (427, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1400588560', 'no') ; 
INSERT INTO `mjwp_options` VALUES (428, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23290:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 20 May 2014 00:22:40 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 08 May 2014 18:40:58 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (429, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1400588560', 'no') ; 
INSERT INTO `mjwp_options` VALUES (430, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1400545360', 'no') ; 
INSERT INTO `mjwp_options` VALUES (431, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1400588562', 'no') ; 
INSERT INTO `mjwp_options` VALUES (432, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: WordPress for Android Will No Longer Support Gingerbread";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23104";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/wordpress-for-android-will-no-longer-support-gingerbread?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-for-android-will-no-longer-support-gingerbread";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3960:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/googleplex-treats.jpg" rel="prettyphoto[23104]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/googleplex-treats.jpg?resize=975%2C440" alt="googleplex-treats" class="aligncenter size-full wp-image-23114" /></a></p>
<p>Long time Android users will remember how much of leap forward Ice Cream Sandwich 4.0 (ICS) was for the platform in 2011. As the vastly improved successor to Android 2.3 Gingerbread, it was one of the largest upgrades to Android OS in history, creating a demarcation line between the much older versions and the newer ones that would follow. (Android OS versions are released in alphabetical order under sugary treat code names.)</p>
<p>ICS came with a completely redesigned UI and the new Roboto typeface. It introduced a new voice input engine and a ton of new media capabilities. The 4.0 version added more intuitive gestures and allowed app developers to make use of them, too. Android developers often refer to the ICS release as a pivotal point in the platform&#8217;s development, given how much changed.</p>
<h3>WordPress for Android Mobile App to Drop Gingerbread Support</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/chomp.jpg" rel="prettyphoto[23104]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/chomp.jpg?resize=296%2C300" alt="chomp" class="alignright size-full wp-image-23115" /></a>The WordPress for Android development team <a href="http://android.wordpress.org/2014/05/16/wordpress-for-android-no-longer-paying-the-gingerbread-tax/" target="_blank">announced</a> today that it will no longer support Gingerbread.</p>
<p>Despite the fact that ICS was released in 2011, many people are still using devices that don&#8217;t support anything past Gingerbread. In an effort to reach the largest number of users, the WordPress app has maintained compatibility with older versions, incurring a ton of extra development time.</p>
<p>Recent numbers showing the <a href="http://developer.android.com/about/dashboards/index.html" target="_blank">relative number of devices on various Android platform versions</a> puts Gingerbread at about 16% this month, down 1% from April:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/android-version-usage.jpg" rel="prettyphoto[23104]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/android-version-usage.jpg?resize=802%2C366" alt="android-version-usage" class="aligncenter size-full wp-image-23119" /></a></p>
<p>The cost of supporting Gingerbread for a small portion of the WordPress app&#8217;s user base (which is actually less than 10%) causes the everyone else to suffer what they are calling the “Gingerbread tax” while waiting for new features:</p>
<blockquote><p>This means over 90% of our users are paying a “Gingerbread tax” – waiting longer for new versions and not seeing features that take advantage of their phones – so that we can continue supporting older devices.</p></blockquote>
<p>The upcoming version 2.9 of WordPress for Android will only support devices running Android 4.0 or later, allowing its developers to be more productive. The app itself will also become faster and smaller for the majority of people who are using it.</p>
<p>Please note that it doesn&#8217;t mean that the app is disappearing for these devices. An older version will still be available from the Google Play store for use with older phones and tablets that are still running on Gingerbread.</p>
<p>Gingerbread support will officially be dropped later this month when WordPress for Android 2.9 is expected to be released. This version will also include a new Blog Discovery feature for finding blogs based on recommendation as well the ability to preview a blog&#8217;s posts before electing to follow. Subscription management will also be included, along with a number of helpful UI improvements.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 23:12:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: WordCamp Miami Kids’ Workshop Launches the Next Generation of Bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23037";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/wordcamp-miami-kids-workshop-launches-the-next-generation-of-bloggers?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-miami-kids-workshop-launches-the-next-generation-of-bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6407:"<p><a href="http://wptavern.com/recap-of-wordcamp-miami-2014" target="_blank">WordCamp Miami</a> celebrated its 5th anniversary this year, drawing 770+ people to the event. The organizers also hosted their first <a href="http://wptavern.com/wordcamp-miami-to-host-free-wordpress-beginners-workshop-for-kids" target="_blank">WordPress beginner&#8217;s workshop for kids</a> as part of the Sunday activities.</p>
<p>Tammie Lister, Kathryn Presner and I worked together to lead the workshop, along with volunteers Noel Tock, Mika Epstein, and Suzette Franck. The session was geared toward kids aged 8-12 and each child attended with a parent. We had two hours to give an introduction to WordPress and help the kids set up their own blogs. At the end of the morning, each child had published a post to the internet.</p>
<blockquote class="twitter-tweet" width="550"><p>Personally, this is most likely the proudest photo from <a href="https://twitter.com/search?q=%23wcmia&src=hash">#wcmia</a> : Our 1st Kid’s Workshop. <a href="http://t.co/KecwSCwVM5">pic.twitter.com/KecwSCwVM5</a></p>
<p>&mdash; David Bisset (@dimensionmedia) <a href="https://twitter.com/dimensionmedia/statuses/466574992105164800">May 14, 2014</a></p></blockquote>
<p></p>
<p>Lister designed the slides for the presentation with a Minecraft theme, which ended up being a big win, since the vast majority of the kids present were wild about the game. She used aspects of Minecraft to help us explain the concept of open source, WordPress blogging tools, themes, commenting, subscribing and making friends online.</p>
<p>We guided the kids through signing up on WordPress.com to create a free blog. A couple of them already had blogs on a network hosted by their parents, but most of them were experiencing WordPress for the first time, including many of their parents. I came away from the workshop with three observations regarding kids and WordPress.</p>
<h3>1. WordPress is Easy for Kids to Use</h3>
<p>The most time-consuming aspect of the workshop was getting kids signed up to WordPress.com and making sure everyone recieved the confirmation email. Not all of the kids had their own email addresses but those who didn&#8217;t were able to use a parent&#8217;s address. Once inside the WordPress admin, the kids took to blogging quite naturally and didn&#8217;t require much hand-holding.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/kidsblogging.jpg" rel="prettyphoto[23037]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/kidsblogging.jpg?resize=1025%2C769" alt="kidsblogging" class="aligncenter size-full wp-image-23048" /></a></p>
<p>After publishing their first posts, the kids linked up to comment on each other&#8217;s blogs and discovered the comment notifications and relevant admin screens on their own. Adding images/media was no sweat for them and many were eager to publish additional posts after the first one.</p>
<h3>2. The Joy of Publishing is Timeless</h3>
<p>One might think that the concept of blogs would be old news to kids who who have never known a world without the internet. While media and technology <del datetime="2014-05-19T15:44:00+00:00">curmudgeons</del> analysts, who count themselves on the cutting edge, like to proclaim that <a href="http://www.newrepublic.com/article/113053/new-york-times-buzzfeed-andrew-sullivan-herald-death-blog" target="_blank">blogs are dead</a>, these kids are discovering publishing for the first time.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/jahdin.png" rel="prettyphoto[23037]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/jahdin.png?resize=1025%2C517" alt="jahdin" class="aligncenter size-full wp-image-23073" /></a></p>
<p>Upon hitting the &#8220;Publish&#8221; button, workshop attendee Jahdin, pictured above, put his hands in the air and shouted, <strong>&#8220;I just published my first post to the Internet!&#8221;</strong> His blog was about his ninth birthday party and included a picture from the event. I asked him what he plans to write about in the future, and he said, <strong>&#8220;I plan to blog about how life was when I was a kid.&#8221;</strong></p>
<p>If you can remember back to the thrill of publishing your thoughts to the web for the first time, that&#8217;s exactly what we saw in the kids&#8217; reactions to putting their first posts out there. WordPress gives them a place to record their thoughts and experiences in a way that can be shared with friends and relatives who want to follow their adventures.</p>
<p>Jahdin&#8217;s plan to &#8220;blog about life when I was a kid&#8221; is one of the most common reasons many of us started blogging in the first place &#8211; to record our own history. This is the next generation of people building the web. Putting the power of publishing in their hands and introducing them to new ideas, such as open source software, gives each child a simple framework for understanding themselves as a person with a voice on the web.</p>
<h3>3. Kids Might Enjoy More Advanced Workshops</h3>
<p>The first kids workshop at WordCamp Miami was a great success and it seems that even more advanced kids workshops would go over well, based on the response. Learning the basics of themes, plugins and WordPress core would be interesting things to explore with them, as some of the older kids seemed eager to know more about the building blocks of WordPress.</p>
<p>WordCamp Miami isn&#8217;t the only event to host a workshop for kids. Both <a href="http://2014.phoenix.wordcamp.org/" target="_blank">WordCamp Phoenix</a> and <a href="http://2013.albuquerque.wordcamp.org/session/wordpress-for-kids/" target="_blank">WordCamp Albuquerque</a> have held similar events. The workshop in Albuquerque is so popular that they&#8217;ve brought it back every year for the past three years.</p>
<p>While WordCamps have always been open to people of all ages, having a dedicated session tailored for kids is an investment in the future publishers and makers of the web. Watching kids get excited about WordPress was one of the highlights of the event for me. If you have an active meetup group or are part of organizing a WordCamp, you might consider adding a session or even a track for kids. Helping them publish their first posts is an inspirational way to experience WordPress for the first time all over again.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 19:24:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WordPress.tv: Agnes Bury: 10 Common Mistakes WordPress Developers Make When Building Multilingual Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34946";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://wordpress.tv/2014/05/19/agnes-bury-10-common-mistakes-wordpress-developers-make-when-building-multilingual-sites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:755:"<div id="v-k2JB4lHu-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34946/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34946/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34946&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/19/agnes-bury-10-common-mistakes-wordpress-developers-make-when-building-multilingual-sites/"><img alt="Agnes Bury: 10 Common Mistakes WordPress Developers Make When Building Multilingual Sites" src="http://videos.videopress.com/k2JB4lHu/video-4e56aa924b_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 18:51:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:105:"WordPress.tv: Table Ronde: Sites multilingues – le grand débat qui va enfin tout régler (yeah right!)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33387";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/05/19/table-ronde-sites-multilingues-le-grand-debat/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:638:"<div id="v-B5P762t4-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33387/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33387/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33387&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/19/table-ronde-sites-multilingues-le-grand-debat/"><img alt="table_ronde.mp4" src="http://videos.videopress.com/B5P762t4/video-ce5d9e7eb2_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 18:30:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"WordPress.tv: Micha Wood: The WP Way";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34912";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.tv/2014/05/19/micha-wood-the-wp-way/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:627:"<div id="v-7vsH79SI-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34912/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34912/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34912&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/19/micha-wood-the-wp-way/"><img alt="Micha Wood: The WP Way" src="http://videos.videopress.com/7vsH79SI/video-7ae60e0510_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 18:29:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Automattic Doesn’t Claim Copyright On Their APIs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23019";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/automattic-doesnt-claim-copyright-on-their-apis?utm_source=rss&utm_medium=rss&utm_campaign=automattic-doesnt-claim-copyright-on-their-apis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4953:"<div id="attachment_23024" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/OracleFeaturedImage.png" rel="prettyphoto[23019]"><img class="size-full wp-image-23024" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/OracleFeaturedImage.png?resize=639%2C200" alt="Oracle Featured Image" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/dahlstroms/4140461901/">Håkan Dahlström</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a></p></div>
<p>In a crucial <a title="http://www.cafc.uscourts.gov/images/stories/opinions-orders/13-1021.Opinion.5-7-2014.1.PDF" href="http://www.cafc.uscourts.gov/images/stories/opinions-orders/13-1021.Opinion.5-7-2014.1.PDF">courtroom decision</a> involving Google v.s Oracle, the United States Court of Appeals for the Federal Circuit ruled in favor of Oracle. The main part of the appeal is whether Oracle can claim copyright on Java APIs and if Google infringed that copyright. If the ruling stands, it would create a major setback to innovation and collaboration.</p>
<p>The Electronic Frontier Foundation has a <a title="https://www.eff.org/deeplinks/2014/05/dangerous-ruling-oracle-v-google-federal-circuit-reverses-sensible-lower-court" href="https://www.eff.org/deeplinks/2014/05/dangerous-ruling-oracle-v-google-federal-circuit-reverses-sensible-lower-court">great write up</a> on the ruling and the implications it could have for the internet.</p>
<blockquote><p>The implications of this decision are significant, and dangerous. As we and others <a href="https://www.eff.org/document/amicus-brief-computer-scientists">tried to explain</a> to the court, the freedom to reimplement and extend existing APIs has been the key to competition and progress in both hardware and software development.</p>
<p>It made possible the emergence and success of many robust industries we now take for granted—for mainframes, PCs, workstations/servers, and so on—by ensuring that competitors could challenge established players and advance the state of the art. In other words, excluding APIs from copyright protection has been essential to the development of modern computers and the Internet.</p></blockquote>
<p>Between 2004 and 2009, which I consider to be the crazy <a title="http://en.wikipedia.org/wiki/Web_2.0" href="http://en.wikipedia.org/wiki/Web_2.0">Web 2.0 years</a>, the one commonality among all of the services was their APIs. The APIs enabled sites, services, and applications to creatively use the data to create mashups. In June of 2005, <a title="http://googleblog.blogspot.com/2005/06/world-is-your-javascript-enabled_29.html" href="http://googleblog.blogspot.com/2005/06/world-is-your-javascript-enabled_29.html">Google released</a> a publicly available API to their Google Maps product. The API ignited a flurry of creative new ways to use and display the data. The ruling would prevent open innovation from happening without explicit permission to use API calls.</p>
<h3>Automattic Takes The Pro-Active Approach</h3>
<p><a title="http://automattic.com/" href="http://automattic.com/">Automattic</a>, the parent company of WordPress.com, has taken a pro-active approach. On May 12th, Automattic <a title="https://developer.wordpress.com/guidelines/#update-copyright" href="https://developer.wordpress.com/guidelines/#update-copyright">changed their guidelines</a> to specify that their APIs are not copyrighted.</p>
<blockquote><p>One more thing – APIs like ours enable the kind of collaboration that makes the Internet great. We don’t think APIs <a href="https://www.eff.org/deeplinks/2014/05/dangerous-ruling-oracle-v-google-federal-circuit-reverses-sensible-lower-court">are copyrightable subject matter</a>, and don’t claim copyright in our APIs.</p></blockquote>
<p>In the section of the the document discussing intellectual property, Automattic clarified they do not claim any copyrights to their APIs that may arise under US law.</p>
<blockquote><p>3. Intellectual Property. [The Automattic APIs are subject to certain intellectual property rights in the US and other countries (though Automattic does not claim copyrights in the Automattic APIs that may arise under US law). You agree to abide by such rights, all applicable laws, and any additional copyright notices or restrictions to which any Content is subject.]</p></blockquote>
<p>Although innovation wouldn&#8217;t cease completely with copyrighted APIs, it would be more difficult thanks to the red tape involved. Patent trolling is already a serious problem and if the court ruling stands, API copyright trolls would probably be the next big thing.</p>
<p>Google will likely file an appeal to the Supreme Court and there is a long way to go before the case is over. Regardless of the final ruling, the Automattic APIs are copyright free. Hopefully, other service providers take the same pro-active approach.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 17:33:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Things To Consider Before Giving A WordPress Developer Admin Access To Your Site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23030";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/things-to-consider-before-giving-a-wordpress-developer-admin-access-to-your-site?utm_source=rss&utm_medium=rss&utm_campaign=things-to-consider-before-giving-a-wordpress-developer-admin-access-to-your-site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3445:"<p>Have you ever found yourself in a situation where a plugin author requests administrator access to your site for troubleshooting purposes? That&#8217;s the <a title="http://www.wpbeginner.com/opinion/should-you-give-admin-access-to-plugin-developers-for-fixing-bugs/" href="http://www.wpbeginner.com/opinion/should-you-give-admin-access-to-plugin-developers-for-fixing-bugs/">question posed by WPBeginner</a> along with a couple of tips to help you decide whether you answer <strong>yes</strong> or <strong>no</strong>. Over the years, I&#8217;ve given access to a couple of plugin authors for the sake of troubleshooting but I always make sure to delete their account when finished.</p>
<p>Recently, I found myself in a situation where the plugin author needed admin access to experience the problem first-hand. Instead of creating a new account, I scheduled a Google Hangout. Within Google Hangout is a screen sharing application. Using the app, I was able to walk the plugin author through the process of replicating the bug without giving them administrator access.</p>
<div id="attachment_23033" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/GoogleHangoutScreenShare.png" rel="prettyphoto[23030]"><img class="size-full wp-image-23033" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/GoogleHangoutScreenShare.png?resize=645%2C426" alt="Screen Sharing App Withing Google Hangouts" /></a><p class="wp-caption-text">Screen Sharing App Withing Google Hangouts</p></div>
<p>Alternatively, you can use the screen sharing option built into Skype. This keeps the communication channel private and most plugin developers I&#8217;ve interacted with have a Skype account. You don&#8217;t need any credits to perform a screen sharing call using data. The video sessions were scheduled with plugin developers after I exhausted all other support options.</p>
<h3>Giving Admin Access Should Be The Last Resort</h3>
<p>Giving administrator access should be considered as the last resort. If you need to give them access, make sure you trust the plugin author. Look at their WP.org profile as well as their support forum history. If the author has a history of being malicious, there&#8217;s a good chance someone reported them. If possible, give them access to a staging site or a sub-domain that mirrors the live site. If you need to give them access to the live site, make sure you back up everything first in case the author changes files to try to fix the issue.</p>
<p>When they&#8217;re finished, inspect the user administration screen to see if any additional users with administrator privileges were created. If so, delete them and find out why that was necessary to diagnose the problem. In most cases, this type of action is unnecessary and would make me highly suspicious of their actions.</p>
<p><strong>Not all plugin authors have malicious intentions.</strong> The tips I outlined are precautionary measures to protect your site.</p>
<h3>Have You Been Burned By A Developer?</h3>
<p>With that in mind, I&#8217;m curious as to whether or not you&#8217;ve been burned by a theme or plugin developer? Did you give them administrator access and end up with a site in worse shape? Have you ever had to restore a backup thanks to a developer making a troubleshooting mistake?</p>
<p>If you have any additional tips or advice, you&#8217;re welcome to share them in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 19 May 2014 17:16:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Tony Perez: WordPress Security – It’s All About The Basics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34746";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2014/05/18/tony-perez-wordpress-security-its-all-about-the-basics/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-uvLAsAAd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34746/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34746/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34746&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/18/tony-perez-wordpress-security-its-all-about-the-basics/"><img alt="Tony Perez: WordPress Security – It’s All About The Basics" src="http://videos.videopress.com/uvLAsAAd/video-4dc54fd242_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 May 2014 18:49:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Jamie Schmid: Structuring Content In WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34776";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/05/18/jamie-schmid-structuring-content-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:675:"<div id="v-sFs8ABIG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34776/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34776/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34776&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/18/jamie-schmid-structuring-content-in-wordpress/"><img alt="Jamie Schmid: Structuring Content In WordPress" src="http://videos.videopress.com/sFs8ABIG/video-27b8bd7af0_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 May 2014 18:26:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WordPress.tv: Nick Ciske: Plugin Monetization Options";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34550";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.tv/2014/05/18/nick-ciske-plugin-monetization-options/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:655:"<div id="v-gcyV4RJ3-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34550/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34550/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34550&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/18/nick-ciske-plugin-monetization-options/"><img alt="Nick Ciske: Plugin Monetization Options" src="http://videos.videopress.com/gcyV4RJ3/video-109426690f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 May 2014 18:00:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WordPress.tv: Luca Sartoni: Remote working – one does not simply spend a year without pants";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34597";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:106:"http://wordpress.tv/2014/05/17/luca-sartoni-remote-working-one-does-not-simply-spend-a-year-without-pants/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:658:"<div id="v-cWRv1Pmi-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34597/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34597/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34597&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/17/luca-sartoni-remote-working-one-does-not-simply-spend-a-year-without-pants/"><img alt="" src="http://videos.videopress.com/cWRv1Pmi/video-8f8d4c06ba_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 May 2014 01:15:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: WordPress Tip: Display Viewport Resolution with the Frontend Developer Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22993";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:216:"http://wptavern.com/wordpress-tip-display-viewport-resolution-with-the-frontend-developer-plugin?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-tip-display-viewport-resolution-with-the-frontend-developer-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1796:"<p>The <a href="http://wordpress.org/plugins/wp-front-end-developer/" target="_blank">Frontend Developer</a> plugin is a handy little tool for WordPress theme developers who are working with media queries. The plugin hooks into the admin bar to display the current viewport resolution so that developers know what they&#8217;re working with.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/frontend-dev-plugin.png" rel="prettyphoto[22993]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/frontend-dev-plugin.png?resize=1025%2C755" alt="frontend-dev-plugin" class="aligncenter size-full wp-image-22999" /></a></p>
<p>The indicator automatically updates as you resize your browser window. In addition to displaying common media queries for mobile, tablet and desktop, the plugin performs some helpful checks:</p>
<ul>
<li>Highlights defined widget areas</li>
<li>Highlights links that do not have a destination set</li>
<li>Highlights images without alt tags set</li>
</ul>
<p>You can see an example of an image without an alt tag below, highlighted by the plugin:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/frontend-dev-images.png" rel="prettyphoto[22993]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/frontend-dev-images.png?resize=1025%2C451" alt="frontend-dev-images" class="aligncenter size-full wp-image-23005" /></a></p>
<p>The <a href="http://wordpress.org/plugins/wp-front-end-developer/" target="_blank">Frontend Developer</a> plugin is a useful addition to your toolbox for theme development, as it makes it easy to define styles for various viewport resolutions. <a href="http://wordpress.org/plugins/wp-front-end-developer/" target="_blank">Download</a> it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 May 2014 21:50:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: John Heimkes and Thomas McMahon: So, You Want To Build A Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34742";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.tv/2014/05/17/john-heimkes-and-thomas-mcmahon-so-you-want-to-build-a-theme/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:706:"<div id="v-3kgRuw9F-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34742/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34742/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34742&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/17/john-heimkes-and-thomas-mcmahon-so-you-want-to-build-a-theme/"><img alt="John Heimkes and Thomas McMahon: So, You Want To Build A Theme" src="http://videos.videopress.com/3kgRuw9F/video-989faade13_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 May 2014 18:41:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: John Havlik: One Million Downloads – Lessons Learned Growing a Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34744";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/05/17/john-havlik-one-million-downloads-lessons-learned-growing-a-plugin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:721:"<div id="v-vFVBu7Il-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34744/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34744/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34744&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/17/john-havlik-one-million-downloads-lessons-learned-growing-a-plugin/"><img alt="John Havlik: One Million Downloads – Lessons Learned Growing a Plugin" src="http://videos.videopress.com/vFVBu7Il/video-7d8580def4_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 May 2014 18:05:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Andrey “Rarst” Savchenko: Caching Small Big Things";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35085";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.tv/2014/05/17/rarst-caching-small-big-things/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:636:"<div id="v-4bb3fl9n-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35085/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35085/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35085&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/17/rarst-caching-small-big-things/"><img alt="Rarst-Savchenko-wcch14" src="http://videos.videopress.com/4bb3fl9n/rarst-savchenko-wcch14_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 May 2014 18:05:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Manuel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WPTavern: WPWeekly Episode 148 – Welcome To Miami";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=22984&preview_id=22984";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:138:"http://wptavern.com/wpweekly-episode-148-welcome-to-miami?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-148-welcome-to-miami";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2572:"<p>In this week&#8217;s edition of WordPress Weekly, we were joined by <a href="http://www.davidbisset.com/" title="http://www.davidbisset.com/">David Bisset</a>, one of the many organizers and volunteers that helped put together <a href="http://2014.miami.wordcamp.org/" title="http://2014.miami.wordcamp.org/">WordCamp Miami 2014</a>. Bisset explained the challenges the team faced, the logistics of organizing a 770 attendee event, and he shared advice to WordCamp organizers looking to grow their events.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/more-than-97-of-updates-to-wordpress-3-9-1-were-automatic" title="http://wptavern.com/more-than-97-of-updates-to-wordpress-3-9-1-were-automatic">More Than 97% of Updates to WordPress 3.9.1 Were Automatic</a><br />
<a href="http://wptavern.com/woothemes-continuing-to-investigate-reports-of-fraudulent-activity" title="http://wptavern.com/woothemes-continuing-to-investigate-reports-of-fraudulent-activity">WooThemes Continuing To Investigate Reports Of Fraudulent Activity</a><br />
<a href="http://wptavern.com/the-ability-to-anonymously-complain-about-wordpress-may-soon-disappear" title="http://wptavern.com/the-ability-to-anonymously-complain-about-wordpress-may-soon-disappear">The Ability To Anonymously Complain About WordPress May Soon Disappear</a><br />
<a href="http://wptavern.com/issuepress-now-in-beta-provide-public-support-for-private-github-projects-using-wordpress" title="http://wptavern.com/issuepress-now-in-beta-provide-public-support-for-private-github-projects-using-wordpress">IssuePress Now In Beta: Provide Public Support for Private Github Projects Using WordPress</a><br />
<a href="http://wptavern.com/apppresser-debuts-appbuddy-mobile-app-at-buddycamp-miami" title="http://wptavern.com/apppresser-debuts-appbuddy-mobile-app-at-buddycamp-miami">AppPresser Debuts AppBuddy Mobile App at BuddyCamp Miami</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, May 23rd 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #148:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 May 2014 03:14:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: How To Easily Add Platform Agnostic Favicons To Your WordPress Site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22916";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/how-to-easily-add-platform-agnostic-favicons-to-your-wordpress-site?utm_source=rss&utm_medium=rss&utm_campaign=how-to-easily-add-platform-agnostic-favicons-to-your-wordpress-site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5524:"<p>When we wrote how to <a title="http://wptavern.com/how-to-create-a-platform-agnostic-favicon" href="http://wptavern.com/how-to-create-a-platform-agnostic-favicon">create a platform agnostic favicon</a> with <a title="http://realfavicongenerator.net/" href="http://realfavicongenerator.net/">RealFaviconGenerator</a>, one of the common complaints in the comments was that you needed to add the generated HTML into the HEAD section of the theme in use. This was not ideal since switching themes would cause the favicon images to be lost. Another suggestion was to create a plugin that automatically added the images and code to the appropriate location.</p>
<p><a title="http://profiles.wordpress.org/phbernard/" href="http://profiles.wordpress.org/phbernard/">Philippe Bernard</a> has created and released the <a title="http://wordpress.org/plugins/favicon-by-realfavicongenerator/" href="http://wordpress.org/plugins/favicon-by-realfavicongenerator/">Favicon by RealFaviconGenerator</a> plugin that satisfies both requests. The plugin is simple to install and use. After installation, head on over to the <strong>Appearance menu</strong> and <strong>select Favicon</strong>. You can either choose an image from your hard drive or from the WordPress media library. Make sure it&#8217;s at least <strong>260&#215;260</strong> in size so the smaller images look nice.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/SelectingAFaviconImage.png" rel="prettyphoto[22916]"><img class="aligncenter size-full wp-image-22953" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/SelectingAFaviconImage.png?resize=770%2C285" alt="SelectingAFaviconImage" /></a></p>
<p>After selecting an image, click the <strong>Generate Favicon</strong> button. This will load the RealFaviconGenerator website where you&#8217;ll be able to configure how the icons will look on different devices. You&#8217;ll also be able to configure the scaling algorithm to find a balance between image size and quality.</p>
<div id="attachment_22951" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/FaviconCompressionSettings.png" rel="prettyphoto[22916]"><img class="size-full wp-image-22951" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/FaviconCompressionSettings.png?resize=750%2C449" alt="Favicon Compression Settings" /></a><p class="wp-caption-text">Favicon Compression Settings</p></div>
<p>Once you&#8217;re satisfied with the result, click the <strong>Generate Favicons</strong> button at the bottom. This will generate and move the images into a randomly named directory within the <strong>WP-Content/Uploads</strong> directory. The plugin also adds rules to the htaccess file located within the root directory. The rewrite rules allow the images to be URL rewritten so they appear to be in the root directory, where favicon images are typically located.</p>
<div id="attachment_22972" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/RealFavIconHtaccessEdits.png" rel="prettyphoto[22916]"><img class="size-full wp-image-22972" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/RealFavIconHtaccessEdits.png?resize=910%2C605" alt="Rewrite Rules By RealFaviconGenerator" /></a><p class="wp-caption-text">Rewrite Rules By RealFaviconGenerator</p></div>
<h3>What&#8217;s On The Roadmap?</h3>
<p>Bernard tells me he&#8217;s working on two new features that deal with image regeneration.</p>
<ul>
<li>Regenerate your favicon automatically whenever RealFaviconGenerator is updated (eg. when iOS 8 is released and comes with new icon resolutions).</li>
<li>Remind you to regenerate your favicon when automatic regeneration is not possible (eg. iOS 8 comes with brand new 3D icons that require your attention as a designer).</li>
</ul>
<p>The plugin works as advertised and eliminates the worry of losing the images when switching themes.</p>
<div id="attachment_22952" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/FaviconFinalResult.png" rel="prettyphoto[22916]"><img class="size-full wp-image-22952" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/FaviconFinalResult.png?resize=751%2C454" alt="The Tavern Favicon For All The Major Platforms" /></a><p class="wp-caption-text">The Tavern Favicon For All The Major Platforms</p></div>
<p>Bernard is currently in talks with Matteo Spinelli to see if a collaboration effort can be achieved. Spinelli is the author of the <a title="http://wordpress.org/plugins/official-add-to-homescreen/" href="http://wordpress.org/plugins/official-add-to-homescreen/">Add to Homescreen plugin</a> that allows website owners to <a title="http://wptavern.com/official-wordpress-plugin-for-the-add-to-homescreen-javascript-plugin" href="http://wptavern.com/official-wordpress-plugin-for-the-add-to-homescreen-javascript-plugin">include the add to home screen call-out for mobile devices</a>. The default home screen icon for websites on iOS is not visually appealing. By combining both plugins, site owners can make it easy for mobile visitors to add their site to their home screen while also maintaining consistency in branding.</p>
<p>With so many mobile devices, screen sizes, and operating systems in use, the standard 16&#215;16 .ico file just won&#8217;t cut it anymore. The Favicon plugin by RealFaviconGenerator is an easy, convenient way to look great on mobile platforms with little effort.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 23:09:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Font Awesome Finally Adds WordPress Icon in 4.1 Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=16893";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:118:"http://wptavern.com/font-awesome-wordpress-icon?utm_source=rss&utm_medium=rss&utm_campaign=font-awesome-wordpress-icon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2803:"<p>One thing that was continually irksome about <a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a> icons was the notable absence of a WordPress icon, despite the font having support for Tumblr, Flickr, Github, Instagram, and others. Given that the project is meant to be a comprehensive pictographic language of web-related actions, I was surprised that WordPress, which powers more than 20% of the web, was sadly not represented among the collection.</p>
<p>The good news is that a WordPress icon has finally been added after <a href="https://github.com/FortAwesome/Font-Awesome/issues/221" target="_blank">two years of public demand</a>. Font Awesome 4.1, released this week, added <a href="http://fontawesome.io/whats-new/" target="_blank">71 new icons</a>, including one for WordPress, Reddit, CodePen, Drupal, Joomla, Spotify, and others.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/font-awesome-wordpress.jpg" rel="prettyphoto[16893]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/font-awesome-wordpress.jpg?resize=826%2C415" alt="font-awesome-wordpress" class="aligncenter size-full wp-image-22941" /></a></p>
<p>Font Awesome, originally created by Dave Gandy, is an <a href="http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL" target="_blank">SIL OFL</a>-licensed icon font, with the CSS, LESS, and SASS files under the MIT License. It was originally designed for use with Bootstrap, which helped it to become popular, but was soon widely used outside of Bootstrap-based projects.</p>
<p>Now that a WordPress icon is included, the font will become even more useful for developers writing plugins and themes that make use of the icons. Some WordPress users have even requested <a href="https://github.com/FortAwesome/Font-Awesome/issues/2720" target="_blank">WordPress post format icons</a> to be added to a future release. This could potentially be very useful for theme developers but may not gain enough traction.</p>
<p>The WordPress Plugin Directory already contains many <a href="http://wordpress.org/plugins/search.php?q=font+awesome" target="_blank">pages</a> worth of extensions that use Font Awesome in some shape or form. Plugin authors find the collection to be especially handy because of its wide range of icons and the fact that the icons are retina-ready and infinitely scalable. The font also comes with its own free CDN. The <a href="http://www.bootstrapcdn.com/#fontawesome_tab" target="_blank">BootstrapCDN for Font Awesome</a>, hosted by MaxCDN, is free for anyone to use. If you&#8217;re using a WordPress plugin that uses Font Awesome and you want to take advantage of its 71 newest icons, make sure to prompt the plugin&#8217;s developer to update the collection to 4.1.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 22:21:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WPTavern: IssuePress Now In Beta: Provide Public Support for Private Github Projects Using WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22883";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:242:"http://wptavern.com/issuepress-now-in-beta-provide-public-support-for-private-github-projects-using-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=issuepress-now-in-beta-provide-public-support-for-private-github-projects-using-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5730:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress-featured.jpg" rel="prettyphoto[22883]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress-featured.jpg?resize=1025%2C485" alt="issuepress-featured" class="aligncenter size-full wp-image-22896" /></a></p>
<p><a href="https://twitter.com/chriswallace" target="_blank">Chris Wallace</a> and his team at <a href="https://upthemes.com/" target="_blank">UpThemes</a> have just pushed their new <a href="http://issuepress.co/" target="_blank">IssuePress</a> plugin into private beta. This innovative new product is will make it possible for developers to provide public support for private Github repositories.</p>
<p>The plugin allows you to assign a dedicated support page on your WordPress site where customers can create and comment on issues. This data is then synced up using the <a href="https://developer.github.com/v3/issues/" target="_blank">Github Issues API</a> so that developers can work in Github without having to switch back and forth between support queues.</p>
<p>Linking up a Github project and support page is as easy as entering your Github Token and selecting an existing WordPress page. The app also has support for multiple repositories:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress.jpg" rel="prettyphoto[22883]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress.jpg?resize=778%2C534" alt="issuepress" class="aligncenter size-full wp-image-22892" /></a></p>
<h3>Streamlining Support for Developers and Customers</h3>
<p>Developers remain free to support their code purely via Github issues but will still have access to the full picture of customer support as the issues queue is synced both ways.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress-support.jpg" rel="prettyphoto[22883]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/issuepress-support.jpg?resize=393%2C296" alt="issuepress-support" class="alignright size-full wp-image-22899" /></a>Support conversations happen on the frontend of WordPress without customers having to venture into &#8220;developer territory&#8221; on Github in order to log issues. They will receive (near) real-time updates on relevant support issues and will be able to search through other issues customers may have already inquired about.</p>
<h3>Cutting Out the Middle Man</h3>
<p>Wallace and his team are hoping to eliminate the need for third-party hosted support apps that so many developers rely on to make issue logging approachable for customers. Unfortunately, those apps often pull developers out of their workflow, force them to consult multiple queues and then aggregate all of those issues in Github.</p>
<p>IssuePress solves this problem by allowing both customers and developers to participate in support in the environments where they are the most comfortable, while providing automated updates to keep everyone in the loop.</p>
<p>This plugin lessens the need for support staff to interface between customers and developers to keep both parties updated on the status of issues as they relate to current and future development on the project. Customers can easily see if their issues will be fixed in the next release. Support staff can focus on answering questions and leave the trickier software bugs to the development team.</p>
<h3>How Does IssuePress Work?</h3>
<p>This isn&#8217;t your average support plugin. IssuePress is composed of server-side API bindings and a client-side single page application powered by Angular.js. The main app is located in /src/app/ directory of the plugin, though the structure will still be in flux throughout the beta period. The <a href="http://issuepress.co/docs/issuepress-works/" target="_blank">IssuePress documentation</a> breaks down the app&#8217;s main components and details its server-side functionality:</p>
<ul>
<li>IssuePress creates custom API endpoints that fetch, cache and serve data from the GitHub API. The IssuePress API is outlined in the IP_api.php file.</li>
<li>IssuePress also creates an object cache that utilizes WordPress transients.</li>
</ul>
<p>If you&#8217;re interested in learning more about creating applications that work with WordPress, the <a href="http://issuepress.co/docs/issuepress-works/" target="_blank">IssuePress documentation</a> is a nice resource to explore.</p>
<h3>Customizing the App</h3>
<p>Customizing the core IssuePress plugin is not recommended at this time as it&#8217;s still in the very early stages of beta testing. The team is working on making it easy to hook into IssuePress so that developers can customize it without editing core files. Once the app has further advanced on its roadmap, you&#8217;ll be able to customize your IP styles, edit the Angular templates and edit the IssuePress API.</p>
<p>The team is conscious of providing a solid mobile experience and is exploring the possibility of creating a native IssuePress app for iOS and/or Android via AppPresser. This would make it possible for customers to receive push notifications for updates on issues they are following.</p>
<p>I spoke with Chris Wallace who is aiming to get IssuePress launched by the end of the summer. <strong>&#8220;We&#8217;re hoping to conduct the beta over the next two months and release the paid version sometime in August,&#8221;</strong> he said. If you want to get in on the beta testing, be aware that the app is still under active development and is likely to change quite a bit over the next few months. Sign up at <a href="http://issuepress.co/" target="_blank">IssuePress.co</a> to download the beta and subscribe to updates.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 18:30:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: Why BuddyPress and bbPress Themes Don’t Exist";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22894";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:152:"http://wptavern.com/why-buddypress-and-bbpress-themes-dont-exist?utm_source=rss&utm_medium=rss&utm_campaign=why-buddypress-and-bbpress-themes-dont-exist";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3125:"<p>At <a title="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event" href="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event">BuddyCamp Miami 2014</a>, I learned about BuddyPress and what it&#8217;s capable of. During the first session, I learned you don&#8217;t have to worry about BuddyPress themes anymore since <a title="http://codex.buddypress.org/themes/theme-compatibility-1-7/a-quick-look-at-1-7-theme-compatibility/" href="http://codex.buddypress.org/themes/theme-compatibility-1-7/a-quick-look-at-1-7-theme-compatibility/">1.7 introduced theme compatibility</a>. This means that BuddyPress sites no longer require a BuddyPress-specific theme.</p>
<p>Later in the day, there was a session devoted to <strong>BuddyPress Theme Do&#8217;s and Don&#8217;ts by Tammie Lister</strong>. Considering BuddyPress no longer needs specific themes, I was confused and frustrated by the session.</p>
<h3>BuddyPress Themes Are WordPress Themes</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/WPBP.png" rel="prettyphoto[22894]"><img class="alignright size-full wp-image-22907" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/WPBP.png?resize=237%2C148" alt="WordPress BuddyPress" /></a>Since BuddyPress is a plugin, it needs WordPress in order to function. It has elements that are supported by default in most WordPress themes. Since BuddyPress is not its own entity, neither are BuddyPress themes. BuddyPress themes are just WordPress themes with built in support for the style elements.</p>
<p>So if I install a <em>BuddyPress theme</em> into WordPress, I&#8217;m actually installing a WordPress theme. Perhaps it&#8217;s semantics but they are important to me for understanding how things work. The same could be said for bbPress which is also a plugin that has style elements that are supported by WordPress themes.</p>
<h3>BuddyPress and bbPress Themes Don&#8217;t Exist</h3>
<p>After speaking with a few attendees that were at both sessions, they understood my confusion and frustration. I&#8217;ve concluded that bbPress and BuddyPress themes don&#8217;t exist. They are WordPress themes, some with better support for bbPress and BuddyPress elements than others.</p>
<p>Also note that BuddyPress.org <a title="https://buddypress.org/extend/themes/" href="https://buddypress.org/extend/themes/">no longer</a> has a theme directory. Instead, you&#8217;re instructed to look for <a title="http://wordpress.org/themes/tags/buddypress" href="http://wordpress.org/themes/tags/buddypress">BuddyPress compatible themes</a> on the WordPress theme directory. This is why it&#8217;s important for theme authors to <a title="http://wptavern.com/why-wordpress-theme-authors-still-need-to-specify-buddypress-compatibility" href="http://wptavern.com/why-wordpress-theme-authors-still-need-to-specify-buddypress-compatibility">specifically state</a> whether their WordPress themes support BuddyPress and bbPress.</p>
<p>If you think I&#8217;m wrong in my assessment, I invite you to explain why in the comments below.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 17:58:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WP Android: WordPress for Android: No Longer Paying the Gingerbread Tax";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://android.wordpress.org/?p=1037";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://android.wordpress.org/2014/05/16/wordpress-for-android-no-longer-paying-the-gingerbread-tax/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2432:"<p><img class="alignright wp-image-1055" src="https://wpandroid.files.wordpress.com/2014/05/gingerbread-man1.png?w=200&h=200" alt="gingerbread-man" width="200" height="200" />Way back in 2011 Google released <a href="http://www.android.com/about/ice-cream-sandwich/">Android 4.0</a> (&#8220;Ice Cream Sandwich&#8221;), a major update that substantially improved the platform both for developers and for end users. This left developers with a problem: how do they take advantage of all the new features without leaving users of older devices stranded?</p>
<p>For most developers the answer has been to support both older and newer devices. This requires a <strong>lot</strong> of work, but it&#8217;s worth it when it means many more people can use your software.</p>
<p>The downside is this approach slows development, resulting in longer delays between releases. It also means developers sometimes don&#8217;t take advantage of the latest Android features, because doing so requires more time and testing to make sure the app continues to work on older devices.</p>
<p>We&#8217;ve followed this approach for quite a while with WordPress for Android, supporting everything from the latest devices to ones running Android 2.3 (&#8220;Gingerbread&#8221;). At the same time we&#8217;ve been seeing the usage of our app decline on Gingerbread, to the point that it&#8217;s now less than 10%.</p>
<p>This means over 90% of our users are paying a &#8220;Gingerbread tax&#8221; &#8211; waiting longer for new versions and not seeing features that take advantage of their phones &#8211; so that we can continue supporting older devices.</p>
<p>We&#8217;ve decided to abolish this tax. Starting with version 2.9 of WordPress for Android &#8211; due later this month &#8211; new versions will only support devices running Android 4.0 or later. If you&#8217;re using an older phone, the previous version of our app will still appear in Google Play and you&#8217;ll still be able to use it.</p>
<p>We&#8217;ll be honest: our developers &#8211; including myself &#8211; are happy about this because it&#8217;ll make us more productive. But the thing we&#8217;re the happiest about is that it will result in a faster, smaller, better app for the large majority of our users.</p><img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=android.wordpress.org&blog=9426921&post=1037&subd=wpandroid&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 17:15:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Nick Bradbury";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WordPress.tv: Paolo Belcastro: Around The World 80 Times Per Day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34716";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.tv/2014/05/16/paolo-belcastro-around-the-world-80-times-per-day/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-TAvsImpY-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34716/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34716/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34716&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/16/paolo-belcastro-around-the-world-80-times-per-day/"><img alt="Paolo Belcastro: Around The World 80 Times Per Day" src="http://videos.videopress.com/TAvsImpY/paolo-belcastro-wcch14_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 10:00:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Stephanie Booth: Blogging In An Imperfectly Multilingual World";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34830";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wordpress.tv/2014/05/16/stephanie-booth-blogging-in-an-imperfectly-multilingual-world/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:707:"<div id="v-PZroqJuV-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34830/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34830/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34830&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/16/stephanie-booth-blogging-in-an-imperfectly-multilingual-world/"><img alt="Stephanie Booth: Blogging In An Imperfectly Multilingual World" src="http://videos.videopress.com/PZroqJuV/video-c4bc329be6_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 10:00:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WordPress.tv: Konstantin Obenland: Behind The Scenes Of The WordPress.com Theme Showcase";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34759";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wordpress.tv/2014/05/16/konstantin-obenland-behind-the-scenes-of-the-wordpress-com-theme-showcase/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:741:"<div id="v-x50xkt0e-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34759/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34759/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34759&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/16/konstantin-obenland-behind-the-scenes-of-the-wordpress-com-theme-showcase/"><img alt="Konstantin Obenland: Behind The Scenes Of The WordPress.com Theme Showcase" src="http://videos.videopress.com/x50xkt0e/konstantin-obenland-wcch14_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 10:00:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WordPress.tv: Silvan Hagen: Multisite On A Tight Budget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34764";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2014/05/16/silvan-hagen-multisite-on-a-tight-budget/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:662:"<div id="v-h9wCjoC1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34764/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34764/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34764&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/16/silvan-hagen-multisite-on-a-tight-budget/"><img alt="Silvan Hagen: Multisite On A Tight Budget" src="http://videos.videopress.com/h9wCjoC1/silvan-hagen-wcch14_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 10:00:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WordPress.tv: Beth Backen: How (and why) to Create a Child Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34556";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.tv/2014/05/15/beth-backen-how-and-why-to-create-a-child-theme-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:683:"<div id="v-f5snPda0-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34556/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34556/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34556&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/15/beth-backen-how-and-why-to-create-a-child-theme-2/"><img alt="Beth Backen: How (And Why) To Create A Child Theme" src="http://videos.videopress.com/f5snPda0/video-aa7a8e7b14_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 May 2014 02:34:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WordPress.tv: Kyle Unzicker: Back To Square One: Building A WordPress Starter Development Kit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34670";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wordpress.tv/2014/05/15/kyle-unzicker-back-to-square-one-building-a-wordpress-starter-development-kit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:740:"<div id="v-EPjHRrU4-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34670/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34670/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34670&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/15/kyle-unzicker-back-to-square-one-building-a-wordpress-starter-development-kit/"><img alt="Kyle Unzicker: Back To Square One: Building A WordPress Starter Development Kit" src="http://videos.videopress.com/EPjHRrU4/video-e5e7796a4e_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 18:54:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Joe Dolson: Presenting Accessible Video In WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34668";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2014/05/15/joe-dolson-presenting-accessible-video-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-ZpIRn7ZZ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34668/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34668/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34668&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/15/joe-dolson-presenting-accessible-video-in-wordpress/"><img alt="Joe Dolson: Presenting Accessible Video In WordPress" src="http://videos.videopress.com/ZpIRn7ZZ/video-fc70952410_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 18:39:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WordPress.tv: Cory Miller: WordCamp Dayton Keynote";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34648";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2014/05/15/cory-miller-wordcamp-dayton-keynote/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:649:"<div id="v-Av4tkJnD-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34648/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34648/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34648&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/15/cory-miller-wordcamp-dayton-keynote/"><img alt="Cory Miller: WordCamp Dayton Keynote" src="http://videos.videopress.com/Av4tkJnD/video-30cacfc575_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 18:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: CSS3 Lightbox Plugin for WordPress: Pure CSS, Super Fast and Mobile Friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22662";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:212:"http://wptavern.com/css3-lightbox-plugin-for-wordpress-pure-css-super-fast-and-mobile-friendly?utm_source=rss&utm_medium=rss&utm_campaign=css3-lightbox-plugin-for-wordpress-pure-css-super-fast-and-mobile-friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1859:"<p>Lightboxes are generally built using Javascript, but depending on the author/version/script, lightbox plugins can sometimes cause conflicts with other plugins and themes when used with WordPress.</p>
<p><a href="http://wordpress.org/plugins/css3lightbox/" target="_blank">CSS3 Lightbox</a> is the first lightbox plugin for WordPress that is powered purely by CSS3, making it super fast and lightweight. It doesn&#8217;t require any Javascript whatsoever and provides a beautiful experience on mobile.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/lightbox.png" rel="prettyphoto[22662]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/lightbox.png?resize=900%2C604" alt="lightbox" class="aligncenter size-full wp-image-22861" /></a></p>
<h3>How does the CSS3 Lightbox plugin work?</h3>
<p>The plugin parses all your images in your content and creates some specific classes which are called from a CSS file. It then uses browser native CSS3 functionality to display images in a lightbox, which makes it faster than any Javascript lightbox plugin out there.</p>
<p>You can test out a demo of the CSS3 lightbox by clicking on the image in the post on the <a href="http://www.mashshare.net/mash-networks-addon/" target="_blank">demo page</a>.</p>
<p>The CSS3 Lightbox plugin currently works with any embedded image in WordPress content. The plugin&#8217;s author is working to make it compatible with gallery images, a feature that will be added in its next release. There&#8217;s nothing more annoying than staring at a loading image, waiting for a Javascript-powered lightbox to load. The delay may even cause visitors to leave the page and navigate away from your site. Check out the <a href="http://wordpress.org/plugins/css3lightbox/" target="_blank">CSS3 Lightbox</a> plugin for a much faster alternative.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 May 2014 15:18:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: Pictorico: A Free WordPress Theme for Portfolios and Photoblogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22827";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:188:"http://wptavern.com/pictorico-a-free-wordpress-theme-for-portfolios-and-photoblogs?utm_source=rss&utm_medium=rss&utm_campaign=pictorico-a-free-wordpress-theme-for-portfolios-and-photoblogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2232:"<p><a href="http://wordpress.org/themes/pictorico" target="_blank">Pictorico</a> is a new free theme for self-hosted WordPress sites, created by the team at Automattic. While many themes in the WordPress Themes Directory lean toward the blog flavor, this one is geared toward portfolios and photoblogging websites.</p>
<p>Pictorico is a single-column, grid-based theme that includes a post slider and looks its best with large featured images set for the posts.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png" rel="prettyphoto[22827]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png?resize=880%2C660" alt="pictorico" class="aligncenter size-full wp-image-22830" /></a></p>
<p>The theme includes four widget areas in the footer and can be further customized with a Custom Header and Background. It also has support for Sticky Posts and Post Formats, including: Aside, Image, Video, Link, and Quote.</p>
<p>Pictorico is one theme that you don&#8217;t want to use without featured images, which are best displayed at a minimum of 1180px wide. It makes use of them on the blog index, archive pages, and single post page (if a custom header hasn&#8217;t been set). In the absence of a featured image, it will display a solid background color instead.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/solid-bakcground.png" rel="prettyphoto[22827]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/solid-bakcground.png?resize=1025%2C271" alt="solid-bakcground" class="aligncenter size-full wp-image-22837" /></a></p>
<p>Check out a <a href="http://pictoricodemo.wordpress.com/" target="_blank">live demo</a> to see the theme in action with big featured images. It also includes posts with no featured images set, so you can preview that scenario.</p>
<p>You may have already seen Pictorico around the web, as it was originally released on WordPress.com a couple weeks ago. This is Automattic&#8217;s 44th free theme added to its collection on WordPress.org. Test <a href="http://wordpress.org/themes/pictorico" target="_blank">Pictorico</a> out first hand by  installing it via the theme browser in your WordPress admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 18:50:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Jenny Munn: Content Marketing Workshop: How To Plan, Optimize And Analyze Your Efforts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34814";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:115:"http://wordpress.tv/2014/05/14/jenny-munn-content-marketing-workshop-how-to-plan-optimize-and-analyze-your-efforts/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:747:"<div id="v-TtS6DqjM-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34814/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34814/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34814&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/14/jenny-munn-content-marketing-workshop-how-to-plan-optimize-and-analyze-your-efforts/"><img alt="Jenny Munn: Content Marketing Workshop: How To Plan, Optimize And Analyze Your Efforts" src="http://videos.videopress.com/TtS6DqjM/video-d498f2c8f6_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 18:33:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Russell Fair: Rockin’ Local Development With Vagrant";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34809";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/05/14/russell-fair-rockin-local-development-with-vagrant/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:682:"<div id="v-njzNg7tf-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34809/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34809/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34809&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/14/russell-fair-rockin-local-development-with-vagrant/"><img alt="Russell Fair: Rockin’ Local Development With Vagrant" src="http://videos.videopress.com/njzNg7tf/video-f14f2b8139_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 18:30:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: Travis Smith: Understanding My Site’s SEO: SEO Essentials And Helpful Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34825";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wordpress.tv/2014/05/14/travis-smith-understanding-my-sites-seo-seo-essentials-and-helpful-tools/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:727:"<div id="v-BncSIs75-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34825/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34825/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34825&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/14/travis-smith-understanding-my-sites-seo-seo-essentials-and-helpful-tools/"><img alt="Travis Smith: Understanding My Site’s SEO: SEO Essentials And Helpful Tools" src="http://videos.videopress.com/BncSIs75/video-2a6f279911_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 18:26:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: WP Ninjas Launch Ninja Demo: A Complete Demo Solution for WordPress Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22672";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/wp-ninjas-launch-ninja-demo-a-complete-demo-solution-for-wordpress-products?utm_source=rss&utm_medium=rss&utm_campaign=wp-ninjas-launch-ninja-demo-a-complete-demo-solution-for-wordpress-products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6820:"<p>When the <a href="http://wpninjas.com/" target="_blank">WP Ninjas</a> launched Ninja Forms in 2010, many people dismissed the plugin, saying there was no way it would be able to compete with Gravity Forms, the dominant commercial product in that space.</p>
<p>Fast forward two years, and <a href="http://wordpress.org/plugins/ninja-forms/" target="_blank">Ninja Forms</a> is now being downloaded over 34,000 times every month from WordPress.org. WP Ninjas has just under 6,000 customers who have purchased one or more of their 28 add-ons. Ninja Forms alone is now a $28,000+ a month business and the Ninjas are setting out on a new adventure with the launch of <a href="http://ninjademo.com/" target="_blank">Ninja Demo</a> this week.</p>
<p>WordPress products of all kinds will often require a live demo, but so far there is no easy way to create and maintain demo sites for potential customers.</p>
<p>Ninja Demo aims to address this need by providing a complete demo solution that includes access restrictions, isolated sandboxes, automated cleanup, user role control, easy content updating, and more. The WP Ninjas are the first ones in the WordPress community to tackle this problem with a convenient solution.</p>
<h3>Identifying the Need for Better WordPress Product Demos</h3>
<div id="attachment_22814" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/sandbox.png" rel="prettyphoto[22672]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/sandbox.png?resize=1023%2C493" alt="photo credit: hiljainenmies - cc" class="size-full wp-image-22814" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/hiljainenmies/3580475943/">hiljainenmies</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a></p></div>
<p><a href="http://twitter.com/jameslaws" target="_blank">James Laws</a>, who partners with <a href="https://twitter.com/kstover" target="_blank">Kevin Stover</a> to form WP Ninjas, said that their experience with Ninja Forms was a source of inspiration for Ninja Demo. &#8220;Our own demo for Ninja Forms was causing us a lot of grief,&#8221; he said. <strong>&#8220;The content was getting out of date, and updating it was such a circus act that we had a hard time feeling motivated. So the demo remained out of date.&#8221;</strong></p>
<p>The second major problem they had is one that is quite common among WordPress product demos:</p>
<blockquote><p>Users were stepping on each other&#8217;s toes because they were all working with the same content. Five users trying to modify the same product settings at the same time pretty much ensured it didn&#8217;t work for any of them. This makes the product look buggy, or worse, broken from their perspective. That wasn&#8217;t good for business.</p></blockquote>
<p>They decided to research to find a better solution but their efforts were futile. The Ninjas discovered that nearly everyone was clumsily creating their own demo sites from spare parts:</p>
<blockquote><p>Almost every WordPress demo was set up exactly like ours: content restoration on an interval, spaghetti code, and plugins to accomplish restrictions and other functionality. We decided the community deserved better than that.</p></blockquote>
<p>Ninja Demo was born to unify all the disparate code that was previously slapped together to create demo sites.</p>
<h3>Ninja Demo Uses Multisite and the WordPress Heartbeat API to Create Demo Sites</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/heartbeat.jpg" rel="prettyphoto[22672]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/heartbeat.jpg?resize=945%2C331" alt="heartbeat" class="aligncenter size-full wp-image-22817" /></a></p>
<p>The architecture behind Ninja Demo is mostly custom built, with a little borrowed code from the NS Cloner plugin to help with the sandbox-creation. Ninja Demo is fully self contained, but it can also be extended with other plugins and the team plans to start releasing <a href="http://ninjademo.com/addons/" target="_blank">enterprise add-ons</a>, such as reporting, within the next two or three weeks.</p>
<p>In the past, many people used plugins that would back up the demo site and restore it at an interval, but Laws and Stover found that these plugins still suffer from the problem of every user working with the same content at the same time. All changes are lost once the backup interval comes around.</p>
<p>Ninja Demo tackles the problem by making use of the multisite functionality in WordPress. &#8220;You set up everything that you want to run on your demo site as the main site within the network,&#8221; Laws explained. &#8220;Then, when a user goes to try out your demo, Ninja Demo will create another site which is an exact duplicate of the main site. We call these sandboxes.&#8221;</p>
<p>Each sandbox is only visible to the specific user and Laws detailed for us how Ninja Demo is able to automatically create and remove sandboxes using the WordPress Heartbeat API:</p>
<blockquote><p>The other great thing is that this sandbox remains alive as long as the user keeps it open in their browser. Using the WordPress heartbeat API, we check to see if the sandbox is still &#8220;active&#8221; and as long as it is, it remains available. Once the user leaves the demo or closes their browser, Ninja Demo will start the expiration process and the sandbox will be deleted within the hour. This means no mess is ever left behind, and the database is kept lean and clean.</p></blockquote>
<p>Essentially, Ninja Demo is programmed to clean up after itself so it won&#8217;t bloat your demo site into a horrible monster. This unique solution makes use of functionality that is already built into WordPress. For live examples you can view the <a href="http://ninjademo.com/directory/" target="_blank">directory</a> of products that are already utilizing Ninja Demo.</p>
<h3>The Future of Ninja Demo</h3>
<p>While the WordPress product market is increasing, those in need of demo sites are still a very small segment compared to Ninja Forms&#8217; much larger reach. Nevertheless, the WP Ninjas have big plans to launch the Reporting, Marketing and Guided Tours add-ons for demo sites before the end of the year. &#8220;Our hope is that these add-ons will make Ninja Demo so much more than a demo plugin and turn it into a tool to make WordPress products better,&#8221; Laws said.</p>
<p>WP Ninjas is primarily a WordPress plugin development shop but they plan to add a few SAAS products in the future and will continue to release more plugins. &#8220;We love WordPress and the community,&#8221; Laws told the Tavern. &#8220;So as long as we can create products the community loves and uses, we will keep innovating.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 16:34:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: The Ability To Anonymously Complain About WordPress May Soon Disappear";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22774";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:204:"http://wptavern.com/the-ability-to-anonymously-complain-about-wordpress-may-soon-disappear?utm_source=rss&utm_medium=rss&utm_campaign=the-ability-to-anonymously-complain-about-wordpress-may-soon-disappear";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3850:"<p>Kvetch is a Yiddish word <a title="http://www.answers.com/topic/kvetch" href="http://www.answers.com/topic/kvetch">defined</a> as a nagging complaint. <a title="http://wordpress.org/news/2007/01/ideas-and-kvetch/" href="http://wordpress.org/news/2007/01/ideas-and-kvetch/">Introduced to WordPress.org in 2007</a>, the kvetch form provided users an opportunity to anonymously tell developers what it was about WordPress that ticked them off. Each time the page is refreshed, a new entry is displayed. If you read several of the submissions, it becomes clear that the complaints are from a by-gone era of WordPress history.</p>
<div id="attachment_22780" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/KvetchSubmissionScreen.png" rel="prettyphoto[22774]"><img class="size-full wp-image-22780" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/KvetchSubmissionScreen.png?resize=855%2C664" alt="The Kvetch Submission Screen" /></a><p class="wp-caption-text">The Kvetch Submission Screen</p></div>
<p>It&#8217;s funny to read some of the responses and know that the current version of WordPress has many of the features users griped about not having a few years ago, such as auto updates.  Take these entries for example:</p>
<ul>
<li>“Must have auto-save!”</li>
<li>&#8220;Matt can just delete things from core without debating it on the mailing list for no clear reason, whereas it takes a lot of time and effort to get anything into core, even with a clear and needed reason.&#8221;</li>
<li>“Updates are too hard to install. I get scared that I will delete everything or something will go wrong. So I don&#8217;t bother. Then I feel guilty. Then I get scared someone will break through the vulnerability in my old edition and delete everything. So I get scared. Either way I&#8217;m scared. Make me less scared. Make updates easier to install/ auto install and have a back-up wizzy-hoop feature.”</li>
</ul>
<p>Eleven months ago, Drew Jaynes <a title="https://meta.trac.wordpress.org/ticket/13" href="https://meta.trac.wordpress.org/ticket/13">submitted a ticket</a> to Meta trac suggesting context be added to kvetch entries. The context would consist of the WordPress version number being complained about and the date of submission. Samuel Sidler <a title="https://meta.trac.wordpress.org/ticket/13#comment:4" href="https://meta.trac.wordpress.org/ticket/13#comment:4">responded to the ticket</a> with information provided by Scott Reilly.</p>
<p>According to Reilly, only <strong>147 entries</strong> were approved to be displayed on the site. The entries were from <strong>January 9th, 2007</strong> to <strong>January 11th, 2007</strong>. Meanwhile, the queue contained <strong>31k</strong> entries not approved, <strong>4k</strong> of which were from the last six months. After sharing the data, Sidler recommended that the ability to kvetch be retired.</p>
<h3>I Still Think It&#8217;s A Good Idea</h3>
<p>Being able to anonymously gripe about WordPress is a great idea. I understand the desire to possibly remove kvetch from WordPress.org but I think it would have provided some interesting data had it been maintained over the years. It was an easy way to discover pain points users were experiencing with WordPress. Sure, there are ways that data can be discovered now thanks to Twitter, forums, and blog posts but it&#8217;s not the same.  Then again, there was no guarantee that submissions would be read and addressed anyways.</p>
<h3>What Do You Think?</h3>
<p>Is it time to remove kvetching from WordPress.org? Have you ever submitted a complaint through the form? Can you remember what it was about WordPress that upset you so much? Tell us about the one thing in WordPress that ticks you off, using the comments below, but <strong>keep it clean!</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 14:52:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WooThemes Continuing To Investigate Reports Of Fraudulent Activity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22766";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/woothemes-continuing-to-investigate-reports-of-fraudulent-activity?utm_source=rss&utm_medium=rss&utm_campaign=woothemes-continuing-to-investigate-reports-of-fraudulent-activity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4526:"<p><a title="http://www.woothemes.com/2014/05/important-info-for-woothemes-customers/" href="http://www.woothemes.com/2014/05/important-info-for-woothemes-customers/">WooThemes is continuing to investigate</a> a handful of reports of fraudulent activity on customers&#8217; credit card accounts. The company worked with <a title="http://sucuri.net/" href="http://sucuri.net/">Sucuri</a> who conducted a code audit and discovered three modified files on their server pointing toward an attack. WooThemes has <a title="http://www.woothemes.com/2014/05/important-update/" href="http://www.woothemes.com/2014/05/important-update/">published a blog post</a> explaining the steps they&#8217;ve taken to prevent this incident from occurring in the future.</p>
<p>Mark Forrester made it clear in the announcement that the company <strong>doesn&#8217;t</strong> store any credit card details on the site, nor does WooCommerce, which increases the difficulty in identifying the problem. Although many of the reports are from customers who have made a purchase within the last 8 days, cards that were used in January have also been reported as compromised.</p>
<div id="attachment_22769" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WooThemesCreditCardFeaturedImage.png" rel="prettyphoto[22766]"><img class="size-full wp-image-22769" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WooThemesCreditCardFeaturedImage.png?resize=636%2C297" alt="WooThemes Credit Card Featured Image" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/68751915@N05/6355848263/">401(K) 2013</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a></p></div>
<p>Some customers are experiencing upwards of $10,000 in fraudulent activity. In a <a title="http://www.reddit.com/r/Wordpress/comments/25dz83/are_we_just_going_to_forget_the_woothemes_leak/" href="http://www.reddit.com/r/Wordpress/comments/25dz83/are_we_just_going_to_forget_the_woothemes_leak/">recent thread on Reddit</a>, some questioned whether WooThemes is trying to sweep this attack under the rug. Forrester said they understand the community&#8217;s frustration and are frustrated as a company as this was a criminal attack on their business. He also went on to say:</p>
<blockquote><p>We really hope the general opinion is not that we are quietly avoiding this, and hoping it will blow over. We&#8217;ve been as forthcoming with information as we can be at this stage. We&#8217;ve answered as many press questions as we can, and we&#8217;ve updated our blog post with any new information as we get it.</p>
<p>There are many parts to this puzzle, many service providers, and many investigations internally and with authorities and financial institutions. Pointing fingers without supporting evidence is dangerous. We accept the fact that if you hadn&#8217;t shopped at WooThemes this would have probably not happened to you, and that makes us really sad. Our brand is known for excellent customer service, and this does not gel with that mantra.</p>
<p>We hope to bounce back stronger, but we realize we might lose some customer&#8217;s confidence along the way.</p></blockquote>
<p>As a precautionary measure, WooThemes has reset their customer&#8217;s passwords. So far, 1,000 cases of fraudulent activity have been reported with reports drastically slowing down since May 9th.</p>
<h3>This Is Not The First Time WooThemes Has Had Security Troubles</h3>
<p>Two years ago almost to the day, <a title="http://www.woothemes.com/2012/04/were-alive-and-kicking/" href="http://www.woothemes.com/2012/04/were-alive-and-kicking/">WooThemes suffered a major attack</a> that took out their database as well as the content on their server. The backups were deleted as were traces of the attack. The details regarding the attack were never published although the company said they would be, &#8220;Long story short, as we’ll save the juicy details for another blog post&#8221;.</p>
<p>Although WooThemes has done a good job keeping everyone informed about this latest security problem via their blog, they&#8217;ll need to explain to the public what happened in order to help customers regain confidence in doing business with them.</p>
<h3>What Should You Do?</h3>
<p>Customers should keep an eye on their credit card statements and report fraudulent activity to their financial institution. You should also contact WooThemes so they can add the report to their investigation.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 14:46:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"WPTavern: Recap Of WordCamp Miami 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22705";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://wptavern.com/recap-of-wordcamp-miami-2014?utm_source=rss&utm_medium=rss&utm_campaign=recap-of-wordcamp-miami-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11999:"<p>With 770 attendees, <a title="http://2014.miami.wordcamp.org" href="http://2014.miami.wordcamp.org">WordCamp Miami</a> is one of the largest WordCamps in the US. WordCamp Miami was comprised of three seperate events. <a title="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event" href="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event">BuddyCamp</a>, a <a title="http://2014.miami.wordcamp.org/wordcamp-miami-beginners-workshops/" href="http://2014.miami.wordcamp.org/wordcamp-miami-beginners-workshops/">WordPress Beginner&#8217;s Workshop</a>, and a <a title="http://2014.miami.wordcamp.org/wordcamp-miami-kids-workshop/" href="http://2014.miami.wordcamp.org/wordcamp-miami-kids-workshop/">Workshop for Kids</a>. With over 40 speakers and three tracks, there was a wide range of topics for users, designers, and developers.</p>
<h3>BuddyCamp Miami 2014</h3>
<p>Sessions were devoted to both BuddyPress and bbPress and was the first opportunity I&#8217;ve had to really learn what BuddyPress has to offer. I was hoping to see more information devoted to bbPress but I understand why there weren&#8217;t more sessions dedicated to the topic. After seeing a demo of BuddyPress and what it&#8217;s capable of doing, I&#8217;m pondering how we could leverage its feature set on WPTavern.</p>
<div id="attachment_22708" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PackedHouseForBuddyCamp.jpg" rel="prettyphoto[22705]"><img class="size-full wp-image-22708" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PackedHouseForBuddyCamp.jpg?resize=800%2C600" alt="Packed House For BuddyCamp" /></a><p class="wp-caption-text">Packed House For BuddyCamp</p></div>
<p>Both BuddyCamp and the WordPress Beginner&#8217;s Workshop rooms were filled to capacity. If you&#8217;d like to know more about BuddyCamp, Sarah Gooding has an <a title="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event" href="http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event">excellent review</a> online, including links to presentation slides.</p>
<h3>WordCamp Miami 2014 Day One</h3>
<p>Each session room was filled with people eager to learn. I spent most of my time networking and chatting with attendees and most of them were of the opinion that WordCamp Miami was a great event.</p>
<div id="attachment_22710" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/PodcastingRoundtable.jpg" rel="prettyphoto[22705]"><img class="size-full wp-image-22710" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/PodcastingRoundtable.jpg?resize=800%2C600" alt="Attendees Learning About Podcasting With WordPress" /></a><p class="wp-caption-text">Attendees Learning About Podcasting With WordPress</p></div>
<p>At the end of day one, I participated in a roundtable discussion on the subject of podcasting with WordPress. It was neat to see so many people interested in the subject. I spoke with a few people after the session who were just getting started and it was a pleasure to see their faces light up after I helped steer them in the right direction. It was great to see Suzette Franck of the <a title="http://wpunicornproject.com/" href="http://wpunicornproject.com/">WP Unicorn Project</a> on the panel as it proved that WordPress podcasting <strong>does not</strong> have to be a male dominated activity.</p>
<div id="attachment_22711" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/MyPodcastingAward.jpg" rel="prettyphoto[22705]"><img class="size-full wp-image-22711" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/MyPodcastingAward.jpg?resize=800%2C1066" alt="My Podcasting Award" /></a><p class="wp-caption-text">My Podcasting Award</p></div>
<p>At the end of the session, everyone on stage received a surprise award from the organizers of WordCamp Miami. It&#8217;s the first award I&#8217;ve ever received thanks to the show and I appreciate the token of gratitude. Although the title of the show is wrong, it&#8217;s the thought that counts! Just for clarification, <a title="http://slocumstudio.com/live/?utm_campaign=Listly&utm_medium=list&utm_source=listly" href="http://slocumstudio.com/live/?utm_campaign=Listly&utm_medium=list&utm_source=listly">Week In WordPress</a> is a show produced by Matt Medeiros discussing the WordPress news of the week. I produce the show <a title="http://wptavern.com/wordpress-weekly" href="http://wptavern.com/wordpress-weekly">WordPress Weekly</a>.</p>
<h3>WordCamp Miami 2014 Day Two</h3>
<p>Day two started with the <a title="http://2014.miami.wordcamp.org/session/wordcamp-for-kids/" href="http://2014.miami.wordcamp.org/session/wordcamp-for-kids/">WordCamp for kids</a> work shop. Kids between the ages of 8-12 showed up with their laptops ready to learn how to create a blog using WordPress.com. During the session, kids went through the process of creating and activating a WordPress.com account. Then they chose a theme and created their first blog post. I observed many of the children getting through the process just fine. In fact, some of the children looked like they were ready to attend the business of WordPress session and start their own businesses.</p>
<div id="attachment_22714" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordCampForKids.jpg" rel="prettyphoto[22705]"><img class="size-full wp-image-22714" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordCampForKids.jpg?resize=800%2C600" alt="Kids Learning How To Level Up With WordPress" /></a><p class="wp-caption-text">Kids Learning How To Level Up With WordPress</p></div>
<p>The next session I attended was the <a title="http://2014.miami.wordcamp.org/session/the-business-of-wordpress/" href="http://2014.miami.wordcamp.org/session/the-business-of-wordpress/">business of WordPress session</a> moderated by Chris Lema. The panel featured <a href="http://2014.miami.wordcamp.org/speakers/#wcorg-speaker-karim-marucchi">Karim Marucchi</a>, <a href="http://2014.miami.wordcamp.org/speakers/#wcorg-speaker-carl-hancock">Carl Hancock</a>, <a href="http://2014.miami.wordcamp.org/speakers/#wcorg-speaker-cory-miller">Cory Miller</a>, <a href="http://2014.miami.wordcamp.org/speakers/#wcorg-speaker-syed-balkhi">Syed Balkhi</a>, and <a href="http://2014.miami.wordcamp.org/speakers/#wcorg-speaker-chris-lema">Chris Lema</a>. The panel was filled with memorable quotes such as:</p>
<blockquote class="twitter-tweet" width="550"><p>"No matter how tempting it is, don\'t take someone else\'s money. Keep bootstrapping"  <a href="https://twitter.com/search?q=%23wcmia&src=hash">#wcmia</a></p>
<p>&mdash; Jeff (@jeffr0) <a href="https://twitter.com/jeffr0/statuses/465519427681656832">May 11, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p>Cory Miller "I can wake up everyday knowing the work were doing is changing people\'s lives"  <a href="https://twitter.com/search?q=%23wcmia&src=hash">#wcmia</a></p>
<p>&mdash; Jeff (@jeffr0) <a href="https://twitter.com/jeffr0/statuses/465522204600709120">May 11, 2014</a></p></blockquote>
<p></p>
<div id="attachment_22730" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/766.jpg" rel="prettyphoto[22705]"><img class="size-full wp-image-22730" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/766.jpg?resize=800%2C600" alt="Business Of WordPress Panel" /></a><p class="wp-caption-text">Business Of WordPress Panel</p></div>
<p>It was evident that a lot of people are looking for ways to either start or improve their businesses using WordPress.</p>
<p> 
<div> <strong> <a href="https://www.slideshare.net/cflema/pricing-tweets" title="Pricing Tweets" target="_blank">Pricing Tweets</a> </strong> from <strong><a href="http://www.slideshare.net/cflema" target="_blank">Chris Lema</a></strong> </div>
<p>Due to an early flight, I left the venue soon after the session but according to many in attendance, this was the best one of the day.</p>
<h3>WordCamp Miami Is A Huge Success</h3>
<p>Overall, I had a great time in Miami. Despite having 770 attendees, the organizers, volunteers, and good planning provided a smooth experience. The venue was beautiful and I walked away from the event with new friends and the largest amount of swag I&#8217;ve ever been given at a WordCamp. Kudos to David Bisset and his entire team for putting on one of the best WordCamps of the year so far.</p>
<blockquote class="twitter-tweet" width="550"><p>Final <a href="https://twitter.com/search?q=%23wcmia&src=hash">#wcmia</a> stats: 770+ attending, 3 evening socials, 200 gourmet donuts, 100+ gallons ice cream, 2 shattered mugs, 5+ first-time speakers.</p>
<p>&mdash; David Bisset (@dimensionmedia) <a href="https://twitter.com/dimensionmedia/statuses/466216463682899968">May 13, 2014</a></p></blockquote>
<p></p>

<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/packedhouseforbuddycamp"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PackedHouseForBuddyCamp.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Packed House For BuddyCamp" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/743"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/743.jpg?resize=150%2C150" class="attachment-thumbnail" alt="BuddyCamp Room" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/746"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/746.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Famous Gartner Quote On Social Networks" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/747"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/747.jpg?resize=150%2C150" class="attachment-thumbnail" alt="David Bisset Presenting On BuddyPress" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/749"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/749.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Outside The BuddyCamp Venue" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/750"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/750.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Testing Out The Occulus Rift" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/751"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/751.jpg?resize=150%2C150" class="attachment-thumbnail" alt="These Lizards Are Everywhere" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/755"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/755.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Palm Trees" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/757"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/757.jpg?resize=150%2C150" class="attachment-thumbnail" alt="People Eager To Learn" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/760"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/760.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Downtown Miami At Night" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/761"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/761.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Not My Boat Coming Down The River" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-miami-2014/attachment/745"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/745.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Sarah Gooding Presenting On BuddyPress 101" /></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 14:18:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Nick Ciske: Plugin Monetization Option";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/05/13/nick-ciske-plugin-monetization-option/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<div id="v-ILHJf2Ns-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34738/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34738/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34738&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/13/nick-ciske-plugin-monetization-option/"><img alt="Nick Ciske: Plugin Monetization Option" src="http://videos.videopress.com/ILHJf2Ns/video-02b1cd8f93_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 14 May 2014 01:24:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: HHVM for Varying Vagrant Vagrants: WordPress Development on Speed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22731";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:192:"http://wptavern.com/hhvm-for-varying-vagrant-vagrants-wordpress-development-on-speed?utm_source=rss&utm_medium=rss&utm_campaign=hhvm-for-varying-vagrant-vagrants-wordpress-development-on-speed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4015:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/hhvmhack.png" rel="prettyphoto[22731]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/hhvmhack.png?resize=700%2C175" alt="hhvmhack" class="aligncenter size-full wp-image-22751" /></a></p>
<p>Are you looking to add <a href="http://hhvm.com/" target="_blank">HHVM</a> to <a href="https://github.com/Varying-Vagrant-Vagrants/VVV" target="_blank">Varying Vagrant Vagrants</a>? HHVVVM is a new HHVM configuration for WordPress developers who currently have dev environments set up using VVV.</p>
<p><a href="https://github.com/johnjamesjacoby/hhvvvm" target="_blank">HHVVVM</a>, though it sounds oddly similar to an STD, is a configuration created by John James Jacoby, which you can fork for your own use.</p>
<p>If you already have VVV up and running, you can set up a new HHVM-powered VVV site by following Jacoby&#8217;s directions in the readme.txt file of the project. The process is fairly straightforward:</p>
<ol>
<li>Create a __hhvvvm directory in the www directory of your VVV checkout</li>
<li>Clone HHVVVM into the new __hhvvvm directory</li>
<li>Create a jjj.dev directory in the www directory of your VVV checkout</li>
<li>Install WordPress using the <a href="https://github.com/markjaquith/WordPress-Skeleton" target="_blank">WP Skeleton approach by Mark Jaquith</a></li>
<li>In terminal, cd to the www directory of your VVV checkout</li>
<li>In terminal, run vagrant provision</li>
<li>Visit jjj.dev/wp-admin/ in your favorite browser</li>
</ol>
<h3>Why HHVM?</h3>
<p>HHVM (HipHop Virtual Machine) is a PHP execution engine based on the HipHop language runtime, <a href="https://www.facebook.com/notes/facebook-engineering/the-hiphop-virtual-machine/10150415177928920" target="_blank">created by Facebook</a> in order to make their infrastructure more efficient. Facebook invented it out of necessity, with hopes of being able to mitigate the growing costs of hardware. The company was able to achieve ridiculous performance improvements in the neighborhood of 6X and released <a href="http://hhvm.com/blog/4349/hhvm-3-0-0" target="_blank">HHVM 3.0</a> in late March.</p>
<p>Kinsta, a WordPress managed hosting company, has an excellent <a href="https://kinsta.com/blog/hhvm-and-wordpress/" target="_blank">article</a> explaining the previous hurdles of running WordPress with HHVM, along with instructions for installing or compiling HHVM on Ubuntu and Nginx.</p>
<p>WordPress 3.9 greatly improves HHVM compatibility, so many developers have started to experiment with it and have achieved some insanely fast load times. Hold onto your hats, folks:</p>
<blockquote class="twitter-tweet" width="550"><p>Just got a dynamic WordPress page to load (no HTML output caching) and transfer to the browser in 58ms using HHVM. Ping to the server: 27ms.</p>
<p>&mdash; Mark Jaquith (@markjaquith) <a href="https://twitter.com/markjaquith/statuses/458294601129144320">April 21, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/ryanhellyer">@ryanhellyer</a> <a href="https://twitter.com/MarkGavalda">@MarkGavalda</a> The same page is about 145ms via PHP-FPM.</p>
<p>&mdash; Mark Jaquith (@markjaquith) <a href="https://twitter.com/markjaquith/statuses/458297336410951680">April 21, 2014</a></p></blockquote>
<p></p>
<p>Hosting companies are gradually starting to adopt HHVM, as many believe that it will soon revolutionize PHP. It&#8217;s been tested with the top 25 Github PHP <a href="http://hhvm.com/frameworks/" target="_blank">frameworks</a> and the HHVM team has lofty goals to run all existing PHP code out in the wild. If you want to start testing WordPress with it now, VVV users can fork Jacoby&#8217;s <a href="https://github.com/johnjamesjacoby/hhvvvm" target="_blank">HHVVVM</a> configuration, or you can set it up manually on your server via the <a href="https://kinsta.com/blog/hhvm-and-wordpress/" target="_blank">instructions from Kinsta</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 May 2014 22:06:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WordPress.tv: Brennen Byrne: Passwords: The Weakest Link In WordPress Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34560";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wordpress.tv/2014/05/13/brennen-byrne-passwords-the-weakest-link-in-wordpress-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:710:"<div id="v-dyqFIb7v-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34560/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34560/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34560&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/13/brennen-byrne-passwords-the-weakest-link-in-wordpress-security/"><img alt="Brennen Byrne: Passwords: The Weakest Link In WordPress Security" src="http://videos.videopress.com/dyqFIb7v/video-4273bb322f_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 May 2014 18:51:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WordPress.tv: Charly McCracken: Anatomy Of A WordPress CSS File";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34806";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wordpress.tv/2014/05/13/charly-mccracken-anatomy-of-a-wordpress-css-file/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:675:"<div id="v-2mAT3ukb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34806/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34806/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34806&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/13/charly-mccracken-anatomy-of-a-wordpress-css-file/"><img alt="Charly McCracken: Anatomy Of A WordPress CSS File" src="http://videos.videopress.com/2mAT3ukb/video-4d67f1dfe4_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 May 2014 18:27:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Sam Hotchkiss: Large Multisite Networks: Our Experiences In Enterprise";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34812";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/05/13/sam-hotchkiss-large-multisite-networks-our-experiences-in-enterprise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:716:"<div id="v-MYwDoqCz-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34812/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34812/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34812&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/13/sam-hotchkiss-large-multisite-networks-our-experiences-in-enterprise/"><img alt="Sam Hotchkiss: Large Multisite Networks: Our Experiences In Enterprise" src="http://videos.videopress.com/MYwDoqCz/video-e601736b9e_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 May 2014 18:23:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: BuddyCamp Miami 2014 In Review: Presentations and Slides From the Event";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22664";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:204:"http://wptavern.com/buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event?utm_source=rss&utm_medium=rss&utm_campaign=buddycamp-miami-2014-in-review-presentations-and-slides-from-the-event";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3949:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/buddycamp.jpg" rel="prettyphoto[22664]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/buddycamp.jpg?resize=1025%2C459" alt="buddycamp" class="aligncenter size-full wp-image-22680" /></a></p>
<p><a href="http://2014.miami.wordcamp.org/" target="_blank">WordCamp Miami</a> was held over the weekend, drawing more than 770+ attendees who converged upon the University of Miami to connect over all things WordPress. The event celebrated its <a href="http://wptavern.com/wordcamp-miami-to-celebrate-5th-anniversary-in-may-2014" target="_blank">5th anniversary</a> (quite ancient in WordCamp years) with a world-class lineup of speakers and many opportunities for attendees to network.</p>
<p>BuddyCamp Miami kicked off the event on Friday, fueled by a delicious array of gourmet donuts. The organizers didn&#8217;t take an official count, but based on registration and room capacity, there were more than 150 people in attendance to learn more about BuddyPress and meet other users of the plugin. Those numbers are roughly double last year&#8217;s BuddyCamp turnout, making the event one of the fastest-growing branches of WordCamp Miami.</p>
<div id="attachment_22677" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/jjj-presenting.jpg" rel="prettyphoto[22664]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/jjj-presenting.jpg?resize=1025%2C751" alt="John James Jacoby presenting on Getting Involved With BuddyPress" class="size-full wp-image-22677" /></a><p class="wp-caption-text">John James Jacoby presenting on Getting Involved With BuddyPress</p></div>
<p>If you missed out on BuddyCamp, you can still check out the collection of slides from presentations given at the event.</p>
<h3>BuddyPress 101</h3>
<p>I gave a quick introduction to BuddyPress and its components. We had a live demo site set up for the event and attendees were able to register and explore BuddyPress hands-on during the session. The majority of those in attendance were brand new to BuddyPress and were trying it for the first time.</p>
<p></p>
<h3>Scaling BuddyPress</h3>
<p><a href="https://twitter.com/mikeeisenwasser" target="_blank">Michael Eisenwasser</a> presented on <a href="http://www.buddyboss.com/docs/scaling-buddypress.pdf">Scaling BuddyPress</a>, offering a framework for understanding how to scale a BuddyPress site over time with tips on hosting, caching, using a CDN, and optimizing to prevent bottlenecks.</p>
<p><a href="http://www.buddyboss.com/docs/scaling-buddypress.pdf"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/scaling-buddypress.png?resize=1000%2C498" alt="scaling-buddypress" class="aligncenter size-full wp-image-22686" /></a></p>
<h3>Best of BuddyPress Plugins</h3>
<p>Karla Campos presented about the best BuddyPress plugins for building community. Her slides have some excellent examples of successful BP sites and advice for those interested in building their own social networks.</p>
<p></p>
<h3>bbPress 101</h3>
<p>Jared Atchison gave a very entertaining presentation that included a quick history of bbPress and all the basics you need to know about using it to power forums on your WordPress site.</p>
<p> </p>
<p>We&#8217;ll add the remaining slides as they are added to the event&#8217;s collection.</p>
<p>Overall, BuddyCamp Miami was a great success and many of those new to BuddyPress are now excited about creating their own social networks with WordPress. The event provided an excellent opportunity for beginners to get fully immersed in BuddyPress as well as the chance for more advanced users to sharpen their skills. Although there have only been a handful of BuddyCamp events in the past, feedback from this event and others proves that adding a BuddyPress/bbPress track can be a positive addition to the traditional WordCamp experience.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 May 2014 17:35:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WordPress.tv: Pavel Ungr: Využijte 50 nejlepších SEO pluginů pro WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34721";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wordpress.tv/2014/05/12/pavel-ungr-vyuzijte-50-nejlepsich-seo-pluginu-pro-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:707:"<div id="v-5c2YzjfG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34721/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34721/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34721&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/12/pavel-ungr-vyuzijte-50-nejlepsich-seo-pluginu-pro-wordpress/"><img alt="Pavel Ungr: Využijte 50 nejlepších SEO pluginů pro WordPress" src="http://videos.videopress.com/5c2YzjfG/video-6bd9e4016f_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 12 May 2014 18:51:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Helena Denley: Making Your Website Business Friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34558";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2014/05/12/helena-denley-making-your-website-business-friendly/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-aJpL32l6-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34558/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34558/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34558&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/12/helena-denley-making-your-website-business-friendly/"><img alt="Helena Denley: Making Your Website Business Friendly" src="http://videos.videopress.com/aJpL32l6/video-a934262999_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 12 May 2014 18:36:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Peter Gramantik: Website Security And WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34682";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2014/05/12/peter-gramantik-website-security-and-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-aVaXX35B-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34682/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34682/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34682&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/12/peter-gramantik-website-security-and-wordpress/"><img alt="Peter Gramantik: Website Security And WordPress" src="http://videos.videopress.com/aVaXX35B/video-0c2d00063a_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 12 May 2014 18:34:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: More Than 97% of Updates to WordPress 3.9.1 Were Automatic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22641";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/more-than-97-of-updates-to-wordpress-3-9-1-were-automatic?utm_source=rss&utm_medium=rss&utm_campaign=more-than-97-of-updates-to-wordpress-3-9-1-were-automatic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2664:"<div id="attachment_22650" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/automatic-updates.jpg" rel="prettyphoto[22641]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/automatic-updates.jpg?resize=1020%2C455" alt="photo credit: Mike Gilbert Photography - cc" class="size-full wp-image-22650" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/technicaldirector/218791492/">Mike Gilbert Photography</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>WordPress 3.9.1 was <a href="http://wptavern.com/feed">released</a> late last week, resolving <a href="http://wptavern.com/feed">34 bugs</a>. This maintenance release includes several important fixes for multisite, TinyMCE, the customizer, widgets, and the new audio/video playlists. Site administrators who are still doing manual updates are encouraged to bring their sites up to the latest.</p>
<p>WordPress lead developer Andrew Nacin reported that in the seven minutes between starting 3.9.1 updates and writing the release post, WordPress performed approximately 68,000 background updates. After it had been out for 100 minutes, 3.9.1 crossed a million downloads, with 10,00 updates happening per minute.</p>
<blockquote class="twitter-tweet" width="550"><p>WordPress 3.9.1 already crossed a million downloads. It’s been out for about 100 minutes. North of 10,000 updates a minute. Not bad.</p>
<p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/464498244853460992">May 8, 2014</a></p></blockquote>
<p></p>
<p>Nacin also posted a graph of network traffic from one of WordPress.org’s load balancers during the time it was serving updates, reporting that &#8220;WP 3.9.1 was no sweat.&#8221;</p>
<blockquote class="twitter-tweet" width="550"><p>Here’s a graph of network traffic from one of <a href="http://t.co/ZYsZNv4Tli">http://t.co/ZYsZNv4Tli</a>’s load balancers today. WP 3.9.1 was no sweat. <a href="http://t.co/kGaHeeWQS2">pic.twitter.com/kGaHeeWQS2</a></p>
<p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/464591561867919361">May 9, 2014</a></p></blockquote>
<p></p>
<p>More than <a href="https://twitter.com/nacin/status/464500683904122880" target="_blank">97% of these updates were automatic</a>, with less than 3% manual. That number is increasing with each release and may very soon be close to 100%. Automatic updates are functioning so well that it’s not difficult to imagine a day in the near future when they will be a non-news item, quietly humming in the background of WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 12 May 2014 16:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress.tv: Scott Williford: Video SEO 101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34702";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.tv/2014/05/11/scott-williford-video-seo-101/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:643:"<div id="v-8m362KT7-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34702/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34702/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34702&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/11/scott-williford-video-seo-101/"><img alt="Scott Williford: Video SEO 101" src="http://videos.videopress.com/8m362KT7/video-c42db8aac0_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 11 May 2014 18:54:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:110:"WordPress.tv: Adam Williams: All The Stuff We Wish We’d Known About When We Started Developing For WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34695";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:123:"http://wordpress.tv/2014/05/11/adam-williams-all-the-stuff-we-wishwed-known-about-when-we-started-developing-for-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:765:"<div id="v-0nxl5jkX-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34695/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34695/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34695&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/11/adam-williams-all-the-stuff-we-wishwed-known-about-when-we-started-developing-for-wordpress/"><img alt="Adam Williams: All The Stuff We Wish We’d Known About When We Started Developing For WordPress" src="http://videos.videopress.com/0nxl5jkX/video-33e476a20e_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 11 May 2014 18:45:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 20 May 2014 00:22:41 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"146915";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Tue, 20 May 2014 00:00:11 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (433, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1400588562', 'no') ; 
INSERT INTO `mjwp_options` VALUES (434, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1400545362', 'no') ; 
INSERT INTO `mjwp_options` VALUES (435, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1400588562', 'no') ; 
INSERT INTO `mjwp_options` VALUES (436, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 20 May 2014 00:05:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 9 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 20 May 2014 00:22:42 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Tue, 20 May 2014 00:40:49 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Tue, 20 May 2014 00:05:49 +0000";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (437, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1400588562', 'no') ; 
INSERT INTO `mjwp_options` VALUES (438, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1400545362', 'no') ; 
INSERT INTO `mjwp_options` VALUES (439, '_transient_timeout_plugin_slugs', '1400631865', 'no') ; 
INSERT INTO `mjwp_options` VALUES (440, '_transient_plugin_slugs', 'a:4:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:43:"custom-post-type-ui/custom-post-type-ui.php";}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (441, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1400588562', 'no') ; 
INSERT INTO `mjwp_options` VALUES (442, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/05/wordpress-3-9-1/\' title=\'After three weeks and more than 9 million downloads of WordPress 3.9, we’re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We’ve also made some improvements to the new audio/video […]\'>WordPress 3.9.1 Maintenance Release</a> <span class="rss-date">May 8, 2014</span><div class=\'rssSummary\'>After three weeks and more than 9 million downloads of WordPress 3.9, we’re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We’ve also made some improvements to the new audio/vi [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-for-android-will-no-longer-support-gingerbread?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-for-android-will-no-longer-support-gingerbread\' title=\' Long time Android users will remember how much of leap forward Ice Cream Sandwich 4.0 (ICS) was for the platform in 2011. As the vastly improved successor to Android 2.3 Gingerbread, it was one of the largest upgrades to Android OS in history, creating a demarcation line between the much older versions and the newer ones that would follow. (Android OS versions are released in alphabetical order under sugary treat code names.) ICS came with a completely redesigned UI and the new Roboto typeface. It introduced a new voice input engine and a ton of new media capabilities. The 4.0 version added more intuitive gestures and allowed app developers to make use of them, too. Android developers often refer to the ICS release as a pivotal point in the platform’s development, given how much changed. WordPress for Android Mobile App to Drop Gingerbread Support The WordPress for Android development team announced today that it will no longer support Gingerbread. Despite the fact that ICS was released in 2011, many people are still using devices that don’t support anything past Gingerbread. In an effort to reach the largest number of users, the WordPress app has maintained compatibility with older versions, incurring a ton of extra development time. Recent numbers showing the relative number of devices on various Android platform versions puts Gingerbread at about 16% this month, down 1% from April:  The cost of supporting Gingerbread for a small portion of the WordPress app’s user base (which is actually less than 10%) causes the everyone else to suffer what they are calling the “Gingerbread tax” while waiting for new features: This means over 90% of our users are paying a “Gingerbread tax” – waiting longer for new versions and not seeing features that take advantage of their phones – so that we can continue supporting older devices. The upcoming version 2.9 of WordPress for Android will only support devices running Android 4.0 or later, allowing its developers to be more productive. The app itself will also become faster and smaller for the majority of people who are using it. Please note that it doesn’t mean that the app is disappearing for these devices. An older version will still be available from the Google Play store for use with older phones and tablets that are still running on Gingerbread. Gingerbread support will officially be dropped later this month when WordPress for Android 2.9 is expected to be released. This version will also include a new Blog Discovery feature for finding blogs based on recommendation as well the ability to preview a blog’s posts before electing to follow. Subscription management will also be included, along with a number of helpful UI improvements.\'>WPTavern: WordPress for Android Will No Longer Support Gingerbread</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordcamp-miami-kids-workshop-launches-the-next-generation-of-bloggers?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordcamp-miami-kids-workshop-launches-the-next-generation-of-bloggers\' title=\'WordCamp Miami celebrated its 5th anniversary this year, drawing 770+ people to the event. The organizers also hosted their first WordPress beginner’s workshop for kids as part of the Sunday activities. Tammie Lister, Kathryn Presner and I worked together to lead the workshop, along with volunteers Noel Tock, Mika Epstein, and Suzette Franck. The session was geared toward kids aged 8-12 and each child attended with a parent. We had two hours to give an introduction to WordPress and help the kids set up their own blogs. At the end of the morning, each child had published a post to the internet. Personally, this is most likely the proudest photo from #wcmia : Our 1st Kid’s Workshop. pic.twitter.com/KecwSCwVM5 — David Bisset (@dimensionmedia) May 14, 2014  Lister designed the slides for the presentation with a Minecraft theme, which ended up being a big win, since the vast majority of the kids present were wild about the game. She used aspects of Minecraft to help us explain the concept of open source, WordPress blogging tools, themes, commenting, subscribing and making friends online. We guided the kids through signing up on WordPress.com to create a free blog. A couple of them already had blogs on a network hosted by their parents, but most of them were experiencing WordPress for the first time, including many of their parents. I came away from the workshop with three observations regarding kids and WordPress. 1. WordPress is Easy for Kids to Use The most time-consuming aspect of the workshop was getting kids signed up to WordPress.com and making sure everyone recieved the confirmation email. Not all of the kids had their own email addresses but those who didn’t were able to use a parent’s address. Once inside the WordPress admin, the kids took to blogging quite naturally and didn’t require much hand-holding.  After publishing their first posts, the kids linked up to comment on each other’s blogs and discovered the comment notifications and relevant admin screens on their own. Adding images/media was no sweat for them and many were eager to publish additional posts after the first one. 2. The Joy of Publishing is Timeless One might think that the concept of blogs would be old news to kids who who have never known a world without the internet. While media and technology curmudgeons analysts, who count themselves on the cutting edge, like to proclaim that blogs are dead, these kids are discovering publishing for the first time.  Upon hitting the “Publish” button, workshop attendee Jahdin, pictured above, put his hands in the air and shouted, “I just published my first post to the Internet!” His blog was about his ninth birthday party and included a picture from the event. I asked him what he plans to write about in the future, and he said, “I plan to blog about how life was when I was a kid.” If you can remember back to the thrill of publishing your thoughts to the web for the first time, that’s exactly what we saw in the kids’ reactions to putting their first posts out there. WordPress gives them a place to record their thoughts and experiences in a way that can be shared with friends and relatives who want to follow their adventures. Jahdin’s plan to “blog about life when I was a kid” is one of the most common reasons many of us started blogging in the first place – to record our own history. This is the next generation of people building the web. Putting the power of publishing in their hands and introducing them to new ideas, such as open source software, gives each child a simple framework for understanding themselves as a person with a voice on the web. 3. Kids Might Enjoy More Advanced Workshops The first kids workshop at WordCamp Miami was a great success and it seems that even more advanced kids workshops would go over well, based on the response. Learning the basics of themes, plugins and WordPress core would be interesting things to explore with them, as some of the older kids seemed eager to know more about the building blocks of WordPress. WordCamp Miami isn’t the only event to host a workshop for kids. Both WordCamp Phoenix and WordCamp Albuquerque have held similar events. The workshop in Albuquerque is so popular that they’ve brought it back every year for the past three years. While WordCamps have always been open to people of all ages, having a dedicated session tailored for kids is an investment in the future publishers and makers of the web. Watching kids get excited about WordPress was one of the highlights of the event for me. If you have an active meetup group or are part of organizing a WordCamp, you might consider adding a session or even a track for kids. Helping them publish their first posts is an inspirational way to experience WordPress for the first time all over again.\'>WPTavern: WordCamp Miami Kids’ Workshop Launches the Next Generation of Bloggers</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/05/19/agnes-bury-10-common-mistakes-wordpress-developers-make-when-building-multilingual-sites/\' title=\'    \'>WordPress.tv: Agnes Bury: 10 Common Mistakes WordPress Developers Make When Building Multilingual Sites</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/woocommerce/\' class=\'dashboard-news-plugin-link\'>WooCommerce - excelling eCommerce</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=639238f787&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WooCommerce - excelling eCommerce\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `mjwp_options` VALUES (443, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1400556229', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (444, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (445, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1400545464;s:7:"checked";a:4:{s:30:"advanced-custom-fields/acf.php";s:5:"4.3.8";s:19:"akismet/akismet.php";s:5:"2.5.9";s:35:"backupwordpress/backupwordpress.php";s:5:"2.6.2";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:5:"0.8.2";}s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.0";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.0.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (446, 'hmbkp_default_path', '/Applications/MAMP/htdocs/themusicjournal/wp-content/backupwordpress-3df9d2449f-backups', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (447, 'hmbkp_path', '/Applications/MAMP/htdocs/themusicjournal/wp-content/backupwordpress-3df9d2449f-backups', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (448, 'hmbkp_schedule_default-1', 'a:5:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:19:"schedule_start_time";i:1400626800;s:11:"max_backups";i:14;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (449, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1400986800;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (450, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `mjwp_options` VALUES (451, '_transient_timeout_hmbkp_plugin_data', '1400631890', 'no') ; 
INSERT INTO `mjwp_options` VALUES (452, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.6.2";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.3";s:6:"tested";s:5:"3.9.1";s:13:"compatibility";a:1:{s:5:"3.8.3";a:1:{s:5:"2.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}}s:6:"rating";d:91.400000000000005684341886080801486968994140625;s:11:"num_ratings";i:675;s:10:"downloaded";i:1046890;s:12:"last_updated";s:10:"2014-05-06";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:18:"http://bwp.hmn.md/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:32377:"<h4>2.6.2</h4>

<ul>
<li>Reverts a change to how the home path is calculated as it caused issues on installs where wp-config.php was stored outside of web root. Props to @mikelittle for the bug report.</li>
</ul>

<h4>2.6.1</h4>

<ul>
<li>Bump minimum WP requirement to 3.7.3, the latest security release on the 3.7 branch.</li>
<li>Fix an issues that could cause schedule times to fail to account for timezone differences.</li>
<li>Add a nonce check to the schedule settings.</li>
<li>Fix a possible JS warning when removing an exclude rule.</li>
<li>Our unit tests now run in PHP 5.2 again.</li>
</ul>

<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `mjwp_options` VALUES (453, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2801177382', 'no') ; 
INSERT INTO `mjwp_options` VALUES (454, '_transient_hmbkp_schedule_default-1_database_filesize', '1376256', 'no') ; 
INSERT INTO `mjwp_options` VALUES (455, '_transient_timeout_hmbkp_schedule_default-1_complete_filesize', '2801177782', 'no') ; 
INSERT INTO `mjwp_options` VALUES (456, '_transient_hmbkp_schedule_default-1_complete_filesize', '23079226', 'no') ;
#
# End of data contents of table mjwp_options
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_postmeta`
#

DROP TABLE IF EXISTS `mjwp_postmeta`;


#
# Table structure of table `mjwp_postmeta`
#

CREATE TABLE `mjwp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=563 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_postmeta (511 records)
#
 
INSERT INTO `mjwp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `mjwp_postmeta` VALUES (2, 2, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `mjwp_postmeta` VALUES (3, 2, '_wp_trash_meta_time', '1399740655') ; 
INSERT INTO `mjwp_postmeta` VALUES (4, 5, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (5, 5, '_edit_lock', '1399915617:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (6, 5, '_wp_page_template', 'default') ; 
INSERT INTO `mjwp_postmeta` VALUES (7, 7, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (8, 7, '_edit_lock', '1399995237:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (9, 7, '_wp_page_template', 'about.php') ; 
INSERT INTO `mjwp_postmeta` VALUES (10, 9, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (11, 9, '_wp_page_template', 'default') ; 
INSERT INTO `mjwp_postmeta` VALUES (12, 9, '_edit_lock', '1399740716:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (13, 11, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (14, 11, '_edit_lock', '1400209182:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (15, 13, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (16, 13, '_wp_page_template', 'inspiration.php') ; 
INSERT INTO `mjwp_postmeta` VALUES (17, 13, '_edit_lock', '1400267049:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (18, 15, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (19, 15, '_edit_lock', '1399745624:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (21, 17, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (22, 17, '_edit_lock', '1399741158:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (24, 19, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (25, 19, '_edit_lock', '1400176919:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (27, 21, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (28, 21, '_edit_lock', '1400177019:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (30, 23, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (31, 23, 'field_536e60cc442b2', 'a:14:{s:3:"key";s:19:"field_536e60cc442b2";s:5:"label";s:5:"Title";s:4:"name";s:5:"title";s:4:"type";s:4:"text";s:12:"instructions";s:23:"Enter the project title";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:13:"project title";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (33, 23, 'field_536e6216442b4', 'a:14:{s:3:"key";s:19:"field_536e6216442b4";s:5:"label";s:11:"Inspiration";s:4:"name";s:11:"inspiration";s:4:"type";s:4:"text";s:12:"instructions";s:31:"Enter the project\'s inspiration";s:8:"required";s:1:"1";s:13:"default_value";s:12:"Inspiration:";s:11:"placeholder";s:12:"Inspiration:";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (34, 23, 'field_536e6244442b5', 'a:13:{s:3:"key";s:19:"field_536e6244442b5";s:5:"label";s:19:"Project Description";s:4:"name";s:19:"project_description";s:4:"type";s:8:"textarea";s:12:"instructions";s:31:"Enter the project\'s description";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:4:"none";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (36, 23, 'position', 'normal') ; 
INSERT INTO `mjwp_postmeta` VALUES (37, 23, 'layout', 'no_box') ; 
INSERT INTO `mjwp_postmeta` VALUES (38, 23, 'hide_on_screen', 'a:12:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:15:"send-trackbacks";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (39, 23, '_edit_lock', '1400173555:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (40, 25, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (41, 25, 'field_536e635d5a724', 'a:14:{s:3:"key";s:19:"field_536e635d5a724";s:5:"label";s:13:"YouTube Video";s:4:"name";s:13:"youtube_video";s:4:"type";s:4:"text";s:12:"instructions";s:38:"Enter YouTube video id ex. RbzP_EscxG0";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (42, 25, 'field_536e63835a725', 'a:14:{s:3:"key";s:19:"field_536e63835a725";s:5:"label";s:13:"Content title";s:4:"name";s:13:"content_title";s:4:"type";s:4:"text";s:12:"instructions";s:19:"Enter content title";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (43, 25, 'field_536e63cb5a726', 'a:14:{s:3:"key";s:19:"field_536e63cb5a726";s:5:"label";s:14:"Content author";s:4:"name";s:14:"content_author";s:4:"type";s:4:"text";s:12:"instructions";s:19:"Enter artist\'s name";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:13:"Artist\'s name";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (44, 25, 'field_536e64065a727', 'a:13:{s:3:"key";s:19:"field_536e64065a727";s:5:"label";s:15:"Content summary";s:4:"name";s:15:"content_summary";s:4:"type";s:8:"textarea";s:12:"instructions";s:36:"Enter a 1-2 sentence content summary";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:15:"Content summary";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:4:"none";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (46, 25, 'position', 'normal') ; 
INSERT INTO `mjwp_postmeta` VALUES (47, 25, 'layout', 'no_box') ; 
INSERT INTO `mjwp_postmeta` VALUES (48, 25, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (49, 25, '_edit_lock', '1399935923:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (55, 26, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (56, 26, '_edit_lock', '1400173565:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (57, 27, 'title', 'First Project') ; 
INSERT INTO `mjwp_postmeta` VALUES (58, 27, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (59, 27, 'style', 'Style: Electronic, minimalist, experimental') ; 
INSERT INTO `mjwp_postmeta` VALUES (60, 27, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (61, 27, 'inspiration', 'Inspiration: The Age of Adz') ; 
INSERT INTO `mjwp_postmeta` VALUES (62, 27, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (63, 27, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (64, 27, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (65, 26, 'title', 'First Project') ; 
INSERT INTO `mjwp_postmeta` VALUES (66, 26, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (67, 26, 'style', 'Style: Electronic, minimalist, experimental') ; 
INSERT INTO `mjwp_postmeta` VALUES (68, 26, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (69, 26, 'inspiration', 'Inspiration: The Age of Adz') ; 
INSERT INTO `mjwp_postmeta` VALUES (70, 26, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (71, 26, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (72, 26, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (73, 28, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (74, 28, '_edit_lock', '1400173536:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (75, 29, 'title', 'Writing for Strings') ; 
INSERT INTO `mjwp_postmeta` VALUES (76, 29, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (77, 29, 'style', 'Style: Classical, acoustic, chamber') ; 
INSERT INTO `mjwp_postmeta` VALUES (78, 29, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (79, 29, 'inspiration', 'Inspiration: Béla Bartók') ; 
INSERT INTO `mjwp_postmeta` VALUES (80, 29, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (81, 29, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (82, 29, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (83, 28, 'title', 'Writing for Strings') ; 
INSERT INTO `mjwp_postmeta` VALUES (84, 28, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (85, 28, 'style', 'Style: Classical, acoustic, chamber') ; 
INSERT INTO `mjwp_postmeta` VALUES (86, 28, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (87, 28, 'inspiration', 'Inspiration: Béla Bartók') ; 
INSERT INTO `mjwp_postmeta` VALUES (88, 28, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (89, 28, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (90, 28, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (91, 30, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (92, 30, '_edit_lock', '1400172097:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (93, 31, 'title', 'Punk Guitar Sound') ; 
INSERT INTO `mjwp_postmeta` VALUES (94, 31, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (95, 31, 'style', 'Style: Punk, rock, retro') ; 
INSERT INTO `mjwp_postmeta` VALUES (96, 31, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (97, 31, 'inspiration', 'Inspiration: The Ramones') ; 
INSERT INTO `mjwp_postmeta` VALUES (98, 31, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (99, 31, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (100, 31, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (101, 30, 'title', 'Punk Guitar Sound') ; 
INSERT INTO `mjwp_postmeta` VALUES (102, 30, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (103, 30, 'style', 'Style: Punk, rock, retro') ; 
INSERT INTO `mjwp_postmeta` VALUES (104, 30, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (105, 30, 'inspiration', 'Inspiration: The Ramones') ; 
INSERT INTO `mjwp_postmeta` VALUES (106, 30, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (107, 30, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (108, 30, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (109, 32, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (110, 32, '_edit_lock', '1400177397:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (111, 33, 'title', 'Drone Track') ; 
INSERT INTO `mjwp_postmeta` VALUES (112, 33, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (113, 33, 'style', 'Style: Ambient, dark, avant-garde, experimental, noise') ; 
INSERT INTO `mjwp_postmeta` VALUES (114, 33, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (115, 33, 'inspiration', 'Inspiration: "Only Lovers Left Alive"') ; 
INSERT INTO `mjwp_postmeta` VALUES (116, 33, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (117, 33, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (118, 33, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (119, 32, 'title', 'Drone Track') ; 
INSERT INTO `mjwp_postmeta` VALUES (120, 32, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (121, 32, 'style', 'Style: Ambient, dark, avant-garde, experimental, noise') ; 
INSERT INTO `mjwp_postmeta` VALUES (122, 32, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (123, 32, 'inspiration', 'Inspiration: "Only Lovers Left Alive"') ; 
INSERT INTO `mjwp_postmeta` VALUES (124, 32, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (125, 32, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (126, 32, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (127, 34, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (128, 34, '_edit_lock', '1399936486:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (129, 35, 'youtube_video', '<a href="https://www.youtube.com/watch?v=Oeu3prTK-tQ">https://www.youtube.com/watch?v=Oeu3prTK-tQ</a>') ; 
INSERT INTO `mjwp_postmeta` VALUES (130, 35, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (131, 35, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (132, 35, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (133, 35, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (134, 35, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (135, 34, 'youtube_video', 'Oeu3prTK-tQ') ; 
INSERT INTO `mjwp_postmeta` VALUES (136, 34, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (137, 34, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (138, 34, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (139, 34, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (140, 34, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (141, 36, 'youtube_video', '<iframe id="ytplayer" src="https://www.youtube.com/embed/Oeu3prTK-tQ?color=white&amp;theme=light" height="350" width="375" allowfullscreen="" frameborder="0"></iframe>') ; 
INSERT INTO `mjwp_postmeta` VALUES (142, 36, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (143, 36, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (144, 36, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (145, 36, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (146, 36, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (147, 37, 'youtube_video', '<iframe id="ytplayer" src="https://www.youtube.com/embed/Oeu3prTK-tQ?color=white&amp;theme=light" height="350" width="375" allowfullscreen="" frameborder="0"></iframe>') ; 
INSERT INTO `mjwp_postmeta` VALUES (148, 37, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (149, 37, 'content_title', '34') ; 
INSERT INTO `mjwp_postmeta` VALUES (150, 37, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (151, 37, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (152, 37, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (153, 37, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (154, 37, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (155, 34, 'content_title', 'Poker Face (Polka Phaze)') ; 
INSERT INTO `mjwp_postmeta` VALUES (156, 34, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (157, 38, 'youtube_video', '<iframe id="ytplayer" src="https://www.youtube.com/embed/Oeu3prTK-tQ?color=white&amp;theme=light" height="350" width="375" allowfullscreen="" frameborder="0"></iframe>') ; 
INSERT INTO `mjwp_postmeta` VALUES (158, 38, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (159, 38, 'content_title', '34') ; 
INSERT INTO `mjwp_postmeta` VALUES (160, 38, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (161, 38, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (162, 38, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (163, 38, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (164, 38, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (165, 39, 'youtube_video', 'https://www.youtube.com/embed/Oeu3prTK-tQ?color=white&amp;theme=light') ; 
INSERT INTO `mjwp_postmeta` VALUES (166, 39, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (167, 39, 'content_title', '34') ; 
INSERT INTO `mjwp_postmeta` VALUES (168, 39, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (169, 39, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (170, 39, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (171, 39, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (172, 39, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (173, 1, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `mjwp_postmeta` VALUES (174, 1, '_wp_trash_meta_time', '1399745503') ; 
INSERT INTO `mjwp_postmeta` VALUES (175, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:5:"trash";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (176, 43, 'youtube_video', 'https://www.youtube.com/watch?v=Oeu3prTK-tQ') ; 
INSERT INTO `mjwp_postmeta` VALUES (177, 43, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (178, 43, 'content_title', '34') ; 
INSERT INTO `mjwp_postmeta` VALUES (179, 43, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (180, 43, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (181, 43, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (182, 43, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (183, 43, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (192, 46, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (193, 46, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (194, 46, '_menu_item_object_id', '5') ; 
INSERT INTO `mjwp_postmeta` VALUES (195, 46, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (196, 46, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (197, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (198, 46, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (199, 46, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (200, 46, '_menu_item_orphaned', '1399915916') ; 
INSERT INTO `mjwp_postmeta` VALUES (201, 47, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (202, 47, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (203, 47, '_menu_item_object_id', '7') ; 
INSERT INTO `mjwp_postmeta` VALUES (204, 47, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (205, 47, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (206, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (207, 47, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (208, 47, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (209, 47, '_menu_item_orphaned', '1399915916') ; 
INSERT INTO `mjwp_postmeta` VALUES (210, 48, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (211, 48, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (212, 48, '_menu_item_object_id', '9') ; 
INSERT INTO `mjwp_postmeta` VALUES (213, 48, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (214, 48, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (215, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (216, 48, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (217, 48, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (218, 48, '_menu_item_orphaned', '1399915916') ; 
INSERT INTO `mjwp_postmeta` VALUES (219, 49, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (220, 49, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (221, 49, '_menu_item_object_id', '13') ; 
INSERT INTO `mjwp_postmeta` VALUES (222, 49, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (223, 49, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (224, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (225, 49, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (226, 49, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (227, 49, '_menu_item_orphaned', '1399915916') ; 
INSERT INTO `mjwp_postmeta` VALUES (228, 50, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (229, 50, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (230, 50, '_menu_item_object_id', '11') ; 
INSERT INTO `mjwp_postmeta` VALUES (231, 50, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (232, 50, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (233, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (234, 50, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (235, 50, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (236, 50, '_menu_item_orphaned', '1399915916') ; 
INSERT INTO `mjwp_postmeta` VALUES (237, 51, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (238, 51, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (239, 51, '_menu_item_object_id', '5') ; 
INSERT INTO `mjwp_postmeta` VALUES (240, 51, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (241, 51, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (242, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (243, 51, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (244, 51, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (246, 52, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (247, 52, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (248, 52, '_menu_item_object_id', '7') ; 
INSERT INTO `mjwp_postmeta` VALUES (249, 52, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (250, 52, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (251, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (252, 52, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (253, 52, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (255, 53, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (256, 53, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (257, 53, '_menu_item_object_id', '9') ; 
INSERT INTO `mjwp_postmeta` VALUES (258, 53, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (259, 53, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (260, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (261, 53, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (262, 53, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (264, 54, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (265, 54, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (266, 54, '_menu_item_object_id', '13') ; 
INSERT INTO `mjwp_postmeta` VALUES (267, 54, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (268, 54, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (269, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (270, 54, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (271, 54, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (273, 55, '_menu_item_type', 'post_type') ; 
INSERT INTO `mjwp_postmeta` VALUES (274, 55, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `mjwp_postmeta` VALUES (275, 55, '_menu_item_object_id', '11') ; 
INSERT INTO `mjwp_postmeta` VALUES (276, 55, '_menu_item_object', 'page') ; 
INSERT INTO `mjwp_postmeta` VALUES (277, 55, '_menu_item_target', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (278, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (279, 55, '_menu_item_xfn', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (280, 55, '_menu_item_url', '') ; 
INSERT INTO `mjwp_postmeta` VALUES (282, 11, '_wp_page_template', 'projects.php') ; 
INSERT INTO `mjwp_postmeta` VALUES (288, 25, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:11:"inspiration";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (289, 59, 'youtube_video', 'Oeu3prTK-tQ') ; 
INSERT INTO `mjwp_postmeta` VALUES (290, 59, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (291, 59, 'content_title', 'Poker Face (Polka Phaze)') ; 
INSERT INTO `mjwp_postmeta` VALUES (292, 59, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (293, 59, 'content_author', 'The Real Tuesday Weld') ; 
INSERT INTO `mjwp_postmeta` VALUES (294, 59, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (295, 59, 'content_summary', 'This track is pretty great. Can\'t wait to type more about it when I\'m focusing on writing.') ; 
INSERT INTO `mjwp_postmeta` VALUES (296, 59, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (297, 60, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (298, 60, '_edit_lock', '1399937719:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (299, 61, 'youtube_video', 'Oeu3prTK-tQ') ; 
INSERT INTO `mjwp_postmeta` VALUES (300, 61, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (301, 61, 'content_title', 'Ice Dance') ; 
INSERT INTO `mjwp_postmeta` VALUES (302, 61, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (303, 61, 'content_author', 'Danny Elfman') ; 
INSERT INTO `mjwp_postmeta` VALUES (304, 61, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (305, 61, 'content_summary', 'From Edward Scissorhands - so sad and beautiful.') ; 
INSERT INTO `mjwp_postmeta` VALUES (306, 61, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (307, 60, 'youtube_video', 'tCTP7Qs0UcU') ; 
INSERT INTO `mjwp_postmeta` VALUES (308, 60, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (309, 60, 'content_title', 'Ice Dance') ; 
INSERT INTO `mjwp_postmeta` VALUES (310, 60, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (311, 60, 'content_author', 'Danny Elfman') ; 
INSERT INTO `mjwp_postmeta` VALUES (312, 60, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (313, 60, 'content_summary', 'From Edward Scissorhands - so sad and beautiful.') ; 
INSERT INTO `mjwp_postmeta` VALUES (314, 60, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (315, 62, 'youtube_video', 'tCTP7Qs0UcU') ; 
INSERT INTO `mjwp_postmeta` VALUES (316, 62, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (317, 62, 'content_title', 'Ice Dance') ; 
INSERT INTO `mjwp_postmeta` VALUES (318, 62, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (319, 62, 'content_author', 'Danny Elfman') ; 
INSERT INTO `mjwp_postmeta` VALUES (320, 62, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (321, 62, 'content_summary', 'From Edward Scissorhands - so sad and beautiful.') ; 
INSERT INTO `mjwp_postmeta` VALUES (322, 62, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (323, 63, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (324, 63, '_edit_lock', '1399937806:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (325, 64, 'youtube_video', '5X-6_0YqgeI') ; 
INSERT INTO `mjwp_postmeta` VALUES (326, 64, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (327, 64, 'content_title', 'Cissy Strut') ; 
INSERT INTO `mjwp_postmeta` VALUES (328, 64, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (329, 64, 'content_author', 'The Meters') ; 
INSERT INTO `mjwp_postmeta` VALUES (330, 64, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (331, 64, 'content_summary', 'The original - also love the John Mayer version.') ; 
INSERT INTO `mjwp_postmeta` VALUES (332, 64, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (333, 63, 'youtube_video', '5X-6_0YqgeI') ; 
INSERT INTO `mjwp_postmeta` VALUES (334, 63, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (335, 63, 'content_title', 'Cissy Strut') ; 
INSERT INTO `mjwp_postmeta` VALUES (336, 63, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (337, 63, 'content_author', 'The Meters') ; 
INSERT INTO `mjwp_postmeta` VALUES (338, 63, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (339, 63, 'content_summary', 'The original - also love the John Mayer version.') ; 
INSERT INTO `mjwp_postmeta` VALUES (340, 63, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (341, 65, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (342, 65, '_edit_lock', '1399937880:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (343, 66, 'youtube_video', 'RbzP_EscxG0') ; 
INSERT INTO `mjwp_postmeta` VALUES (344, 66, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (345, 66, 'content_title', 'Go Do') ; 
INSERT INTO `mjwp_postmeta` VALUES (346, 66, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (347, 66, 'content_author', 'Jónsi & Nico Muhly') ; 
INSERT INTO `mjwp_postmeta` VALUES (348, 66, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (349, 66, 'content_summary', 'An acoustic performance, such a fun upbeat song.') ; 
INSERT INTO `mjwp_postmeta` VALUES (350, 66, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (351, 65, 'youtube_video', 'RbzP_EscxG0') ; 
INSERT INTO `mjwp_postmeta` VALUES (352, 65, '_youtube_video', 'field_536e635d5a724') ; 
INSERT INTO `mjwp_postmeta` VALUES (353, 65, 'content_title', 'Go Do') ; 
INSERT INTO `mjwp_postmeta` VALUES (354, 65, '_content_title', 'field_536e63835a725') ; 
INSERT INTO `mjwp_postmeta` VALUES (355, 65, 'content_author', 'Jónsi & Nico Muhly') ; 
INSERT INTO `mjwp_postmeta` VALUES (356, 65, '_content_author', 'field_536e63cb5a726') ; 
INSERT INTO `mjwp_postmeta` VALUES (357, 65, 'content_summary', 'An acoustic performance, such a fun upbeat song.') ; 
INSERT INTO `mjwp_postmeta` VALUES (358, 65, '_content_summary', 'field_536e64065a727') ; 
INSERT INTO `mjwp_postmeta` VALUES (359, 67, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (360, 67, 'field_537232fb38c54', 'a:13:{s:3:"key";s:19:"field_537232fb38c54";s:5:"label";s:15:"First Paragraph";s:4:"name";s:6:"firstp";s:4:"type";s:8:"textarea";s:12:"instructions";s:58:"Enter the first paragraph of the about page write-up here.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:4:"none";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (362, 67, 'position', 'normal') ; 
INSERT INTO `mjwp_postmeta` VALUES (363, 67, 'layout', 'no_box') ; 
INSERT INTO `mjwp_postmeta` VALUES (364, 67, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (365, 67, '_edit_lock', '1399995083:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (367, 69, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (368, 69, '_edit_lock', '1399995003:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (369, 70, 'about', 'This is the write-up describing my site. Some more text here talking about the site. Let\'s make a second paragraph and see what that looks like. It would be great if I could finish up the theme conversion today and set-up some hosting. I\'d love to be able to stop paying for SS for my photo site. 

It\'s a gray day outside, but it\'s been too buggy to enjoy and the sun. I\'m looking forward to going into town in a few days. It\'ll be a good break from my usual pattern. I hope DH is really nice. I should make sure to bring some snacks.

Okay, on the third paragraph now. Enough text to hit publish.') ; 
INSERT INTO `mjwp_postmeta` VALUES (370, 70, '_about', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (371, 69, 'about', 'This is the write-up describing my site. Some more text here talking about the site. Let\'s make a second paragraph and see what that looks like. It would be great if I could finish up the theme conversion today and set-up some hosting. I\'d love to be able to stop paying for SS for my photo site.

It\'s a gray day outside, but it\'s been too buggy to enjoy and the sun. I\'m looking forward to going into town in a few days. It\'ll be a good break from my usual pattern. I hope DH is really nice. I should make sure to bring some snacks.

Okay, on the third paragraph now. Enough text to hit publish.') ; 
INSERT INTO `mjwp_postmeta` VALUES (372, 69, '_about', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (373, 72, 'about', '<p>This is the write-up describing my site. Some more text here talking about the site. Let\'s make a second paragraph and see what that looks like. It would be great if I could finish up the theme conversion today and set-up some hosting. I\'d love to be able to stop paying for SS for my photo site.</p> 

<p>It\'s a gray day outside, but it\'s been too buggy to enjoy and the sun. I\'m looking forward to going into town in a few days. It\'ll be a good break from my usual pattern. I hope DH is really nice. I should make sure to bring some snacks.</p>

<p>Okay, on the third paragraph now. Enough text to hit publish.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (374, 72, '_about', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (375, 73, 'about', 'This is the write-up describing my site. Some more text here talking about the site. Let\'s make a second paragraph and see what that looks like. It would be great if I could finish up the theme conversion today and set-up some hosting. I\'d love to be able to stop paying for SS for my photo site.

It\'s a gray day outside, but it\'s been too buggy to enjoy and the sun. I\'m looking forward to going into town in a few days. It\'ll be a good break from my usual pattern. I hope DH is really nice. I should make sure to bring some snacks.

<p>Okay, on the third paragraph now. Enough text to hit publish.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (376, 73, '_about', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (377, 74, 'about', 'This is the write-up describing my site. Some more text here talking about the site. Let\'s make a second paragraph and see what that looks like. It would be great if I could finish up the theme conversion today and set-up some hosting. I\'d love to be able to stop paying for SS for my photo site.

It\'s a gray day outside, but it\'s been too buggy to enjoy and the sun. I\'m looking forward to going into town in a few days. It\'ll be a good break from my usual pattern. I hope DH is really nice. I should make sure to bring some snacks.

Okay, on the third paragraph now. Enough text to hit publish.') ; 
INSERT INTO `mjwp_postmeta` VALUES (378, 74, '_about', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (382, 67, 'field_537237152ad06', 'a:13:{s:3:"key";s:19:"field_537237152ad06";s:5:"label";s:25:"All Subsequent Paragraphs";s:4:"name";s:14:"sub_paragraphs";s:4:"type";s:8:"textarea";s:12:"instructions";s:49:"Enter the rest of the About Page paragraphs here.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:4:"html";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (385, 75, 'firstp', 'Here\'s the first paragraph of the About Page. More text here. Filling up the page. Typing enough so this will wrap around.') ; 
INSERT INTO `mjwp_postmeta` VALUES (386, 75, '_firstp', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (387, 75, 'sub_paragraphs', '<p>The second paragraph formatted with paragraph tags.</p>
<p>The third paragraph formatted with more paragraph tags. Hopefully these will work. I\'d love this site to actually be semantic instead of having to misuse break tags.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (388, 75, '_sub_paragraphs', 'field_537237152ad06') ; 
INSERT INTO `mjwp_postmeta` VALUES (389, 69, 'firstp', 'Here\'s the first paragraph of the About Page. More text here. Filling up the page. Typing enough so this will wrap around.') ; 
INSERT INTO `mjwp_postmeta` VALUES (390, 69, '_firstp', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (391, 69, 'sub_paragraphs', '<p>The second paragraph formatted with paragraph tags.</p>
<p>The third paragraph formatted with more paragraph tags. Hopefully these will work. I\'d love this site to actually be semantic instead of having to misuse break tags.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (392, 69, '_sub_paragraphs', 'field_537237152ad06') ; 
INSERT INTO `mjwp_postmeta` VALUES (393, 67, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:9:"about.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (394, 76, 'firstp', 'Welcome to The Music Journal. This is a site where I can write about favorite tracks I\'ve heard, and projects I\'ve been inspired to create because of events I\'ve attended, movies I\'ve seen, books I\'ve read and more.') ; 
INSERT INTO `mjwp_postmeta` VALUES (395, 76, '_firstp', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (396, 76, 'sub_paragraphs', '<p>Looking for to writing more after I get all of the code converted for the site. It\'s going better than I thought it would - that\'s reassuring.</p>
<p>I think I\'ve watched the WP videos on TTH about 20 times. I still haven\'t finished the custom theme track - ha. This should be enough text to test the theme.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (397, 76, '_sub_paragraphs', 'field_537237152ad06') ; 
INSERT INTO `mjwp_postmeta` VALUES (398, 7, 'firstp', 'Welcome to The Music Journal. This is a site where I can write about favorite tracks I\'ve heard, and projects I\'ve been inspired to create because of events I\'ve attended, movies I\'ve seen, books I\'ve read and more.') ; 
INSERT INTO `mjwp_postmeta` VALUES (399, 7, '_firstp', 'field_537232fb38c54') ; 
INSERT INTO `mjwp_postmeta` VALUES (400, 7, 'sub_paragraphs', '<p>Looking for to writing more after I get all of the code converted for the site. It\'s going better than I thought it would - that\'s reassuring.</p>
<p>I think I\'ve watched the WP videos on TTH about 20 times. I still haven\'t finished the custom theme track - ha. This should be enough text to test the theme.</p>') ; 
INSERT INTO `mjwp_postmeta` VALUES (401, 7, '_sub_paragraphs', 'field_537237152ad06') ; 
INSERT INTO `mjwp_postmeta` VALUES (407, 80, 'title', 'Punk Guitar Sound') ; 
INSERT INTO `mjwp_postmeta` VALUES (408, 80, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (409, 80, 'style', 'Style: Punk, rock, retro') ; 
INSERT INTO `mjwp_postmeta` VALUES (410, 80, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (411, 80, 'inspiration', 'Inspiration: The Ramones') ; 
INSERT INTO `mjwp_postmeta` VALUES (412, 80, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (413, 80, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (414, 80, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (417, 83, 'title', 'Drone Track') ; 
INSERT INTO `mjwp_postmeta` VALUES (418, 83, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (419, 83, 'style', 'Style: Ambient, dark, avant-garde, experimental, noise') ; 
INSERT INTO `mjwp_postmeta` VALUES (420, 83, '_style', 'field_536e6198442b3') ; 
INSERT INTO `mjwp_postmeta` VALUES (421, 83, 'inspiration', 'Inspiration: "Only Lovers Left Alive"') ; 
INSERT INTO `mjwp_postmeta` VALUES (422, 83, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (423, 83, 'project_description', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.') ; 
INSERT INTO `mjwp_postmeta` VALUES (424, 83, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (426, 23, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"project";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (431, 88, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (432, 88, '_edit_lock', '1400181084:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (433, 89, 'title', 'Pagination Project') ; 
INSERT INTO `mjwp_postmeta` VALUES (434, 89, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (435, 89, 'inspiration', 'Inspiration: Learning PHP') ; 
INSERT INTO `mjwp_postmeta` VALUES (436, 89, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (437, 89, 'project_description', 'Testing a function from the WordPress Codex site. It\'s a gray humid day. Moving along on the WP conversion. Making much more progress than yesterday. I\'m getting close to the point where I\'ll be writing the articles and excerpts.') ; 
INSERT INTO `mjwp_postmeta` VALUES (438, 89, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (439, 88, 'title', 'Pagination Project') ; 
INSERT INTO `mjwp_postmeta` VALUES (440, 88, '_title', 'field_536e60cc442b2') ; 
INSERT INTO `mjwp_postmeta` VALUES (441, 88, 'inspiration', 'Inspiration: Learning PHP') ; 
INSERT INTO `mjwp_postmeta` VALUES (442, 88, '_inspiration', 'field_536e6216442b4') ; 
INSERT INTO `mjwp_postmeta` VALUES (443, 88, 'project_description', 'Testing a function from the WordPress Codex site. It\'s a gray humid day. Moving along on the WP conversion. Making much more progress than yesterday. I\'m getting close to the point where I\'ll be writing the articles and excerpts.') ; 
INSERT INTO `mjwp_postmeta` VALUES (444, 88, '_project_description', 'field_536e6244442b5') ; 
INSERT INTO `mjwp_postmeta` VALUES (445, 88, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `mjwp_postmeta` VALUES (446, 88, '_wp_trash_meta_time', '1400187716') ; 
INSERT INTO `mjwp_postmeta` VALUES (447, 90, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (448, 90, 'field_53757e45c05e8', 'a:11:{s:3:"key";s:19:"field_53757e45c05e8";s:5:"label";s:11:"Album Cover";s:4:"name";s:11:"album_cover";s:4:"type";s:5:"image";s:12:"instructions";s:45:"Upload the album cover
Ideal size: 200x200px";s:8:"required";s:1:"1";s:11:"save_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (449, 90, 'field_53757ea6c05e9', 'a:14:{s:3:"key";s:19:"field_53757ea6c05e9";s:5:"label";s:11:"Album Title";s:4:"name";s:11:"album_title";s:4:"type";s:4:"text";s:12:"instructions";s:22:"Enter album title here";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:14:"ex. Abbey Road";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (450, 90, 'field_53757ed8c05ea', 'a:14:{s:3:"key";s:19:"field_53757ed8c05ea";s:5:"label";s:15:"Album Artist(s)";s:4:"name";s:15:"album_artist(s)";s:4:"type";s:4:"text";s:12:"instructions";s:26:"Enter album artist(s) here";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:15:"ex. The Beatles";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (452, 90, 'position', 'normal') ; 
INSERT INTO `mjwp_postmeta` VALUES (453, 90, 'layout', 'no_box') ; 
INSERT INTO `mjwp_postmeta` VALUES (454, 90, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}') ; 
INSERT INTO `mjwp_postmeta` VALUES (455, 90, '_edit_lock', '1400209920:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (456, 91, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (457, 91, '_edit_lock', '1400209435:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (458, 91, '_wp_page_template', 'wp-config.php') ; 
INSERT INTO `mjwp_postmeta` VALUES (459, 93, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (460, 93, '_edit_lock', '1400210119:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (461, 94, '_wp_attached_file', '2014/05/BacktoBlack.jpg') ; 
INSERT INTO `mjwp_postmeta` VALUES (462, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:23:"2014/05/BacktoBlack.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"BacktoBlack-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `mjwp_postmeta` VALUES (463, 94, '_wp_attachment_image_alt', 'Album Cover: Back to Black - Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (464, 95, 'album_cover', '94') ; 
INSERT INTO `mjwp_postmeta` VALUES (465, 95, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (466, 95, 'album_title', 'Back to Black') ; 
INSERT INTO `mjwp_postmeta` VALUES (467, 95, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (468, 95, 'album_artist(s)', 'Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (469, 95, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (470, 93, 'album_cover', '94') ; 
INSERT INTO `mjwp_postmeta` VALUES (471, 93, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (472, 93, 'album_title', 'Back to Black') ; 
INSERT INTO `mjwp_postmeta` VALUES (473, 93, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (474, 93, 'album_artist(s)', 'Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (475, 93, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (476, 96, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (477, 96, '_edit_lock', '1400209862:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (478, 97, '_wp_attached_file', '2014/05/ThisBinaryUniverse.jpg') ; 
INSERT INTO `mjwp_postmeta` VALUES (479, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:30:"2014/05/ThisBinaryUniverse.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"ThisBinaryUniverse-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `mjwp_postmeta` VALUES (480, 97, '_wp_attachment_image_alt', 'Album Cover: This Binary Universe - BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (481, 98, 'album_cover', '97') ; 
INSERT INTO `mjwp_postmeta` VALUES (482, 98, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (483, 98, 'album_title', 'This Binary Universe') ; 
INSERT INTO `mjwp_postmeta` VALUES (484, 98, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (485, 98, 'album_artist(s)', 'BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (486, 98, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (487, 96, 'album_cover', '97') ; 
INSERT INTO `mjwp_postmeta` VALUES (488, 96, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (489, 96, 'album_title', 'This Binary Universe') ; 
INSERT INTO `mjwp_postmeta` VALUES (490, 96, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (491, 96, 'album_artist(s)', 'BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (492, 96, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (493, 99, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (494, 99, '_edit_lock', '1400209844:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (495, 100, '_wp_attached_file', '2014/05/OnlyLoversLeftAliveSoundtrack.jpg') ; 
INSERT INTO `mjwp_postmeta` VALUES (496, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:41:"2014/05/OnlyLoversLeftAliveSoundtrack.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"OnlyLoversLeftAliveSoundtrack-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `mjwp_postmeta` VALUES (497, 100, '_wp_attachment_image_alt', 'Album Cover: Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (498, 101, 'album_cover', '100') ; 
INSERT INTO `mjwp_postmeta` VALUES (499, 101, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (500, 101, 'album_title', 'Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (501, 101, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (502, 101, 'album_artist(s)', 'Jozef Van Wissem / SQÜRL') ; 
INSERT INTO `mjwp_postmeta` VALUES (503, 101, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (504, 99, 'album_cover', '100') ; 
INSERT INTO `mjwp_postmeta` VALUES (505, 99, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (506, 99, 'album_title', 'Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (507, 99, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (508, 99, 'album_artist(s)', 'Jozef Van Wissem / SQÜRL') ; 
INSERT INTO `mjwp_postmeta` VALUES (509, 99, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (511, 90, 'field_5375818c31538', 'a:14:{s:3:"key";s:19:"field_5375818c31538";s:5:"label";s:20:"Album Cover Alt Text";s:4:"name";s:13:"album_alt_txt";s:4:"type";s:4:"text";s:12:"instructions";s:38:"Enter the image\'s alternate text here.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (512, 90, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"album";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `mjwp_postmeta` VALUES (513, 102, 'album_cover', '100') ; 
INSERT INTO `mjwp_postmeta` VALUES (514, 102, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (515, 102, 'album_alt_txt', 'Album Cover: Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (516, 102, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (517, 102, 'album_title', 'Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (518, 102, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (519, 102, 'album_artist(s)', 'Jozef Van Wissem / SQÜRL') ; 
INSERT INTO `mjwp_postmeta` VALUES (520, 102, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (521, 99, 'album_alt_txt', 'Album Cover: Only Lovers Left Alive') ; 
INSERT INTO `mjwp_postmeta` VALUES (522, 99, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (523, 103, 'album_cover', '97') ; 
INSERT INTO `mjwp_postmeta` VALUES (524, 103, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (525, 103, 'album_alt_txt', 'Album Cover: This Binary Universe - BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (526, 103, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (527, 103, 'album_title', 'This Binary Universe') ; 
INSERT INTO `mjwp_postmeta` VALUES (528, 103, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (529, 103, 'album_artist(s)', 'BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (530, 103, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (531, 96, 'album_alt_txt', 'Album Cover: This Binary Universe - BT') ; 
INSERT INTO `mjwp_postmeta` VALUES (532, 96, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (533, 104, 'album_cover', '94') ; 
INSERT INTO `mjwp_postmeta` VALUES (534, 104, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (535, 104, 'album_alt_txt', 'Album Cover: Back to Black - Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (536, 104, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (537, 104, 'album_title', 'Back to Black') ; 
INSERT INTO `mjwp_postmeta` VALUES (538, 104, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (539, 104, 'album_artist(s)', 'Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (540, 104, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (541, 93, 'album_alt_txt', 'Album Cover: Back to Black - Amy Winehouse') ; 
INSERT INTO `mjwp_postmeta` VALUES (542, 93, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (543, 105, '_edit_last', '1') ; 
INSERT INTO `mjwp_postmeta` VALUES (544, 105, '_edit_lock', '1400211147:1') ; 
INSERT INTO `mjwp_postmeta` VALUES (545, 106, 'album_cover', '94') ; 
INSERT INTO `mjwp_postmeta` VALUES (546, 106, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (547, 106, 'album_alt_txt', 'B2B') ; 
INSERT INTO `mjwp_postmeta` VALUES (548, 106, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (549, 106, 'album_title', 'B2B') ; 
INSERT INTO `mjwp_postmeta` VALUES (550, 106, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (551, 106, 'album_artist(s)', 'AW') ; 
INSERT INTO `mjwp_postmeta` VALUES (552, 106, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (553, 105, 'album_cover', '94') ; 
INSERT INTO `mjwp_postmeta` VALUES (554, 105, '_album_cover', 'field_53757e45c05e8') ; 
INSERT INTO `mjwp_postmeta` VALUES (555, 105, 'album_alt_txt', 'B2B') ; 
INSERT INTO `mjwp_postmeta` VALUES (556, 105, '_album_alt_txt', 'field_5375818c31538') ; 
INSERT INTO `mjwp_postmeta` VALUES (557, 105, 'album_title', 'B2B') ; 
INSERT INTO `mjwp_postmeta` VALUES (558, 105, '_album_title', 'field_53757ea6c05e9') ; 
INSERT INTO `mjwp_postmeta` VALUES (559, 105, 'album_artist(s)', 'AW') ; 
INSERT INTO `mjwp_postmeta` VALUES (560, 105, '_album_artist(s)', 'field_53757ed8c05ea') ; 
INSERT INTO `mjwp_postmeta` VALUES (561, 105, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `mjwp_postmeta` VALUES (562, 105, '_wp_trash_meta_time', '1400211307') ;
#
# End of data contents of table mjwp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_posts`
#

DROP TABLE IF EXISTS `mjwp_posts`;


#
# Table structure of table `mjwp_posts`
#

CREATE TABLE `mjwp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_posts (106 records)
#
 
INSERT INTO `mjwp_posts` VALUES (1, 1, '2014-05-10 15:13:55', '2014-05-10 15:13:55', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2014-05-10 18:11:43', '2014-05-10 18:11:43', '', 0, 'http://localhost/themusicjournal/?p=1', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (2, 1, '2014-05-10 15:13:55', '2014-05-10 15:13:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost/themusicjournal/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-05-10 16:50:55', '2014-05-10 16:50:55', '', 0, 'http://localhost/themusicjournal/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (4, 1, '2014-05-10 16:50:55', '2014-05-10 16:50:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost/themusicjournal/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-05-10 16:50:55', '2014-05-10 16:50:55', '', 2, 'http://localhost/themusicjournal/?p=4', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (5, 1, '2014-05-10 16:51:12', '2014-05-10 16:51:12', '', 'Main', '', 'publish', 'open', 'open', '', 'main', '', '', '2014-05-10 16:51:12', '2014-05-10 16:51:12', '', 0, 'http://localhost/themusicjournal/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (6, 1, '2014-05-10 16:51:12', '2014-05-10 16:51:12', '', 'Main', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-05-10 16:51:12', '2014-05-10 16:51:12', '', 5, 'http://localhost/themusicjournal/?p=6', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (7, 1, '2014-05-10 16:52:17', '2014-05-10 16:52:17', '', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-05-13 15:35:50', '2014-05-13 15:35:50', '', 0, 'http://localhost/themusicjournal/?page_id=7', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (8, 1, '2014-05-10 16:52:17', '2014-05-10 16:52:17', 'Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'About', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-05-10 16:52:17', '2014-05-10 16:52:17', '', 7, 'http://localhost/themusicjournal/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (9, 1, '2014-05-10 16:52:43', '2014-05-10 16:52:43', '', 'Blog', '', 'publish', 'open', 'open', '', 'blog', '', '', '2014-05-10 16:52:43', '2014-05-10 16:52:43', '', 0, 'http://localhost/themusicjournal/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (10, 1, '2014-05-10 16:52:43', '2014-05-10 16:52:43', '', 'Blog', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-05-10 16:52:43', '2014-05-10 16:52:43', '', 9, 'http://localhost/themusicjournal/?p=10', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (11, 1, '2014-05-10 16:53:57', '2014-05-10 16:53:57', '', 'Projects', '', 'publish', 'open', 'closed', '', 'projects', '', '', '2014-05-12 20:16:11', '2014-05-12 20:16:11', '', 0, 'http://localhost/themusicjournal/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (13, 1, '2014-05-10 16:55:30', '2014-05-10 16:55:30', '', 'Inspirations', '', 'publish', 'open', 'closed', '', 'inspirations', '', '', '2014-05-16 19:06:02', '2014-05-16 19:06:02', '', 0, 'http://localhost/themusicjournal/?page_id=13', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (14, 1, '2014-05-10 16:55:30', '2014-05-10 16:55:30', '', 'Inspiration', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-05-10 16:55:30', '2014-05-10 16:55:30', '', 13, 'http://localhost/themusicjournal/?p=14', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (15, 1, '2014-05-10 17:00:21', '2014-05-10 17:00:21', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'First Blog Post', '', 'publish', 'open', 'open', '', 'first-blog-post', '', '', '2014-05-10 17:00:21', '2014-05-10 17:00:21', '', 0, 'http://localhost/themusicjournal/?p=15', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (16, 1, '2014-05-10 17:00:21', '2014-05-10 17:00:21', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'First Blog Post', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2014-05-10 17:00:21', '2014-05-10 17:00:21', '', 15, 'http://localhost/themusicjournal/?p=16', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (17, 1, '2014-05-10 17:01:06', '2014-05-10 17:01:06', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Reading and Lyric Writing', '', 'publish', 'open', 'open', '', 'reading-and-lyric-writing', '', '', '2014-05-10 17:01:06', '2014-05-10 17:01:06', '', 0, 'http://localhost/themusicjournal/?p=17', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (18, 1, '2014-05-10 17:01:06', '2014-05-10 17:01:06', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Reading and Lyric Writing', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-05-10 17:01:06', '2014-05-10 17:01:06', '', 17, 'http://localhost/themusicjournal/?p=18', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (19, 1, '2014-05-10 17:01:27', '2014-05-10 17:01:27', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', '1970s New York', '', 'publish', 'open', 'open', '', '1970s-new-york', '', '', '2014-05-10 17:01:27', '2014-05-10 17:01:27', '', 0, 'http://localhost/themusicjournal/?p=19', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (20, 1, '2014-05-10 17:01:27', '2014-05-10 17:01:27', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', '1970s New York', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-05-10 17:01:27', '2014-05-10 17:01:27', '', 19, 'http://localhost/themusicjournal/?p=20', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (21, 1, '2014-05-10 17:01:53', '2014-05-10 17:01:53', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Jazz Symposium', 'Here is the excerpt for the Jazz Symposium post. Let\'s see if that conditional if else statement worked. Going to post this now. Man is it humid today.', 'publish', 'open', 'open', '', 'jazz-symposium', '', '', '2014-05-15 18:05:31', '2014-05-15 18:05:31', '', 0, 'http://localhost/themusicjournal/?p=21', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (22, 1, '2014-05-10 17:01:53', '2014-05-10 17:01:53', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Jazz Symposium', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-05-10 17:01:53', '2014-05-10 17:01:53', '', 21, 'http://localhost/themusicjournal/?p=22', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (23, 1, '2014-05-10 17:32:14', '2014-05-10 17:32:14', '', 'Project', '', 'publish', 'closed', 'closed', '', 'acf_project', '', '', '2014-05-15 17:05:54', '2014-05-15 17:05:54', '', 0, 'http://localhost/themusicjournal/?post_type=acf&#038;p=23', 0, 'acf', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (25, 1, '2014-05-10 17:38:59', '2014-05-10 17:38:59', '', 'Inspiration', '', 'publish', 'closed', 'closed', '', 'acf_inspiration', '', '', '2014-05-12 23:05:23', '2014-05-12 23:05:23', '', 0, 'http://localhost/themusicjournal/?post_type=acf&#038;p=25', 0, 'acf', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (26, 1, '2014-05-10 17:47:47', '2014-05-10 17:47:47', '', 'First Project', '', 'publish', 'open', 'open', '', 'first-project', '', '', '2014-05-15 17:07:55', '2014-05-15 17:07:55', '', 0, 'http://localhost/themusicjournal/?post_type=project&#038;p=26', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (27, 1, '2014-05-10 17:47:47', '2014-05-10 17:47:47', '', 'First Project', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2014-05-10 17:47:47', '2014-05-10 17:47:47', '', 26, 'http://localhost/themusicjournal/?p=27', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (28, 1, '2014-05-10 17:49:02', '2014-05-10 17:49:02', '', 'Writing for Strings', '', 'publish', 'open', 'open', '', 'writing-for-strings', '', '', '2014-05-15 17:07:19', '2014-05-15 17:07:19', '', 0, 'http://localhost/themusicjournal/?post_type=project&#038;p=28', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (29, 1, '2014-05-10 17:49:02', '2014-05-10 17:49:02', '', 'Writing for Strings', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-05-10 17:49:02', '2014-05-10 17:49:02', '', 28, 'http://localhost/themusicjournal/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (30, 1, '2014-05-10 17:49:49', '2014-05-10 17:49:49', '', 'Punk Guitar Sound', 'Making Judy is a Punk style guitar sounds.', 'publish', 'open', 'open', '', 'punk-guitar-sound', '', '', '2014-05-15 16:39:17', '2014-05-15 16:39:17', '', 0, 'http://localhost/themusicjournal/?post_type=project&#038;p=30', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (31, 1, '2014-05-10 17:49:49', '2014-05-10 17:49:49', '', 'Punk Guitar Sound', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2014-05-10 17:49:49', '2014-05-10 17:49:49', '', 30, 'http://localhost/themusicjournal/?p=31', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (32, 1, '2014-05-10 17:51:25', '2014-05-10 17:51:25', '', 'Drone Track', 'This is the excerpt for the Drone Track project. Maybe two or three sentences would be good here. Let\'s make it three and see if I\'ll need to update the CSS.', 'publish', 'open', 'open', '', 'drone-track', '', '', '2014-05-15 16:37:17', '2014-05-15 16:37:17', '', 0, 'http://localhost/themusicjournal/?post_type=project&#038;p=32', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (33, 1, '2014-05-10 17:51:25', '2014-05-10 17:51:25', '', 'Drone Track', '', 'inherit', 'open', 'open', '', '32-revision-v1', '', '', '2014-05-10 17:51:25', '2014-05-10 17:51:25', '', 32, 'http://localhost/themusicjournal/?p=33', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (34, 1, '2014-05-10 17:55:06', '2014-05-10 17:55:06', '', 'Poker Face (Polka Phaze)', '', 'publish', 'open', 'open', '', 'poker-face-polka-phaze', '', '', '2014-05-12 23:08:45', '2014-05-12 23:08:45', '', 0, 'http://localhost/themusicjournal/?post_type=inspiration&#038;p=34', 0, 'inspiration', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (35, 1, '2014-05-10 17:53:50', '2014-05-10 17:53:50', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 17:53:50', '2014-05-10 17:53:50', '', 34, 'http://localhost/themusicjournal/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (36, 1, '2014-05-10 17:55:06', '2014-05-10 17:55:06', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 17:55:06', '2014-05-10 17:55:06', '', 34, 'http://localhost/themusicjournal/?p=36', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (37, 1, '2014-05-10 18:04:41', '2014-05-10 18:04:41', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 18:04:41', '2014-05-10 18:04:41', '', 34, 'http://localhost/themusicjournal/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (38, 1, '2014-05-10 18:05:16', '2014-05-10 18:05:16', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 18:05:16', '2014-05-10 18:05:16', '', 34, 'http://localhost/themusicjournal/?p=38', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (39, 1, '2014-05-10 18:06:01', '2014-05-10 18:06:01', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 18:06:01', '2014-05-10 18:06:01', '', 34, 'http://localhost/themusicjournal/?p=39', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (41, 1, '2014-05-10 18:11:43', '2014-05-10 18:11:43', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-10 18:11:43', '2014-05-10 18:11:43', '', 1, 'http://localhost/themusicjournal/?p=41', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (42, 1, '2014-05-10 18:13:58', '2014-05-10 18:13:58', '<a href="http://www.youtube.com/watch?v=Oeu3prTK">http://www.youtube.com/watch?v=Oeu3prTK</a>', 'First Blog Post', '', 'inherit', 'open', 'open', '', '15-autosave-v1', '', '', '2014-05-10 18:13:58', '2014-05-10 18:13:58', '', 15, 'http://localhost/themusicjournal/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (43, 1, '2014-05-10 18:17:53', '2014-05-10 18:17:53', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-10 18:17:53', '2014-05-10 18:17:53', '', 34, 'http://localhost/themusicjournal/?p=43', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (45, 1, '2014-05-12 17:30:46', '2014-05-12 17:30:46', '', 'Projects', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-05-12 17:30:46', '2014-05-12 17:30:46', '', 11, 'http://localhost/themusicjournal/?p=45', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (46, 1, '2014-05-12 17:31:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-12 17:31:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=46', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (47, 1, '2014-05-12 17:31:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-12 17:31:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=47', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (48, 1, '2014-05-12 17:31:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-12 17:31:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=48', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (49, 1, '2014-05-12 17:31:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-12 17:31:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=49', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (50, 1, '2014-05-12 17:31:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-12 17:31:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=50', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (51, 1, '2014-05-12 18:28:12', '2014-05-12 18:28:12', ' ', '', '', 'publish', 'open', 'open', '', '51', '', '', '2014-05-12 18:28:12', '2014-05-12 18:28:12', '', 0, 'http://localhost/themusicjournal/?p=51', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (52, 1, '2014-05-12 18:28:12', '2014-05-12 18:28:12', ' ', '', '', 'publish', 'open', 'open', '', '52', '', '', '2014-05-12 18:28:12', '2014-05-12 18:28:12', '', 0, 'http://localhost/themusicjournal/?p=52', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (53, 1, '2014-05-12 18:28:12', '2014-05-12 18:28:12', ' ', '', '', 'publish', 'open', 'open', '', '53', '', '', '2014-05-12 18:28:12', '2014-05-12 18:28:12', '', 0, 'http://localhost/themusicjournal/?p=53', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (54, 1, '2014-05-12 18:28:12', '2014-05-12 18:28:12', ' ', '', '', 'publish', 'open', 'open', '', '54', '', '', '2014-05-12 18:28:12', '2014-05-12 18:28:12', '', 0, 'http://localhost/themusicjournal/?p=54', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (55, 1, '2014-05-12 18:28:12', '2014-05-12 18:28:12', ' ', '', '', 'publish', 'open', 'open', '', '55', '', '', '2014-05-12 18:28:12', '2014-05-12 18:28:12', '', 0, 'http://localhost/themusicjournal/?p=55', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (56, 1, '2014-05-12 22:28:03', '2014-05-12 22:28:03', '<pre>A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.</pre>', 'Jazz Symposium', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-05-12 22:28:03', '2014-05-12 22:28:03', '', 21, 'http://localhost/themusicjournal/21-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (57, 1, '2014-05-12 22:29:54', '2014-05-12 22:29:54', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Jazz Symposium', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-05-12 22:29:54', '2014-05-12 22:29:54', '', 21, 'http://localhost/themusicjournal/21-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (58, 1, '2014-05-12 23:01:40', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-12 23:01:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?post_type=inspiration&p=58', 0, 'inspiration', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (59, 1, '2014-05-12 23:06:11', '2014-05-12 23:06:11', '', 'Poker Face (Polka Phaze)', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-05-12 23:06:11', '2014-05-12 23:06:11', '', 34, 'http://localhost/themusicjournal/34-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (60, 1, '2014-05-12 23:36:11', '2014-05-12 23:36:11', '', 'Ice Dance', '', 'publish', 'open', 'open', '', 'ice-dance', '', '', '2014-05-12 23:37:12', '2014-05-12 23:37:12', '', 0, 'http://localhost/themusicjournal/?post_type=inspiration&#038;p=60', 0, 'inspiration', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (61, 1, '2014-05-12 23:36:11', '2014-05-12 23:36:11', '', 'Ice Dance', '', 'inherit', 'open', 'open', '', '60-revision-v1', '', '', '2014-05-12 23:36:11', '2014-05-12 23:36:11', '', 60, 'http://localhost/themusicjournal/60-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (62, 1, '2014-05-12 23:37:12', '2014-05-12 23:37:12', '', 'Ice Dance', '', 'inherit', 'open', 'open', '', '60-revision-v1', '', '', '2014-05-12 23:37:12', '2014-05-12 23:37:12', '', 60, 'http://localhost/themusicjournal/60-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (63, 1, '2014-05-12 23:38:38', '2014-05-12 23:38:38', '', 'Cissy Strut', '', 'publish', 'open', 'open', '', 'cissy-strut', '', '', '2014-05-12 23:38:38', '2014-05-12 23:38:38', '', 0, 'http://localhost/themusicjournal/?post_type=inspiration&#038;p=63', 0, 'inspiration', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (64, 1, '2014-05-12 23:38:38', '2014-05-12 23:38:38', '', 'Cissy Strut', '', 'inherit', 'open', 'open', '', '63-revision-v1', '', '', '2014-05-12 23:38:38', '2014-05-12 23:38:38', '', 63, 'http://localhost/themusicjournal/63-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (65, 1, '2014-05-12 23:39:51', '2014-05-12 23:39:51', '', 'Go Do', '', 'publish', 'open', 'open', '', 'go-do', '', '', '2014-05-12 23:39:51', '2014-05-12 23:39:51', '', 0, 'http://localhost/themusicjournal/?post_type=inspiration&#038;p=65', 0, 'inspiration', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (66, 1, '2014-05-12 23:39:51', '2014-05-12 23:39:51', '', 'Go Do', '', 'inherit', 'open', 'open', '', '65-revision-v1', '', '', '2014-05-12 23:39:51', '2014-05-12 23:39:51', '', 65, 'http://localhost/themusicjournal/65-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (67, 1, '2014-05-13 15:00:20', '2014-05-13 15:00:20', '', 'About', '', 'publish', 'closed', 'closed', '', 'acf_about', '', '', '2014-05-13 15:31:22', '2014-05-13 15:31:22', '', 0, 'http://localhost/themusicjournal/?post_type=acf&#038;p=67', 0, 'acf', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (68, 1, '2014-05-13 15:02:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-13 15:02:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?post_type=about&p=68', 0, 'about', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (69, 1, '2014-05-13 15:06:19', '2014-05-13 15:06:19', '', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-05-13 15:20:14', '2014-05-13 15:20:14', '', 0, 'http://localhost/themusicjournal/?post_type=about&#038;p=69', 0, 'about', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (70, 1, '2014-05-13 15:06:19', '2014-05-13 15:06:19', '', 'About', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-05-13 15:06:19', '2014-05-13 15:06:19', '', 69, 'http://localhost/themusicjournal/69-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (71, 1, '2014-05-13 15:10:37', '2014-05-13 15:10:37', '', 'About', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-05-13 15:10:37', '2014-05-13 15:10:37', '', 7, 'http://localhost/themusicjournal/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (72, 1, '2014-05-13 15:11:33', '2014-05-13 15:11:33', '', 'About', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-05-13 15:11:33', '2014-05-13 15:11:33', '', 69, 'http://localhost/themusicjournal/69-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (73, 1, '2014-05-13 15:12:22', '2014-05-13 15:12:22', '', 'About', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-05-13 15:12:22', '2014-05-13 15:12:22', '', 69, 'http://localhost/themusicjournal/69-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (74, 1, '2014-05-13 15:12:29', '2014-05-13 15:12:29', '', 'About', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-05-13 15:12:29', '2014-05-13 15:12:29', '', 69, 'http://localhost/themusicjournal/69-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (75, 1, '2014-05-13 15:20:14', '2014-05-13 15:20:14', '', 'About', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-05-13 15:20:14', '2014-05-13 15:20:14', '', 69, 'http://localhost/themusicjournal/69-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (76, 1, '2014-05-13 15:35:50', '2014-05-13 15:35:50', '', 'About', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-05-13 15:35:50', '2014-05-13 15:35:50', '', 7, 'http://localhost/themusicjournal/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (77, 1, '2014-05-15 15:40:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 15:40:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?post_type=project&p=77', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (78, 1, '2014-05-15 15:48:59', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 15:48:59', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=78', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (79, 1, '2014-05-15 15:49:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 15:49:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?post_type=project&p=79', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (80, 1, '2014-05-15 15:51:11', '2014-05-15 15:51:11', '', 'Punk Guitar Sound', 'Making Judy is a Punk style guitar sounds.', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2014-05-15 15:51:11', '2014-05-15 15:51:11', '', 30, 'http://localhost/themusicjournal/30-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (81, 1, '2014-05-15 15:57:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 15:57:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?post_type=project&p=81', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (82, 1, '2014-05-15 16:36:36', '2014-05-15 16:36:36', '', 'Drone Track', 'This is the excerpt for the Drone Track project. Maybe two or three sentences would be good ', 'inherit', 'open', 'open', '', '32-autosave-v1', '', '', '2014-05-15 16:36:36', '2014-05-15 16:36:36', '', 32, 'http://localhost/themusicjournal/32-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (83, 1, '2014-05-15 16:37:17', '2014-05-15 16:37:17', '', 'Drone Track', 'This is the excerpt for the Drone Track project. Maybe two or three sentences would be good here. Let\'s make it three and see if I\'ll need to update the CSS.', 'inherit', 'open', 'open', '', '32-revision-v1', '', '', '2014-05-15 16:37:17', '2014-05-15 16:37:17', '', 32, 'http://localhost/themusicjournal/32-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (84, 1, '2014-05-15 17:56:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 17:56:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=84', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (85, 1, '2014-05-15 18:03:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-15 18:03:54', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=85', 0, 'post', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (86, 1, '2014-05-15 18:05:26', '2014-05-15 18:05:26', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Jazz Symposium', 'Here is the excerpt for the Jazz Symposium post. Let\'s see if that conditional if else statement worked. Going to post this now. Man is it humid today.', 'inherit', 'open', 'open', '', '21-autosave-v1', '', '', '2014-05-15 18:05:26', '2014-05-15 18:05:26', '', 21, 'http://localhost/themusicjournal/21-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (87, 1, '2014-05-15 18:05:31', '2014-05-15 18:05:31', 'A Jacobs noticed that cinematographers used editing methods like reverse-shot patterns to make it appear that the portrait was looking back, as in Laura—in which a portrait has to stand in for the missing character in McPherson’s mind. They also used eye-line matches between the portraits and characters in tracking shots—or special effects with color and sound. For example, Bernard Herrmann’s well-known refrain “Carlotta’s Portrait” plays as Scottie follows Madeleine into an art gallery, where she stares at a portrait of a woman eerily similar to her—an eeriness conveyed by the camera’s glide between their shared features, to the sound of an unsettling score.', 'Jazz Symposium', 'Here is the excerpt for the Jazz Symposium post. Let\'s see if that conditional if else statement worked. Going to post this now. Man is it humid today.', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-05-15 18:05:31', '2014-05-15 18:05:31', '', 21, 'http://localhost/themusicjournal/21-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (88, 1, '2014-05-15 19:13:17', '2014-05-15 19:13:17', '', 'Pagination Test Project', 'A quick test to check the pagination and a new function.', 'trash', 'open', 'open', '', 'pagination-test-project', '', '', '2014-05-15 21:01:56', '2014-05-15 21:01:56', '', 0, 'http://localhost/themusicjournal/?post_type=project&#038;p=88', 0, 'project', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (89, 1, '2014-05-15 19:13:17', '2014-05-15 19:13:17', '', 'Pagination Test Project', 'A quick test to check the pagination and a new function.', 'inherit', 'open', 'open', '', '88-revision-v1', '', '', '2014-05-15 19:13:17', '2014-05-15 19:13:17', '', 88, 'http://localhost/themusicjournal/88-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (90, 1, '2014-05-16 03:00:05', '2014-05-16 03:00:05', '', 'Album', '', 'publish', 'closed', 'closed', '', 'acf_album', '', '', '2014-05-16 03:12:00', '2014-05-16 03:12:00', '', 0, 'http://localhost/themusicjournal/?post_type=acf&#038;p=90', 0, 'acf', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (91, 1, '2014-05-16 03:00:58', '2014-05-16 03:00:58', '', 'In Rotation', '', 'publish', 'open', 'open', '', 'inrotation', '', '', '2014-05-16 03:01:08', '2014-05-16 03:01:08', '', 0, 'http://localhost/themusicjournal/?page_id=91', 0, 'page', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (92, 1, '2014-05-16 03:00:58', '2014-05-16 03:00:58', '', 'In Rotation', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-05-16 03:00:58', '2014-05-16 03:00:58', '', 91, 'http://localhost/themusicjournal/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (93, 1, '2014-05-16 03:03:24', '2014-05-16 03:03:24', '', 'Back to Black', '', 'publish', 'open', 'open', '', 'back-to-black', '', '', '2014-05-16 03:13:10', '2014-05-16 03:13:10', '', 0, 'http://localhost/themusicjournal/?post_type=album&#038;p=93', 0, 'album', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (94, 1, '2014-05-16 03:02:28', '2014-05-16 03:02:28', '', 'BacktoBlack2', '', 'inherit', 'open', 'open', '', 'backtoblack', '', '', '2014-05-16 03:02:28', '2014-05-16 03:02:28', '', 93, 'http://localhost/themusicjournal/wp-content/uploads/2014/05/BacktoBlack.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `mjwp_posts` VALUES (95, 1, '2014-05-16 03:03:24', '2014-05-16 03:03:24', '', 'Back to Black', '', 'inherit', 'open', 'open', '', '93-revision-v1', '', '', '2014-05-16 03:03:24', '2014-05-16 03:03:24', '', 93, 'http://localhost/themusicjournal/93-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (96, 1, '2014-05-16 03:04:22', '2014-05-16 03:04:22', '', 'This Binary Universe', '', 'publish', 'open', 'open', '', 'this-binary-universe', '', '', '2014-05-16 03:12:54', '2014-05-16 03:12:54', '', 0, 'http://localhost/themusicjournal/?post_type=album&#038;p=96', 0, 'album', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (97, 1, '2014-05-16 03:03:52', '2014-05-16 03:03:52', '', 'ThisBinaryUniverse', '', 'inherit', 'open', 'open', '', 'thisbinaryuniverse', '', '', '2014-05-16 03:03:52', '2014-05-16 03:03:52', '', 96, 'http://localhost/themusicjournal/wp-content/uploads/2014/05/ThisBinaryUniverse.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `mjwp_posts` VALUES (98, 1, '2014-05-16 03:04:22', '2014-05-16 03:04:22', '', 'This Binary Universe', '', 'inherit', 'open', 'open', '', '96-revision-v1', '', '', '2014-05-16 03:04:22', '2014-05-16 03:04:22', '', 96, 'http://localhost/themusicjournal/96-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (99, 1, '2014-05-16 03:05:20', '2014-05-16 03:05:20', '', 'Only Lovers Left Alive', '', 'publish', 'open', 'open', '', 'only-lovers-left-alive', '', '', '2014-05-16 03:12:36', '2014-05-16 03:12:36', '', 0, 'http://localhost/themusicjournal/?post_type=album&#038;p=99', 0, 'album', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (100, 1, '2014-05-16 03:04:44', '2014-05-16 03:04:44', '', 'OnlyLoversLeftAliveSoundtrack', '', 'inherit', 'open', 'open', '', 'onlyloversleftalivesoundtrack', '', '', '2014-05-16 03:04:44', '2014-05-16 03:04:44', '', 99, 'http://localhost/themusicjournal/wp-content/uploads/2014/05/OnlyLoversLeftAliveSoundtrack.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `mjwp_posts` VALUES (101, 1, '2014-05-16 03:05:20', '2014-05-16 03:05:20', '', 'Only Lovers Left Alive', '', 'inherit', 'open', 'open', '', '99-revision-v1', '', '', '2014-05-16 03:05:20', '2014-05-16 03:05:20', '', 99, 'http://localhost/themusicjournal/99-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (102, 1, '2014-05-16 03:12:36', '2014-05-16 03:12:36', '', 'Only Lovers Left Alive', '', 'inherit', 'open', 'open', '', '99-revision-v1', '', '', '2014-05-16 03:12:36', '2014-05-16 03:12:36', '', 99, 'http://localhost/themusicjournal/99-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (103, 1, '2014-05-16 03:12:54', '2014-05-16 03:12:54', '', 'This Binary Universe', '', 'inherit', 'open', 'open', '', '96-revision-v1', '', '', '2014-05-16 03:12:54', '2014-05-16 03:12:54', '', 96, 'http://localhost/themusicjournal/96-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (104, 1, '2014-05-16 03:13:10', '2014-05-16 03:13:10', '', 'Back to Black', '', 'inherit', 'open', 'open', '', '93-revision-v1', '', '', '2014-05-16 03:13:10', '2014-05-16 03:13:10', '', 93, 'http://localhost/themusicjournal/93-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (105, 1, '2014-05-16 03:34:20', '2014-05-16 03:34:20', '', 'Second B2B', '', 'trash', 'open', 'open', '', 'second-b2b', '', '', '2014-05-16 03:35:07', '2014-05-16 03:35:07', '', 0, 'http://localhost/themusicjournal/?post_type=album&#038;p=105', 0, 'album', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (106, 1, '2014-05-16 03:34:20', '2014-05-16 03:34:20', '', 'Second B2B', '', 'inherit', 'open', 'open', '', '105-revision-v1', '', '', '2014-05-16 03:34:20', '2014-05-16 03:34:20', '', 105, 'http://localhost/themusicjournal/105-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (107, 1, '2014-05-16 18:55:27', '2014-05-16 18:55:27', '', 'Inspiration Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-05-16 18:55:27', '2014-05-16 18:55:27', '', 13, 'http://localhost/themusicjournal/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (108, 1, '2014-05-16 18:57:48', '2014-05-16 18:57:48', '', 'Inspired By', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-05-16 18:57:48', '2014-05-16 18:57:48', '', 13, 'http://localhost/themusicjournal/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (109, 1, '2014-05-16 19:03:44', '2014-05-16 19:03:44', '', 'Influences', '', 'inherit', 'open', 'open', '', '13-autosave-v1', '', '', '2014-05-16 19:03:44', '2014-05-16 19:03:44', '', 13, 'http://localhost/themusicjournal/13-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (110, 1, '2014-05-16 19:06:02', '2014-05-16 19:06:02', '', 'Inspirations', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-05-16 19:06:02', '2014-05-16 19:06:02', '', 13, 'http://localhost/themusicjournal/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `mjwp_posts` VALUES (111, 1, '2014-05-20 00:22:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-20 00:22:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/themusicjournal/?p=111', 0, 'post', '', 0) ;
#
# End of data contents of table mjwp_posts
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_term_relationships`
#

DROP TABLE IF EXISTS `mjwp_term_relationships`;


#
# Table structure of table `mjwp_term_relationships`
#

CREATE TABLE `mjwp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_term_relationships (25 records)
#
 
INSERT INTO `mjwp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (15, 1, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (17, 1, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (19, 1, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (21, 1, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (26, 6, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (26, 14, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (26, 15, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (28, 11, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (28, 12, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (28, 13, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (30, 8, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (30, 9, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (30, 10, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (32, 3, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (32, 4, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (32, 5, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (32, 6, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (32, 7, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (51, 2, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (52, 2, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (53, 2, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (54, 2, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (55, 2, 0) ; 
INSERT INTO `mjwp_term_relationships` VALUES (88, 17, 0) ;
#
# End of data contents of table mjwp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_term_taxonomy`
#

DROP TABLE IF EXISTS `mjwp_term_taxonomy`;


#
# Table structure of table `mjwp_term_taxonomy`
#

CREATE TABLE `mjwp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_term_taxonomy (17 records)
#
 
INSERT INTO `mjwp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 4) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 5) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (3, 3, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (4, 4, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (5, 5, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (6, 6, 'post_tag', '', 0, 2) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (7, 7, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (8, 8, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (9, 9, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (10, 10, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (11, 11, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (12, 12, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (13, 13, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (14, 14, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (15, 15, 'post_tag', '', 0, 1) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (16, 16, 'post_tag', '', 0, 0) ; 
INSERT INTO `mjwp_term_taxonomy` VALUES (17, 17, 'post_tag', '', 0, 0) ;
#
# End of data contents of table mjwp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_terms`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_terms`
#

DROP TABLE IF EXISTS `mjwp_terms`;


#
# Table structure of table `mjwp_terms`
#

CREATE TABLE `mjwp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_terms (17 records)
#
 
INSERT INTO `mjwp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `mjwp_terms` VALUES (2, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `mjwp_terms` VALUES (3, 'ambient', 'ambient', 0) ; 
INSERT INTO `mjwp_terms` VALUES (4, 'dark', 'dark', 0) ; 
INSERT INTO `mjwp_terms` VALUES (5, 'avant-garde', 'avant-garde', 0) ; 
INSERT INTO `mjwp_terms` VALUES (6, 'experimental', 'experimental', 0) ; 
INSERT INTO `mjwp_terms` VALUES (7, 'noise', 'noise', 0) ; 
INSERT INTO `mjwp_terms` VALUES (8, 'punk', 'punk', 0) ; 
INSERT INTO `mjwp_terms` VALUES (9, 'rock', 'rock', 0) ; 
INSERT INTO `mjwp_terms` VALUES (10, 'retro', 'retro', 0) ; 
INSERT INTO `mjwp_terms` VALUES (11, 'classical', 'classical', 0) ; 
INSERT INTO `mjwp_terms` VALUES (12, 'acoustic', 'acoustic', 0) ; 
INSERT INTO `mjwp_terms` VALUES (13, 'chamber', 'chamber', 0) ; 
INSERT INTO `mjwp_terms` VALUES (14, 'electronic', 'electronic', 0) ; 
INSERT INTO `mjwp_terms` VALUES (15, 'minimalist', 'minimalist', 0) ; 
INSERT INTO `mjwp_terms` VALUES (16, 'jazz', 'jazz', 0) ; 
INSERT INTO `mjwp_terms` VALUES (17, 'test', 'test', 0) ;
#
# End of data contents of table mjwp_terms
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_usermeta`
#

DROP TABLE IF EXISTS `mjwp_usermeta`;


#
# Table structure of table `mjwp_usermeta`
#

CREATE TABLE `mjwp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_usermeta (29 records)
#
 
INSERT INTO `mjwp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `mjwp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `mjwp_usermeta` VALUES (3, 1, 'nickname', 'cmd545') ; 
INSERT INTO `mjwp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `mjwp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `mjwp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `mjwp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `mjwp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `mjwp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `mjwp_usermeta` VALUES (10, 1, 'mjwp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `mjwp_usermeta` VALUES (11, 1, 'mjwp_user_level', '10') ; 
INSERT INTO `mjwp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `mjwp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `mjwp_usermeta` VALUES (14, 1, 'mjwp_dashboard_quick_press_last_post_id', '111') ; 
INSERT INTO `mjwp_usermeta` VALUES (15, 1, 'mjwp_user-settings', 'hidetb=1&libraryContent=browse&editor=tinymce') ; 
INSERT INTO `mjwp_usermeta` VALUES (16, 1, 'mjwp_user-settings-time', '1400209399') ; 
INSERT INTO `mjwp_usermeta` VALUES (17, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:71:"acf_25,acf_23,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (18, 1, 'screen_layout_page', '2') ; 
INSERT INTO `mjwp_usermeta` VALUES (19, 1, 'closedpostboxes_page', 'a:1:{i:0;s:11:"commentsdiv";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (20, 1, 'metaboxhidden_page', 'a:6:{i:0;s:6:"acf_25";i:1;s:6:"acf_23";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (22, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:11:"add-project";i:2;s:15:"add-inspiration";i:3;s:12:"add-post_tag";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (23, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `mjwp_usermeta` VALUES (24, 1, 'closedpostboxes_project', 'a:0:{}') ; 
INSERT INTO `mjwp_usermeta` VALUES (25, 1, 'metaboxhidden_project', 'a:9:{i:0;s:11:"categorydiv";i:1;s:6:"acf_67";i:2;s:6:"acf_25";i:3;s:13:"trackbacksdiv";i:4;s:10:"postcustom";i:5;s:16:"commentstatusdiv";i:6;s:11:"commentsdiv";i:7;s:7:"slugdiv";i:8;s:9:"authordiv";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (26, 1, 'meta-box-order_project', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:35:"submitdiv,categorydiv,pageparentdiv";s:6:"normal";s:121:"acf_67,acf_25,tagsdiv-post_tag,acf_23,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `mjwp_usermeta` VALUES (27, 1, 'screen_layout_project', '2') ; 
INSERT INTO `mjwp_usermeta` VALUES (28, 1, 'closedpostboxes_post', 'a:0:{}') ; 
INSERT INTO `mjwp_usermeta` VALUES (29, 1, 'metaboxhidden_post', 'a:10:{i:0;s:6:"acf_67";i:1;s:6:"acf_25";i:2;s:6:"acf_23";i:3;s:12:"revisionsdiv";i:4;s:13:"trackbacksdiv";i:5;s:10:"postcustom";i:6;s:16:"commentstatusdiv";i:7;s:11:"commentsdiv";i:8;s:7:"slugdiv";i:9;s:9:"authordiv";}') ;
#
# End of data contents of table mjwp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/themusicjournal MySQL database backup
#
# Generated: Tuesday 20. May 2014 00:29 UTC
# Hostname: localhost
# Database: `musicjournaldb`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `mjwp_users`
# --------------------------------------------------------


#
# Delete any existing table `mjwp_users`
#

DROP TABLE IF EXISTS `mjwp_users`;


#
# Table structure of table `mjwp_users`
#

CREATE TABLE `mjwp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table mjwp_users (1 records)
#
 
INSERT INTO `mjwp_users` VALUES (1, 'cmd545', '$P$B/qUSbBXDuoG7IivFiypWpgFo2xAb90', 'cmd545', 'carriemphotography@gmail.com', '', '2014-05-10 15:13:55', '', 0, 'cmd545') ;
#
# End of data contents of table mjwp_users
# --------------------------------------------------------

